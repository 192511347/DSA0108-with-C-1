@echo off
echo ========================================
echo Starting AgriSphere Next.js Frontend
echo ========================================
echo.

cd frontend
npm run dev

pause
