# AgriSphere Master Implementation Plan

**Status**: In Progress  
**Started**: November 12, 2026  
**Port Configuration**: Frontend on 3000, Backend on 6000

---

## Executive Summary

Comprehensive redesign addressing:
1. ❌ 404 errors on profile, orders, services
2. ❌ Farmer product listing restriction bug
3. ❌ Emoji overuse - replace with SVG icons
4. ❌ No demo accounts/credentials
5. ❌ Poor spacing in login/register
6. ❌ Empty marketplace - need mock data
7. ❌ Service buttons non-functional
8. ❌ No role-based dashboards
9. ❌ Typography issues
10. ❌ Port conflicts

---

## Phase 0: Critical Setup

### 0.1 Port Configuration ✅
- **Frontend**: Change from 3000 → 6000
- **Backend**: Change from 8080 → 6001 (to avoid conflicts)
- **Reason**: User requested port 6000-something

### 0.2 Branch Setup
```bash
git checkout -b redesign/agrisphere-complete
```

### 0.3 Status Tracking
- Create `docs/REDESIGN_STATUS.md` (living document)
- Track every phase completion
- Document assumptions and decisions

---

## Implementation Phases

### Phase 1: Fix Critical 404s (TODAY - Priority 1)
**Time**: 2-3 hours

**Tasks**:
1. Create `/dashboard/profile/page.tsx`
2. Create `/dashboard/orders/page.tsx`
3. Create `/orders/[id]/page.tsx`
4. Create `/services/[id]/page.tsx`
5. Fix routing in Header/Footer components
6. Test all routes - NO 404s

**Verification**:
- Visit every dashboard link
- Check all navigation items
- Test direct URL access
- Mobile navigation check

---

### Phase 2: Backend Role Fix (TODAY - Priority 1)
**Time**: 30 minutes

**Current Bug**:
```cpp
// backend-simple or backend/src/controllers/ProductController.cpp
if (userRole != "SELLER") {
    return 403; // BUG: Blocks farmers!
}
```

**Fix**:
```cpp
if (userRole != "SELLER" && userRole != "FARMER") {
    return 403;
}
```

**Verification**:
- Farmer can POST /products
- Buyer cannot POST /products
- Seller can POST /products

---

### Phase 3: Port Configuration (TODAY - Priority 1)
**Time**: 15 minutes

**Frontend** (`frontend/package.json`):
```json
{
  "scripts": {
    "dev": "next dev -p 6000",
    "start": "next start -p 6000"
  }
}
```

**Frontend** (`frontend/.env.local`):
```bash
NEXT_PUBLIC_API_URL=http://localhost:6001/api/v1
```

**Backend** (`backend-simple/package.json` or startup):
```json
{
  "scripts": {
    "start": "node server.js --port 6001"
  }
}
```

Or update `backend-simple/.env`:
```bash
PORT=6001
```

**Verification**:
- Frontend accessible at `http://localhost:6000`
- Backend accessible at `http://localhost:6001`
- API calls work correctly

---

### Phase 4: Install Icon Library (TODAY)
**Time**: 10 minutes

```bash
cd frontend
npm install lucide-react
```

**Why**: Replace ALL emojis with professional SVG icons

---

### Phase 5: Install New Fonts (TODAY)
**Time**: 15 minutes

```bash
npm install @fontsource/fraunces @fontsource-variable/fraunces
npm install @fontsource/plus-jakarta-sans @fontsource-variable/plus-jakarta-sans
npm install @fontsource/noto-sans-tamil @fontsource/noto-sans-devanagari
```

**Update** `frontend/src/app/layout.tsx`:
- Remove EB Garamond, Figtree
- Add Fraunces (display), Plus Jakarta Sans (UI)
- Add Noto fonts for Tamil/Hindi

---

### Phase 6: Replace ALL Emojis (DAY 1)
**Time**: 2-3 hours

**Emoji → Icon Mapping**:
- 🌱 → `<Sprout />` (Farmer)
- 🛒 → `<ShoppingCart />` (Buyer)  
- 💼 → `<Store />` (Seller)
- 🔧 → `<Wrench />` (Service Provider)
- 👤 → `<User />` (Profile)
- 📦 → `<Package />` (Orders)
- 🏠 → `<Home />` (Home)
- 🔍 → `<Search />` (Search)
- ⭐ → `<Star />` (Rating)

**Files to Update**:
- Header.tsx
- Footer.tsx  
- Dashboard pages (all)
- Register page (role selection)
- Services page
- Products page
- Every component

**Script to Check**:
```js
// scripts/check-no-emoji.mjs
import { readFileSync, readdirSync } from 'fs';
import { join } from 'path';

// Regex to detect emojis
const emojiRegex = /[\u{1F300}-\u{1F9FF}]/u;

function checkFile(path) {
  const content = readFileSync(path, 'utf-8');
  const lines = content.split('\n');
  const violations = [];
  
  lines.forEach((line, idx) => {
    if (emojiRegex.test(line)) {
      violations.push({ line: idx + 1, content: line.trim() });
    }
  });
  
  return violations;
}

// Run on src/**/*.{ts,tsx,js,jsx}
```

---

### Phase 7: Create Demo Accounts & Credentials (DAY 1)
**Time**: 1 hour

**Create** `credentials.md` (in repo root):
```markdown
# AgriSphere Demo Credentials

⚠️ **DEMO ONLY - DO NOT USE IN PRODUCTION**

## Accounts

### Admin
Email: admin@agrisphere.demo
Password: Admin@DemoOnly2024
Role: Administrator

### Farmer 1
Email: farmer1@agrisphere.demo  
Password: Farmer@DemoOnly2024
Name: Murugan K.
Location: Vellore, Tamil Nadu

### Farmer 2
Email: farmer2@agrisphere.demo
Password: Farmer2@DemoOnly2024  
Name: Lakshmi R.
Location: Thanjavur, Tamil Nadu

### Buyer
Email: buyer@agrisphere.demo
Password: Buyer@DemoOnly2024
Name: Anitha S.
Type: Individual

### Seller 1  
Email: seller1@agrisphere.demo
Password: Seller@DemoOnly2024
Business: GreenRoot Agro Supplies
Status: VERIFIED

### Seller 2
Email: seller2@agrisphere.demo
Password: Seller2@DemoOnly2024
Business: Kaveri Agri Mart  
Status: VERIFIED

### Service Provider
Email: provider@agrisphere.demo
Password: Provider@DemoOnly2024
Business: Sri Balaji Farm Services
Services: Tractor, Drone, Soil Testing
Status: VERIFIED
```

**Update** `.gitignore`:
```
credentials.md
```

**Create Seed Script** (`backend-simple/scripts/seed-demo-users.js`):
```javascript
// Seed all 7 demo accounts with hashed passwords
// Set is_demo = true on all
// Mark sellers/providers as VERIFIED
```

---

### Phase 8: Fix Login/Register Spacing (DAY 1)
**Time**: 1 hour

**Current Issues**:
- Forms cramped (gap-5 = 20px too tight)
- Container padding insufficient
- Buttons too short

**New Spacing**:
```tsx
// Login/Register pages
<div className="min-h-screen flex items-center justify-center p-6 md:p-12">
  <div className="w-full max-w-md">
    <Card className="p-8 md:p-12"> {/* Was p-6 */}
      <form className="space-y-6"> {/* Was space-y-5 */}
        <Input className="h-12" /> {/* Was default */}
        <Button className="h-13 text-lg"> {/* Was default */}
      </form>
    </Card>
  </div>
</div>
```

---

### Phase 9: Create AgriSphere Logo SVG (DAY 1)
**Time**: 30 minutes

**Create** `frontend/src/components/Logo.tsx`:
```tsx
interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function Logo({ size = 'md', className }: LogoProps) {
  const sizes = {
    sm: { icon: 24, text: 'text-lg' },
    md: { icon: 32, text: 'text-xl' },
    lg: { icon: 48, text: 'text-3xl' }
  };
  
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <svg 
        width={sizes[size].icon} 
        height={sizes[size].icon}
        viewBox="0 0 32 32" 
        fill="none"
        aria-hidden="true"
      >
        {/* Sphere with leaf - minimal agricultural mark */}
        <circle 
          cx="16" cy="16" r="13" 
          stroke="currentColor" 
          strokeWidth="1.75"
        />
        <path 
          d="M10 22c0-6.5 4-10.5 12-11.5 0 7.5-4 11.5-10 11.5-.7 0-1.4 0-2 0z" 
          fill="currentColor"
        />
        <path 
          d="M10.5 22.5c3-3.2 6-5.4 9.5-7.5" 
          stroke="#FFFFEB" 
          strokeWidth="1.5" 
          strokeLinecap="round"
        />
      </svg>
      <span className={`font-display font-semibold ${sizes[size].text}`}>
        AgriSphere
      </span>
    </div>
  );
}
```

---

### Phase 10: Seed Mock Products (DAY 2)
**Time**: 3-4 hours

**Create** `backend-simple/scripts/seed-demo-products.js`:

**Categories**:
1. Seeds (10 products)
2. Fertilizers (8 products)
3. Pesticides (6 products)  
4. Equipment (8 products)
5. Fresh Produce (12 products)

**Each Product**:
- Name, description, category
- Price in paise (multiply by 100)
- Stock quantity
- Unit type
- Seller/Farmer ID (demo accounts)
- is_demo = true
- Image path (local file)

**Images**:
- Download from Unsplash/Pexels with agriculture keywords
- Save to `frontend/public/seed/products/`
- Document licenses in `docs/ASSET_CREDITS.md`

---

### Phase 11: Seed Mock Services (DAY 2)  
**Time**: 2 hours

**Services** (6 total):
1. Tractor Rental with Driver (₹500/hour)
2. Drone Spraying (₹800/acre)
3. Soil Testing with Report (₹1200/sample)
4. Rotavator Rental (₹2500/day)
5. Drip Irrigation Installation (₹7800/half-acre)
6. Crop Consultation Visit (₹1500/visit)

**Each Service**:
- Type icon (SVG, not emoji)
- Provider ID (demo provider)
- Price and pricing type
- Description
- Service area
- is_demo = true

---

### Phase 12: Role-Based Dashboards (DAY 2-3)
**Time**: 6-8 hours

**Create Structure**:
```
frontend/src/app/dashboard/
├── page.tsx (router to role-based dashboard)
├── farmer/
│   ├── page.tsx (overview)
│   ├── sell-produce/page.tsx
│   ├── my-listings/page.tsx
│   └── bookings/page.tsx
├── buyer/
│   ├── page.tsx (overview)
│   └── wishlist/page.tsx
├── seller/
│   ├── page.tsx (overview)
│   ├── products/
│   │   ├── page.tsx (list)
│   │   └── new/page.tsx (create)
│   ├── inventory/page.tsx
│   └── orders/page.tsx
├── provider/
│   ├── page.tsx (overview)
│   ├── services/
│   │   ├── page.tsx (list)
│   │   └── new/page.tsx (create)
│   ├── bookings/page.tsx
│   └── availability/page.tsx
└── profile/page.tsx (shared)
```

**Dashboard Router Logic**:
```tsx
// dashboard/page.tsx
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { authApi } from '@/lib/api';

export default function DashboardPage() {
  const router = useRouter();
  
  useEffect(() => {
    async function routeByRole() {
      const { data } = await authApi.me();
      const role = data.role.toLowerCase();
      
      switch (role) {
        case 'farmer':
          router.replace('/dashboard/farmer');
          break;
        case 'buyer':
          router.replace('/dashboard/buyer');
          break;
        case 'seller':
          router.replace('/dashboard/seller');
          break;
        case 'service_provider':
          router.replace('/dashboard/provider');
          break;
        case 'admin':
          router.replace('/admin');
          break;
        default:
          router.replace('/');
      }
    }
    
    routeByRole();
  }, [router]);
  
  return <div>Loading...</div>;
}
```

---

### Phase 13: Service Detail Pages & Booking (DAY 3)
**Time**: 3-4 hours

1. Create `/services/[id]/page.tsx`
2. Implement booking form
3. Add booking management
4. Test end-to-end flow

---

### Phase 14: Admin Panel (DAY 3)
**Time**: 3-4 hours

**Create** `frontend/src/app/admin/`:
- Dashboard overview
- User management
- Seller/provider approvals
- Product moderation
- Analytics

---

### Phase 15: Complete API Client (DAY 3)
**Time**: 2 hours

**Add to** `frontend/src/lib/api.ts`:
```typescript
// Service API
serviceApi: {
  list(params),
  getById(id),
  create(data),
  update(id, data),
  myServices(),
}

// Booking API  
bookingApi: {
  create(data),
  list(params),
  getById(id),
  accept(id),
  reject(id),
  complete(id),
  cancel(id),
}

// Order API (complete)
orderApi: {
  create(data),
  list(params),
  getById(id),
  cancel(id),
}

// Admin API
adminApi: {
  pendingApprovals(),
  approveUser(id),
  rejectUser(id),
  stats(),
}
```

---

### Phase 16: Final Verification (DAY 4)
**Time**: 4 hours

**Checklist**:
- [ ] No 404 errors anywhere
- [ ] All emojis replaced with SVG
- [ ] Demo accounts work
- [ ] Farmers can list products
- [ ] All service buttons functional
- [ ] Role-based dashboards work
- [ ] Proper spacing everywhere
- [ ] Fonts load correctly (Fraunces, Plus Jakarta Sans)
- [ ] Logo renders everywhere
- [ ] Mock data visible
- [ ] Mobile responsive
- [ ] TypeScript builds
- [ ] All routes accessible

---

## Port Configuration Summary

| Service | Port | URL |
|---------|------|-----|
| Frontend Dev | 6000 | http://localhost:6000 |
| Frontend Prod | 6000 | http://localhost:6000 |
| Backend API | 6001 | http://localhost:6001 |

---

## Estimated Timeline

- **Day 1** (TODAY): Phases 1-9 (Critical fixes, fonts, icons, spacing, logo, credentials)
- **Day 2**: Phases 10-12 (Mock data, role dashboards)
- **Day 3**: Phases 13-15 (Services, admin, API complete)
- **Day 4**: Phase 16 (Final verification and polish)

**Total**: 4 days of focused work

---

## Success Criteria

### Must Have (Phase 1 Priority):
✅ No 404 errors
✅ Demo credentials working
✅ Port changed to 6000
✅ All emojis removed
✅ Proper spacing in forms
✅ Farmer can list products

### Should Have:
✅ Role-based dashboards
✅ Mock data populated
✅ Service booking works
✅ Professional fonts and logo

### Nice to Have:
✅ Admin panel complete
✅ Regional language support
✅ Voice search
✅ Offline support

---

**Next Step**: Start Phase 1 - Fix Critical 404s

