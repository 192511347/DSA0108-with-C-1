# AgriSphere Design System

**Version**: 1.0.0  
**Last Updated**: 2026-11-10  
**Inspiration**: wisprflow.ai aesthetic adapted for agricultural context

---

## Design Philosophy

AgriSphere's design system balances warmth, professionalism, and accessibility. Drawing inspiration from wisprflow.ai, we use organic colors, elegant typography, and generous whitespace to create a welcoming yet sophisticated experience for India's agricultural community.

### Core Principles

1. **Warmth & Trust**: Cream canvas creates an inviting, organic feel
2. **Growth & Nature**: Forest green represents agriculture and sustainability
3. **Clarity & Action**: Lavender accents guide users to key interactions
4. **Elegance & Accessibility**: Typography balances beauty with readability
5. **Consistency**: Reusable components ensure coherent user experience

---

## Color System

### Canvas (Background)
**Primary Background**: `#FFFFEB` (cream)

Provides a warm, organic alternative to stark white. Reduces eye strain and creates an inviting atmosphere.

```css
bg-canvas        /* #FFFFEB - Main canvas */
bg-canvas-50     /* #FFFEF5 - Lighter variant */
bg-canvas-100    /* #FFFFEB - Default */
bg-canvas-200    /* #FFFDD6 - Subtle variant */
```

### Primary (Forest Green)
**Brand Color**: `#034F46`

Represents agriculture, growth, and sustainability. Used for primary actions and brand elements.

```css
primary-500      /* #034F46 - Main brand color */
primary-600      /* #02453D - Hover states */
primary-700      /* #023B34 - Active states */
primary-50       /* #E6F2F0 - Light backgrounds */
```

### Secondary (Soil Tones)
**Grounding Color**: `#8B7570` (warm soil brown)

Earthy tones for text, borders, and secondary UI elements.

```css
secondary-800    /* #372F2E - Primary text */
secondary-700    /* #534745 - Secondary text */
secondary-500    /* #8B7570 - Muted elements */
secondary-300    /* #C3B7B1 - Borders */
secondary-50     /* #F5F3F2 - Light backgrounds */
```

### Accent (Lavender)
**CTA Color**: `#F0D7FF`

Soft lavender for call-to-action elements and highlights. Creates contrast without harshness.

```css
accent-200       /* #F0D7FF - Main CTA color */
accent-300       /* #E7BFFF - Hover */
accent-400       /* #DEA7FF - Active */
```

### Semantic Colors

**Success** (Growth): `#2ACF69` - Vibrant green for positive feedback
**Warning** (Turmeric): `#E3A008` - Yellow-orange for cautions
**Error** (Terra Cotta): `#DC2626` - Red for errors and critical alerts

---

## Typography

### Font Families

**Display Font**: EB Garamond  
- Usage: Headlines, page titles, hero text
- Weights: 400, 500, 600, 700
- Characteristics: Elegant, readable, timeless

**UI Font**: Figtree  
- Usage: Body text, buttons, labels, navigation
- Weights: 300, 400, 500, 600, 700
- Characteristics: Clean, modern, highly legible

### Type Scale

#### Display Sizes (EB Garamond)
```css
text-display-xl  /* 72px / 4.5rem - Hero headlines */
text-display-lg  /* 60px / 3.75rem - Section heroes */
text-display-md  /* 48px / 3rem - Page titles (h1) */
text-display-sm  /* 36px / 2.25rem - Section titles (h2) */
```

#### Heading Sizes (Figtree)
```css
text-heading-xl  /* 32px / 2rem - Major headings (h3) */
text-heading-lg  /* 24px / 1.5rem - Sub-headings (h4) */
text-heading-md  /* 20px / 1.25rem - Card titles (h5) */
text-heading-sm  /* 18px / 1.125rem - Minor headings (h6) */
```

#### Body Sizes (Figtree)
```css
text-body-lg     /* 18px / 1.125rem - Large body, prominent text */
text-body-md     /* 16px / 1rem - Default body text */
text-body-sm     /* 14px / 0.875rem - Small text, captions */
text-body-xs     /* 12px / 0.75rem - Fine print, labels */
```

### Usage Guidelines

- **Headlines**: Use EB Garamond for emotional impact and elegance
- **Body**: Use Figtree for clarity and readability
- **Buttons**: Always Figtree, medium weight
- **Line Height**: 1.6-1.7 for body text, 1.1-1.3 for display
- **Letter Spacing**: Slightly tighter (-0.01em to -0.02em) for large display text

---

## Spacing System

Based on 4px base unit (Tailwind's default spacing scale):

```
4px   → 1     (0.25rem)
8px   → 2     (0.5rem)
12px  → 3     (0.75rem)
16px  → 4     (1rem)
20px  → 5     (1.25rem)
24px  → 6     (1.5rem)
32px  → 8     (2rem)
40px  → 10    (2.5rem)
48px  → 12    (3rem)
64px  → 16    (4rem)
```

### Component Spacing
- **Buttons**: `px-5 py-2.5` (20px × 10px)
- **Inputs**: `px-4 py-2.5` (16px × 10px)
- **Cards**: `p-6` (24px padding)
- **Sections**: `py-12 sm:py-16 lg:py-20` (responsive vertical rhythm)

---

## Border Radius

Rounded corners create a friendly, approachable aesthetic:

```css
rounded-lg       /* 8px - Small elements */
rounded-xl       /* 12px - Buttons, inputs */
rounded-2xl      /* 20px - Cards */
rounded-3xl      /* 24px - Large cards */
rounded-4xl      /* 32px - Hero elements */
```

---

## Shadows

Soft shadows inspired by natural light:

```css
shadow-soft         /* Light shadow for cards */
shadow-soft-lg      /* Medium shadow for hover states */
shadow-elevated     /* Prominent shadow for modals */
shadow-elevated-lg  /* Heavy shadow for floating elements */
```

All shadows use the primary color with low opacity for brand consistency:
- `rgba(3, 79, 70, 0.08)` - Soft
- `rgba(3, 79, 70, 0.16)` - Elevated

---

## Components

### Buttons

**Variants**:
- `btn-primary`: Primary actions (forest green background)
- `btn-secondary`: Secondary actions (white with border)
- `btn-accent`: Call-to-action (lavender background)
- `btn-ghost`: Subtle actions (transparent)

**Sizes**:
- `btn-sm`: Compact (px-4 py-2)
- Default: Standard (px-5 py-2.5)
- `btn-lg`: Prominent (px-6 py-3.5)

**States**:
- Default: Base styles
- Hover: Darker background, lifted shadow
- Active: Even darker, pressed appearance
- Disabled: 50% opacity, no pointer events
- Loading: Spinner with "Loading..." text

### Inputs

**Variants**:
- Default: Standard input with border
- `input-error`: Red border for validation errors

**Features**:
- Label support with required indicator
- Helper text for guidance
- Error text for validation
- Left/right icon slots
- Focus states with ring

### Cards

**Variants**:
- `card`: Standard card (soft shadow)
- `card-elevated`: Prominent card (elevated shadow)
- `card-interactive`: Hoverable card (lift on hover)

**Padding Options**:
- `padding="none"`: No padding
- `padding="sm"`: 16px
- `padding="md"`: 24px (default)
- `padding="lg"`: 32px

**Subcomponents**:
- `CardHeader`: Top section
- `CardTitle`: Heading (h3)
- `CardDescription`: Subtitle
- `CardContent`: Main content
- `CardFooter`: Bottom section with divider

### Badges

Small status indicators:

```tsx
<Badge variant="primary">New</Badge>
<Badge variant="success">Active</Badge>
<Badge variant="warning">Pending</Badge>
<Badge variant="error">Sold Out</Badge>
```

### Alerts

Feedback messages:

```tsx
<Alert variant="info" title="Note">Important information...</Alert>
<Alert variant="success" title="Success">Operation completed</Alert>
<Alert variant="warning" title="Warning">Please review...</Alert>
<Alert variant="error" title="Error">Something went wrong</Alert>
```

---

## Layout System

### Containers

```css
container-narrow   /* max-w-4xl (896px) - Forms, articles */
container-default  /* max-w-7xl (1280px) - Standard pages */
container-wide     /* max-w-[1400px] - Wide layouts */
```

All containers include responsive padding: `px-4 sm:px-6 lg:px-8`

### Sections

Vertical spacing for page sections:

```css
section-sm    /* py-8 sm:py-10 lg:py-12 - Compact */
section       /* py-12 sm:py-16 lg:py-20 - Standard */
section-lg    /* py-16 sm:py-20 lg:py-24 - Spacious */
```

---

## Responsive Design

### Breakpoints (Tailwind defaults)

```
sm:  640px   /* Tablet portrait */
md:  768px   /* Tablet landscape */
lg:  1024px  /* Desktop */
xl:  1280px  /* Large desktop */
2xl: 1536px  /* Extra large */
```

### Mobile-First Approach

All base styles target mobile. Use breakpoint prefixes for larger screens:

```tsx
<div className="text-body-sm sm:text-body-md lg:text-body-lg">
  Responsive text
</div>
```

---

## Animations

### Transitions

Standard duration: `duration-200` (200ms)

```css
transition-colors    /* Color changes */
transition-all       /* All properties */
transition-transform /* Movement */
```

### Keyframe Animations

```css
animate-fade-in   /* Fade in (opacity) */
animate-slide-up  /* Slide from bottom */
animate-scale-in  /* Scale from 95% */
```

---

## Accessibility

### Color Contrast

All text/background combinations meet WCAG 2.1 AA standards:
- Normal text: 4.5:1 minimum
- Large text: 3:1 minimum
- UI components: 3:1 minimum

### Focus States

All interactive elements have visible focus indicators:
- `focus:ring-2` - 2px ring
- `focus:ring-offset-2` - 2px offset
- Ring colors match component variant

### Keyboard Navigation

All components support keyboard interaction:
- Tab navigation
- Enter/Space for activation
- Arrow keys for menus/lists

### Screen Readers

- Semantic HTML (buttons, links, headings)
- ARIA labels where needed
- Role attributes for custom components

---

## Usage Examples

### Button Usage

```tsx
import { Button } from '@/components/ui'

// Primary action
<Button variant="primary" size="lg">
  Get Started
</Button>

// Secondary with icon
<Button variant="secondary" leftIcon={<Icon />}>
  Learn More
</Button>

// Loading state
<Button variant="accent" isLoading>
  Processing
</Button>
```

### Form with Input

```tsx
import { Input } from '@/components/ui'

<Input
  label="Email Address"
  type="email"
  placeholder="you@example.com"
  required
  helperText="We'll never share your email"
  errorText={errors.email}
/>
```

### Card Layout

```tsx
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui'

<Card variant="interactive">
  <CardHeader>
    <CardTitle>Product Name</CardTitle>
    <CardDescription>Fresh from the farm</CardDescription>
  </CardHeader>
  <CardContent>
    <p>Product details here...</p>
  </CardContent>
</Card>
```

---

## Implementation Notes

### Font Loading

Fonts are loaded via Next.js font optimization in `app/layout.tsx`:

```tsx
import { EB_Garamond, Figtree } from 'next/font/google'

const garamond = EB_Garamond({ ... })
const figtree = Figtree({ ... })
```

### CSS Variables

Font families are available as CSS variables:
- `--font-garamond`: EB Garamond
- `--font-figtree`: Figtree

### Tailwind Configuration

All design tokens are defined in `tailwind.config.ts` and available throughout the app via Tailwind utility classes.

### Component Variants

Components use `class-variance-authority` for type-safe variant management.

---

## Resources

- Tailwind Config: `frontend/tailwind.config.ts`
- Global Styles: `frontend/src/app/globals.css`
- Component Library: `frontend/src/components/ui/`
- Font Setup: `frontend/src/app/layout.tsx`

---

**Design System Owner**: AgriSphere Development Team  
**Questions**: Refer to this document or check component implementation in `src/components/ui/`
