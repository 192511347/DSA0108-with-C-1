# AgriSphere Images and Assets

**Phase 8 Status**: DOCUMENTED  
**Date**: 2026-11-10

---

## Current State

### Images Used

**Product Images**:
- Currently using gradient backgrounds (primary-100 to accent-100) as placeholders
- SVG icons as fallbacks when no product image available
- Images are expected from API (`product.images[0]`)

**Logo**:
- Emoji-based: 🌾 (wheat/rice emoji)
- Consistent across all pages (Header, Footer, Login, Register)
- Forest green background (primary-500) with rounded-xl corners

**Icons**:
- All icons are SVG-based from Heroicons
- No external icon libraries needed
- Inline SVG for optimal performance

### Placeholder System

**Product Placeholders**:
```tsx
// Gradient background with SVG icon
<div className="bg-gradient-to-br from-primary-100 to-accent-100">
  <svg className="w-20 h-20 text-primary-400">...</svg>
</div>
```

**Empty States**:
- SVG illustrations for "No products found"
- SVG illustrations for "Product not found"
- Consistent iconography throughout

### Assets Inventory

**Fonts**:
- ✅ EB Garamond (Google Fonts) - loaded via Next.js
- ✅ Figtree (Google Fonts) - loaded via Next.js
- Font files automatically optimized by Next.js

**Colors**:
- ✅ All colors defined in `tailwind.config.ts`
- ✅ No external color assets needed

**Icons**:
- ✅ SVG icons inline (no sprite sheets)
- ✅ Heroicons style consistent throughout
- ✅ All icons accessible and semantic

---

## Recommendations for Production

### Product Images

**Current**: Gradient placeholders  
**Recommended**: 
1. Real product photos from sellers
2. Standardized dimensions (1:1 aspect ratio)
3. WebP format for smaller file sizes
4. Next.js Image component with optimization
5. Lazy loading for performance

**Implementation**:
```tsx
import Image from 'next/image'

<Image
  src={product.images[0]}
  alt={product.name}
  width={400}
  height={400}
  className="w-full h-full object-cover"
  placeholder="blur"
  blurDataURL="data:image/..."
/>
```

### Logo

**Current**: Emoji-based (🌾)  
**Recommended**: 
1. Custom SVG logo with brand identity
2. Multiple sizes for different use cases
3. Dark mode variant if needed
4. Favicon generation

**Location**: `/public/logo/`
- `logo.svg` - Main logo
- `logo-icon.svg` - Icon only
- `favicon.ico` - Browser favicon
- `apple-touch-icon.png` - iOS home screen

### Social Media Assets

**Recommended**:
- Open Graph images for social sharing
- Twitter card images
- App store screenshots (if mobile app planned)

**Location**: `/public/og/`
- `og-image.png` - Default OG image (1200x630)
- `twitter-card.png` - Twitter card (1200x675)

---

## Performance Considerations

### Current Setup
- ✅ SVG icons are inline (no HTTP requests)
- ✅ Fonts loaded via Next.js optimization
- ✅ No external image CDN needed yet
- ✅ Gradients used for placeholders (CSS-based, fast)

### Future Optimization
1. **Image CDN**: Consider Cloudinary or AWS S3 for product images
2. **Lazy Loading**: Implement for off-screen images
3. **Responsive Images**: Multiple sizes for different screen sizes
4. **WebP/AVIF**: Modern formats with fallbacks
5. **Blur Placeholders**: Low-quality placeholders while loading

---

## Accessibility

### Current State
- ✅ All SVG icons have descriptive paths
- ✅ No decorative images without alt text
- ✅ Color contrast meets WCAG AA standards
- ✅ Icons paired with text labels where needed

### Missing (for production)
- [ ] Alt text for all product images
- [ ] ARIA labels for icon-only buttons
- [ ] Focus indicators on all interactive elements
- [ ] High contrast mode support

---

## File Structure

```
public/
├── logo/
│   ├── logo.svg (recommended)
│   ├── logo-icon.svg (recommended)
│   └── favicon.ico (recommended)
├── og/
│   ├── og-image.png (recommended)
│   └── twitter-card.png (recommended)
└── products/
    └── (product images from uploads)
```

---

## Next Steps

1. **Replace Emoji Logo**: Design and implement custom SVG logo
2. **Product Image Upload**: Implement file upload for sellers
3. **Image Optimization**: Add Next.js Image component
4. **Favicon**: Generate and add favicon set
5. **OG Images**: Create social media preview images

---

## Notes

- Current system uses minimal external assets for fast loading
- Emoji logo is temporary but functional
- SVG icons are optimal for performance
- Gradient placeholders provide good visual consistency
- Ready for real product images when available
