# AgriSphere API Contract Documentation

**Purpose**: Define exact API contracts that the C++ backend must implement to satisfy the existing Next.js frontend.

**Source**: Analyzed from `frontend/src/lib/api.ts` and frontend components.

**Base URL**: `http://localhost:6001/api/v1`

---

## Authentication Endpoints

### POST /api/v1/auth/register
**Purpose**: Register new user account

**Request Body**:
```json
{
  "email": "string (required, valid email)",
  "password": "string (required, min 8 chars)",
  "fullName": "string (required)",
  "phone": "string (required, format: +91XXXXXXXXXX)",
  "role": "FARMER|BUYER|SELLER|PROVIDER|ADMIN",
  "district": "string (optional)",
  "state": "string (optional)"
}
```

**Success Response** (201):
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "email": "string",
      "fullName": "string",
      "role": "string",
      "status": "ACTIVE"
    },
    "tokens": {
      "accessToken": "jwt-string",
      "refreshToken": "jwt-string"
    }
  }
}
```

**Error Response** (400):
```json
{
  "success": false,
  "error": {
    "code": "REGISTRATION_FAILED",
    "message": "Email already exists",
    "fields": {
      "email": "Email is already registered"
    }
  }
}
```

---

### POST /api/v1/auth/login
**Purpose**: Authenticate user and return tokens

**Request Body**:
```json
{
  "email": "string (required)",
  "password": "string (required)"
}
```

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "email": "string",
      "fullName": "string",
      "role": "string",
      "status": "ACTIVE"
    },
    "tokens": {
      "accessToken": "jwt-string",
      "refreshToken": "jwt-string"
    }
  }
}
```

**Error Response** (401):
```json
{
  "success": false,
  "error": {
    "code": "INVALID_CREDENTIALS",
    "message": "Invalid email or password"
  }
}
```

---

### POST /api/v1/auth/refresh
**Purpose**: Refresh access token using refresh token

**Request Body**:
```json
{
  "refreshToken": "jwt-string"
}
```

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "accessToken": "new-jwt-string"
  }
}
```

---

### POST /api/v1/auth/logout
**Authentication**: Required (Bearer token)

**Request Body**:
```json
{
  "refreshToken": "jwt-string"
}
```

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "message": "Logged out successfully"
  }
}
```

---

### GET /api/v1/auth/me
**Authentication**: Required (Bearer token)

**Purpose**: Get current authenticated user details

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "email": "string",
      "fullName": "string",
      "phone": "string",
      "role": "string",
      "status": "string",
      "district": "string",
      "state": "string",
      "createdAt": "ISO-8601 timestamp"
    }
  }
}
```

---

### PUT /api/v1/auth/profile
**Authentication**: Required (Bearer token)

**Purpose**: Update user profile

**Request Body**:
```json
{
  "fullName": "string (optional)",
  "phone": "string (optional)",
  "district": "string (optional)",
  "state": "string (optional)",
  "addressLine1": "string (optional)",
  "city": "string (optional)",
  "pincode": "string (optional)"
}
```

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "user": { /* updated user object */ }
  }
}
```

---

## Product Endpoints

### GET /api/v1/products
**Purpose**: List/search products with filters

**Query Parameters**:
- `search` (string, optional): Search in product name/description
- `category` (string, optional): Filter by category
- `district` (string, optional): Filter by location
- `state` (string, optional): Filter by state
- `minPrice` (number, optional): Minimum price in paise
- `maxPrice` (number, optional): Maximum price in paise
- `page` (number, optional): Page number (default: 1)
- `pageSize` (number, optional): Items per page (default: 20)

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "products": [
      {
        "id": "uuid",
        "name": "string",
        "description": "string",
        "category": "string",
        "pricePerUnit": "number (in paise)",
        "unit": "KG|LITER|PIECE",
        "availableQuantity": "number",
        "minOrderQuantity": "number",
        "images": ["url1", "url2"],
        "seller": {
          "id": "uuid",
          "fullName": "string",
          "district": "string",
          "state": "string"
        },
        "status": "ACTIVE|INACTIVE",
        "createdAt": "ISO-8601"
      }
    ],
    "pagination": {
      "page": 1,
      "pageSize": 20,
      "totalItems": 44,
      "totalPages": 3
    }
  }
}
```

---

### GET /api/v1/products/{id}
**Purpose**: Get single product details

**URL Parameters**:
- `id` (uuid): Product ID

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "product": { /* full product object with seller details */ }
  }
}
```

**Error Response** (404):
```json
{
  "success": false,
  "error": {
    "code": "PRODUCT_NOT_FOUND",
    "message": "Product not found"
  }
}
```

---

### POST /api/v1/products
**Authentication**: Required (FARMER or SELLER role)

**Purpose**: Create new product listing

**Request Body**:
```json
{
  "name": "string (required)",
  "description": "string (required)",
  "category": "string (required)",
  "pricePerUnit": "number (required, in paise)",
  "unit": "KG|LITER|PIECE (required)",
  "availableQuantity": "number (required)",
  "minOrderQuantity": "number (optional, default: 1)",
  "images": ["url1", "url2"] (optional, array of URLs)
}
```

**Success Response** (201):
```json
{
  "success": true,
  "data": {
    "product": { /* created product object */ }
  }
}
```

---

### GET /api/v1/products/my/listings
**Authentication**: Required (FARMER or SELLER role)

**Purpose**: Get current user's product listings

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "products": [ /* array of user's products */ ]
  }
}
```

---

### GET /api/v1/products/categories
**Purpose**: Get list of all product categories

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "categories": [
      "GRAINS",
      "VEGETABLES",
      "FRUITS",
      "DAIRY",
      "SPICES"
    ]
  }
}
```

---

## Cart Endpoints

### GET /api/v1/cart
**Authentication**: Required (BUYER role)

**Purpose**: Get current user's cart

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "cart": {
      "id": "uuid",
      "items": [
        {
          "id": "uuid",
          "product": { /* product object */ },
          "quantity": "number",
          "pricePerUnit": "number (in paise)",
          "subtotal": "number (in paise)"
        }
      ],
      "totalItems": "number",
      "totalAmount": "number (in paise)",
      "updatedAt": "ISO-8601"
    }
  }
}
```

---

### POST /api/v1/cart/items
**Authentication**: Required (BUYER role)

**Purpose**: Add product to cart

**Request Body**:
```json
{
  "productId": "uuid (required)",
  "quantity": "number (required, min: 1)"
}
```

**Success Response** (201):
```json
{
  "success": true,
  "data": {
    "cart": { /* updated cart object */ }
  }
}
```

**Error Response** (400):
```json
{
  "success": false,
  "error": {
    "code": "INSUFFICIENT_STOCK",
    "message": "Requested quantity exceeds available stock"
  }
}
```

---

### PUT /api/v1/cart/items/{id}
**Authentication**: Required (BUYER role)

**Purpose**: Update cart item quantity

**URL Parameters**:
- `id` (uuid): Cart item ID

**Request Body**:
```json
{
  "quantity": "number (required, min: 1)"
}
```

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "cart": { /* updated cart object */ }
  }
}
```

---

### DELETE /api/v1/cart/items/{id}
**Authentication**: Required (BUYER role)

**Purpose**: Remove item from cart

**URL Parameters**:
- `id` (uuid): Cart item ID

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "cart": { /* updated cart object */ }
  }
}
```

---

### DELETE /api/v1/cart
**Authentication**: Required (BUYER role)

**Purpose**: Clear entire cart

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "message": "Cart cleared successfully"
  }
}
```

---

## Health Endpoint

### GET /api/v1/health
**Purpose**: Health check endpoint

**Success Response** (200):
```json
{
  "success": true,
  "data": {
    "status": "ok",
    "service": "AgriSphere C++ API",
    "database": "connected",
    "timestamp": "ISO-8601"
  }
}
```

**Unhealthy Response** (503):
```json
{
  "success": false,
  "error": {
    "code": "SERVICE_UNAVAILABLE",
    "message": "Database connection failed"
  }
}
```

---

## Authentication Mechanism

**Method**: JWT Bearer Token

**Request Header**:
```
Authorization: Bearer <access-token>
```

**Token Refresh Flow**:
1. Client makes authenticated request with access token
2. If response is 401 Unauthorized
3. Client sends refresh token to `/api/v1/auth/refresh`
4. Receives new access token
5. Retries original request with new token
6. If refresh fails, redirects to login

**Token Storage**:
- Access Token: `localStorage.getItem('accessToken')`
- Refresh Token: `localStorage.getItem('refreshToken')`

---

## Error Response Format

**Standard Error Structure**:
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "fields": {
      "fieldName": "Field-specific error message"
    }
  }
}
```

**Common Error Codes**:
- `INVALID_REQUEST` (400): Malformed request
- `INVALID_CREDENTIALS` (401): Authentication failed
- `UNAUTHORIZED` (401): Missing or invalid token
- `FORBIDDEN` (403): Insufficient permissions
- `NOT_FOUND` (404): Resource not found
- `CONFLICT` (409): Resource conflict (e.g., duplicate email)
- `SERVER_ERROR` (500): Internal server error

---

## CORS Configuration

**Allowed Origins**:
- `http://localhost:5000` (Frontend dev server)
- `http://localhost:3000` (Alternative frontend port)

**Allowed Methods**:
- GET, POST, PUT, DELETE, PATCH, OPTIONS

**Allowed Headers**:
- Content-Type
- Authorization
- X-Requested-With

**Credentials**: Allowed

---

## Data Type Conventions

### Monetary Values
- **ALL prices and amounts are in PAISE (₹1 = 100 paise)**
- Frontend displays: `amount / 100` formatted as ₹X.XX
- Backend stores: Integer values (no decimals)
- Example: ₹85.50 → stored as `8550` paise

### Dates and Times
- Format: ISO-8601 with timezone
- Example: `2026-11-10T14:30:00.000Z`

### UUIDs
- Format: Standard UUID v4
- Example: `550e8400-e29b-41d4-a716-446655440000`

### Phone Numbers
- Format: International format with country code
- Example: `+919876543210`

---

## Implementation Priority

### Phase 1 (CRITICAL - Frontend depends on these)
1. ✓ Health endpoint
2. ✓ Auth: Register, Login, Logout, Me
3. ✓ Products: List, Get by ID
4. ✓ Cart: Get, Add Item, Update Item, Remove Item

### Phase 2 (HIGH - Core marketplace features)
1. Products: Create, My Listings
2. Products: Categories endpoint
3. Orders: Create, List, Get by ID

### Phase 3 (MEDIUM - Enhanced features)
1. Service bookings
2. Mock payments
3. Reviews

### Phase 4 (LOW - Advanced features)
1. Weather API integration
2. Crop advisor AI
3. Advanced search and filters

---

**END OF API CONTRACT DOCUMENTATION**
