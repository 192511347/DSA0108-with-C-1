# AgriSphere Backend Refactoring Audit

**Date:** 2024-11-17  
**Auditor:** Senior C++ Backend Architect  
**Framework:** Crow HTTP Server (Windows Native)  
**Current Status:** Monolithic main.cpp with partial PostgreSQL integration

---

## 1. EXECUTIVE SUMMARY

### Current State
- **Single file backend:** All logic in `src/main.cpp` (~500 LOC)
- **Framework:** Crow HTTP Server v1.3.5 (header-only, asynchronous)
- **Database:** Partial libpq PostgreSQL integration (connection exists, partial query implementation)
- **Build System:** CMake with vcpkg dependency management
- **Compilation:** ✅ SUCCESSFUL (MSVC 19.52, zero errors)
- **Runtime:** ✅ Server starts on port 6001
- **Database Connection:** ⚠️ BLOCKED (password authentication failure)

### Critical Findings
1. ✅ **Framework Detection:** Crow (NOT Drogon) - correct framework in use
2. ⚠️ **Monolithic Architecture:** All routes, logic, and data access in main.cpp
3. ⚠️ **Database Integration:** Connection code exists but blocked by authentication
4. ❌ **Missing Password Hashing:** No bcrypt/Argon2 implementation
5. ❌ **Missing JWT Implementation:** jwt-cpp linked but not used
6. ❌ **Incomplete Registration:** Stub response, no database insert
7. ⚠️ **Partial Login:** Database query exists, password verification missing
8. ⚠️ **Partial Products:** Database query exists, pagination incomplete
9. ❌ **Cart Endpoints:** Stub responses only
10. ❌ **No Database Schema:** No migrations, seeds, or schema files found

---

## 2. FILE AND MODULE INVENTORY

### Existing Backend Files
```
backend/
├── src/
│   ├── main.cpp              (500 LOC - ALL LOGIC HERE)
│   └── Database.h            (125 LOC - libpq wrapper)
├── build/
│   └── Release/
│       └── AgriSphere.exe    (✅ Compiles successfully)
├── CMakeLists.txt            (48 LOC)
├── .env                      (DB credentials - needs password)
└── .env.example
```

### Missing Modular Structure
**Everything below is MISSING:**
```
include/
  ├── core/          (Config, Application, Database pool)
  ├── controllers/   (AuthController, ProductController, CartController)
  ├── services/      (AuthService, ProductService, CartService)
  ├── repositories/  (UserRepository, ProductRepository, CartRepository)
  ├── models/        (User, Product, Cart DTOs)
  ├── middleware/    (AuthMiddleware, validation)
  └── utils/         (JWT, Password hashing, validation)

src/
  ├── core/
  ├── controllers/
  ├── services/
  ├── repositories/
  └── models/

database/
  ├── migrations/    (Schema versioning)
  ├── seeds/         (Demo data)
  └── schema/        (DDL scripts)
```

---

## 3. ROUTE-TO-HANDLER MAPPING

### Implemented Routes (8 total)

| Method | Path | Handler Location | DB Integration | Auth | Status |
|--------|------|------------------|----------------|------|--------|
| GET | `/api/v1/health` | main.cpp:67-81 | ✅ Status check | No | ✅ Working |
| POST | `/api/v1/auth/register` | main.cpp:88-142 | ❌ Stub only | No | ⚠️ Partial |
| POST | `/api/v1/auth/login` | main.cpp:145-261 | ⚠️ Query only | No | ⚠️ Partial |
| GET | `/api/v1/products` | main.cpp:268-341 | ✅ Full query | No | ✅ Working* |
| GET | `/api/v1/products/:id` | main.cpp:344-362 | ❌ Stub only | No | ❌ Stub |
| POST | `/api/v1/products` | main.cpp:365-387 | ❌ Stub only | ❌ Required | ❌ Stub |
| GET | `/api/v1/cart` | main.cpp:394-407 | ❌ Stub only | ❌ Required | ❌ Stub |
| POST | `/api/v1/cart/items` | main.cpp:410-432 | ❌ Stub only | ❌ Required | ❌ Stub |

**Working*** = Works if database connection succeeds

### Frontend Expected Routes (from api.ts)

**Authentication:**
- ✅ POST `/api/v1/auth/register` (partial)
- ✅ POST `/api/v1/auth/login` (partial)
- ❌ POST `/api/v1/auth/logout` (MISSING)
- ❌ POST `/api/v1/auth/refresh` (MISSING)
- ❌ GET `/api/v1/auth/me` (MISSING)
- ❌ PUT `/api/v1/auth/profile` (MISSING)

**Products:**
- ✅ GET `/api/v1/products` (partial - missing filters)
- ❌ GET `/api/v1/products/categories` (MISSING)
- ⚠️ GET `/api/v1/products/:id` (stub)
- ⚠️ POST `/api/v1/products` (stub, no auth)
- ❌ GET `/api/v1/products/my/listings` (MISSING)

**Cart:**
- ⚠️ GET `/api/v1/cart` (stub)
- ⚠️ POST `/api/v1/cart/items` (stub)
- ❌ PUT `/api/v1/cart/items/:id` (MISSING)
- ❌ DELETE `/api/v1/cart/items/:id` (MISSING)
- ❌ DELETE `/api/v1/cart` (MISSING)

**Gap Analysis:** 14 missing or incomplete routes

---

## 4. DEPENDENCIES AND BUILD CONFIGURATION

### vcpkg Dependencies (Installed)
```
crow:x64-windows@1.3.5            ✅ HTTP framework
nlohmann-json:x64-windows@3.12.0  ✅ JSON parsing
jwt-cpp:x64-windows@0.7.2         ⚠️ Linked but unused
libpq:x64-windows@18.4            ⚠️ Partially used
openssl:x64-windows@3.6.5         ✅ For HTTPS/crypto
```

### CMakeLists.txt Analysis
```cmake
# ✅ Correct standard
set(CMAKE_CXX_STANDARD 17)

# ✅ All dependencies found
find_package(Crow CONFIG REQUIRED)
find_package(nlohmann_json CONFIG REQUIRED)
find_package(PostgreSQL REQUIRED)
find_package(OpenSSL REQUIRED)
find_package(jwt-cpp CONFIG REQUIRED)

# ⚠️ PROBLEM: Only main.cpp in sources
set(SOURCES
    src/main.cpp  # ← Single file!
)

# ✅ Correct linkage
target_link_libraries(${PROJECT_NAME} PRIVATE
    Crow::Crow
    nlohmann_json::nlohmann_json
    PostgreSQL::PostgreSQL
    OpenSSL::SSL OpenSSL::Crypto
    jwt-cpp::jwt-cpp
)
```

**Issue:** CMakeLists.txt will need updating as we add modular source files.

---

## 5. DATABASE CONNECTIVITY FINDINGS

### Current Implementation
**File:** `src/Database.h`  
**Type:** Simple libpq wrapper (no pooling)  
**Features:**
- ✅ Connection string building
- ✅ Basic connect/disconnect
- ✅ `executeQuery()` for simple queries
- ✅ `executeParams()` for parameterized queries
- ✅ `escapeString()` for safety
- ❌ No connection pooling
- ❌ No transaction support
- ❌ No prepared statement caching
- ❌ No reconnection logic

### Connection Test Result
```
Database connection failed: password authentication failed for user "postgres"
⚠️  WARNING: Database connection failed. Using stub responses.
```

**Root Cause:** `.env` file has placeholder password `your_postgres_password_here`

**Blocker:** Cannot test database-dependent features until password is configured.

### Current Database Usage

**Health Check (✅ Working):**
```cpp
std::string dbStatus = db->isConnected() ? "connected" : "not_connected";
```

**Login (⚠️ Partial):**
```cpp
PGresult* res = db->executeParams(
    "SELECT id, email, full_name, password_hash, role, status FROM users WHERE email = $1 LIMIT 1",
    1, paramValues
);
// ✅ Query correct
// ❌ Password verification missing
// ❌ JWT generation missing
```

**Products Listing (✅ Working):**
```cpp
PGresult* res = db->executeQuery(
    "SELECT id, name, description, category, price_per_unit, unit, available_quantity, "
    "seller_id, status, created_at FROM products "
    "WHERE status = 'ACTIVE' ORDER BY created_at DESC LIMIT 20"
);
// ✅ Query correct
// ⚠️ No pagination params
// ⚠️ No filters (category, price, search)
```

---

## 6. SECURITY ANALYSIS

### Critical Security Issues

1. **No Password Hashing** ❌
   - Registration: Passwords stored in plain text (if it worked)
   - Login: No bcrypt/Argon2 verification
   - Risk: HIGH - credential compromise

2. **No JWT Implementation** ❌
   - jwt-cpp is linked but never used
   - Tokens are hardcoded strings: `"jwt-token-for-" + userId`
   - No expiration, no signature, no claims
   - Risk: HIGH - authentication bypass

3. **No Authorization** ❌
   - No middleware to check tokens
   - No role-based access control
   - Anyone can call any endpoint
   - Risk: HIGH - privilege escalation

4. **SQL Injection Prevention** ⚠️
   - Parameterized queries used ✅
   - But not consistently (some routes use stubs)
   - Risk: MEDIUM - partial protection

5. **Input Validation** ⚠️
   - Basic field existence checks ✅
   - No type validation, format validation, or sanitization
   - Risk: MEDIUM - malformed data

6. **CORS Configuration** ✅
   - Properly configured for localhost:5000
   - Risk: LOW

7. **Secrets Management** ⚠️
   - .env file exists ✅
   - .env.example provided ✅
   - But .env committed to git ❌
   - Risk: MEDIUM - exposure if pushed

---

## 7. REFACTORING PLAN

### Phase Breakdown

#### **PHASE 1: Project Structure Setup** [CURRENT]
- ✅ Audit complete
- Create directory structure
- Set up BACKEND_PROGRESS.md

#### **PHASE 2: Core Infrastructure**
- Extract `Config` class from main.cpp
- Extract `Application` class (server lifecycle)
- Improve `Database` class (add pooling, transactions)
- Create `Logger` utility

#### **PHASE 3: Models and DTOs**
- Create `User`, `Product`, `Cart`, `CartItem` models
- Create request/response DTOs
- JSON serialization helpers

#### **PHASE 4: Repositories**
- `UserRepository` (CRUD + queries)
- `ProductRepository` (CRUD + filters + pagination)
- `CartRepository` (CRUD + item management)
- Transaction support

#### **PHASE 5: Security Utilities**
- Password hashing (bcrypt or Argon2)
- JWT generation and validation (using jwt-cpp)
- Token middleware
- Input validation utilities

#### **PHASE 6: Services**
- `AuthService` (register, login, refresh, password verification)
- `ProductService` (business logic, validation)
- `CartService` (cart operations, stock validation)

#### **PHASE 7: Controllers**
- `AuthController` (all auth routes)
- `ProductController` (all product routes)
- `CartController` (all cart routes)
- Error handling and response formatting

#### **PHASE 8: Middleware**
- `AuthMiddleware` (token validation)
- `RoleMiddleware` (role-based access)
- Request logging
- Error handling

#### **PHASE 9: Database Schema**
- Create `database/schema/` directory
- Write DDL for users, products, carts, cart_items
- Create migration system
- Seed demo data

#### **PHASE 10: Integration and Testing**
- Connect all modules in main.cpp
- Test each route with real database
- Fix frontend compatibility issues
- Update documentation

---

## 8. BASELINE BUILD AND TEST RESULTS

### Build Test
```powershell
cd backend/build
cmake --build . --config Release
```
**Result:** ✅ SUCCESS (0 errors, 0 warnings)

### Runtime Test
```powershell
.\Release\AgriSphere.exe
```
**Result:** ✅ Server starts on port 6001

### Health Endpoint Test
```powershell
Invoke-WebRequest -Uri "http://localhost:6001/api/v1/health"
```
**Result:**
```json
{
  "success": true,
  "data": {
    "status": "ok",
    "service": "AgriSphere C++ API",
    "database": "not_connected",
    "timestamp": 1794928726
  }
}
```
✅ HTTP 200, JSON valid, CORS headers present

### Database Connection Test
**Result:** ❌ BLOCKED
```
password authentication failed for user "postgres"
```

### Frontend Integration Test
**Not performed yet** - requires backend running with database

---

## 9. RISKS AND COMPATIBILITY REQUIREMENTS

### High-Risk Items
1. **Database Connection:** Must get PostgreSQL password before proceeding
2. **Breaking Changes:** Refactoring could break existing frontend
3. **Build System:** Adding files requires careful CMakeLists.txt updates
4. **Windows-Specific:** libpq, OpenSSL paths may vary
5. **Crow Framework:** Limited documentation, unusual route capture syntax

### Compatibility Requirements
1. **Preserve all existing routes** (8 routes currently)
2. **Maintain exact request/response schemas** (frontend depends on them)
3. **Keep port 6001** (frontend hardcoded)
4. **Preserve CORS settings**
5. **Maintain error response format** ({ success, error: { code, message }})
6. **Keep status codes** (200, 201, 400, 401, 500)
7. **JSON field names** (camelCase, e.g., pricePerUnit, not price_per_unit)

### Rollback Plan
- Git commit after each phase
- Keep main.cpp.backup before major changes
- CMakeLists.txt version control
- Build verification after every module addition

---

## 10. DUPLICATE IMPLEMENTATIONS

**None found.** This is a clean slate refactoring.

---

## 11. COMPLETENESS ANALYSIS

### Complete Features
- ✅ Health check
- ✅ Server startup/shutdown
- ✅ CORS configuration
- ✅ JSON request/response handling
- ✅ Basic error handling

### Partial Features (Need Completion)
- ⚠️ User registration (no DB insert, no password hash)
- ⚠️ User login (DB query exists, no password verify, no JWT)
- ⚠️ Product listing (DB query exists, missing filters/pagination params)
- ⚠️ Product details (stub only)
- ⚠️ Product creation (stub only, missing auth)

### Missing Features
- ❌ JWT token generation and validation
- ❌ Password hashing
- ❌ Token refresh
- ❌ User profile management
- ❌ Product filtering (category, price, search)
- ❌ Product pagination (page, pageSize params)
- ❌ Cart database operations (all stubs)
- ❌ Cart item updates and deletes
- ❌ Authorization middleware
- ❌ Role-based access control
- ❌ Database migrations
- ❌ Database seeding
- ❌ Connection pooling
- ❌ Transaction support
- ❌ Logging system
- ❌ Unit tests
- ❌ Integration tests
- ❌ API documentation

---

## 12. RECOMMENDATIONS

### Immediate Actions (PHASE 2)
1. **Fix Database Password:** Update `.env` with correct PostgreSQL password
2. **Test Connection:** Verify database connectivity before refactoring
3. **Commit Current State:** Baseline commit before structural changes
4. **Create Directory Structure:** Set up include/ and src/ subdirectories

### Refactoring Strategy
- **Incremental:** One module at a time
- **Compilable:** Maintain buildable state after every change
- **Tested:** Verify routes work after each extraction
- **Documented:** Update BACKEND_PROGRESS.md after each phase

### Critical Path
```
Database Password → Connection Test → Core Classes → 
Models → Repositories → Security Utils → Services → 
Controllers → Middleware → Integration → Testing
```

---

## 13. CONCLUSION

**Status:** READY TO REFACTOR (after database connection fix)

**Framework:** Crow (correct, do not change)

**Build:** ✅ Working

**Blocker:** PostgreSQL password authentication

**Approach:** Incremental extraction from monolithic main.cpp

**Risk:** MEDIUM (careful testing required)

**Estimated Phases:** 10 phases over 8-12 hours

**Next Step:** Configure database password, then begin PHASE 2

---

**Audit Completed:** 2024-11-17  
**Sign-off:** Senior C++ Backend Architect
