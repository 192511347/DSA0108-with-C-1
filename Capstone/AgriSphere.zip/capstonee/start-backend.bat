@echo off
echo ========================================
echo AgriSphere Backend Server
echo ========================================
echo.
echo Starting C++ Crow backend on port 6001...
echo.

cd backend
if not exist build\Release\AgriSphere.exe (
    echo ERROR: Backend executable not found!
    echo Please build the backend first with CMake
    pause
    exit /b 1
)

echo Backend starting...
echo Press Ctrl+C to stop
echo.
.\build\Release\AgriSphere.exe

pause
