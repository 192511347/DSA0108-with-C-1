# Test AgriSphere Backend Endpoints
Write-Host "`n=== AgriSphere Backend Tests ===" -ForegroundColor Cyan

$baseUrl = "http://localhost:6001"

# Test 1: Health Check
Write-Host "`n1. Testing Health Endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$baseUrl/api/v1/health" -Method GET -UseBasicParsing
    Write-Host "   Status: $($response.StatusCode)" -ForegroundColor Green
    $json = $response.Content | ConvertFrom-Json
    Write-Host "   Database: $($json.data.database)" -ForegroundColor Green
} catch {
    Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: Get Products
Write-Host "`n2. Testing Products Endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$baseUrl/api/v1/products?page=1&pageSize=5" -Method GET -UseBasicParsing
    Write-Host "   Status: $($response.StatusCode)" -ForegroundColor Green
    $json = $response.Content | ConvertFrom-Json
    Write-Host "   Success: $($json.success)" -ForegroundColor Green
    Write-Host "   Products Count: $($json.data.products.Count)" -ForegroundColor Green
    Write-Host "   Total Items: $($json.data.pagination.totalItems)" -ForegroundColor Green
    if ($json.data.products.Count -gt 0) {
        Write-Host "   First Product: $($json.data.products[0].name)" -ForegroundColor Green
    }
} catch {
    Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "   Response: $($_.Exception.Response)" -ForegroundColor Red
}

# Test 3: Register New User
Write-Host "`n3. Testing Register Endpoint..." -ForegroundColor Yellow
$timestamp = Get-Date -Format "yyyyMMddHHmmss"
$registerData = @{
    email = "testuser$timestamp@example.com"
    password = "TestPass123!"
    fullName = "Test User $timestamp"
    phone = "+1234567890"
    role = "BUYER"
    district = "Test District"
    state = "Test State"
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "$baseUrl/api/v1/auth/register" -Method POST -Body $registerData -ContentType "application/json" -UseBasicParsing
    Write-Host "   Status: $($response.StatusCode)" -ForegroundColor Green
    $json = $response.Content | ConvertFrom-Json
    Write-Host "   Success: $($json.success)" -ForegroundColor Green
    Write-Host "   User Email: $($json.data.user.email)" -ForegroundColor Green
    Write-Host "   Has Token: $(if ($json.data.tokens.accessToken) { 'Yes' } else { 'No' })" -ForegroundColor Green
    
    # Save for login test
    $global:testEmail = $json.data.user.email
    $global:testPassword = "TestPass123!"
} catch {
    Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 4: Login
Write-Host "`n4. Testing Login Endpoint..." -ForegroundColor Yellow
if ($global:testEmail) {
    $loginData = @{
        email = $global:testEmail
        password = $global:testPassword
    } | ConvertTo-Json

    try {
        $response = Invoke-WebRequest -Uri "$baseUrl/api/v1/auth/login" -Method POST -Body $loginData -ContentType "application/json" -UseBasicParsing
        Write-Host "   Status: $($response.StatusCode)" -ForegroundColor Green
        $json = $response.Content | ConvertFrom-Json
        Write-Host "   Success: $($json.success)" -ForegroundColor Green
        Write-Host "   User Email: $($json.data.user.email)" -ForegroundColor Green
        Write-Host "   Token Length: $($json.data.tokens.accessToken.Length)" -ForegroundColor Green
        
        $global:accessToken = $json.data.tokens.accessToken
    } catch {
        Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "   SKIPPED: No test user created" -ForegroundColor Yellow
}

# Test 5: Get Cart (requires auth)
Write-Host "`n5. Testing Cart Endpoint (Authenticated)..." -ForegroundColor Yellow
if ($global:accessToken) {
    try {
        $headers = @{
            "Authorization" = "Bearer $global:accessToken"
        }
        $response = Invoke-WebRequest -Uri "$baseUrl/api/v1/cart" -Method GET -Headers $headers -UseBasicParsing
        Write-Host "   Status: $($response.StatusCode)" -ForegroundColor Green
        $json = $response.Content | ConvertFrom-Json
        Write-Host "   Success: $($json.success)" -ForegroundColor Green
        Write-Host "   Cart Items: $($json.data.cart.items.Count)" -ForegroundColor Green
        Write-Host "   Total Amount: $($json.data.cart.totalAmount)" -ForegroundColor Green
    } catch {
        Write-Host "   FAILED: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "   SKIPPED: No auth token available" -ForegroundColor Yellow
}

Write-Host "`n=== Tests Complete ===" -ForegroundColor Cyan
