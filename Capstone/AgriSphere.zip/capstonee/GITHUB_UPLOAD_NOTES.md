# AgriSphere — GitHub source package

This ZIP contains project source without node_modules, compiled binaries, build folders, git history, backups and local secret `.env` files.

## Setup
1. Install the project dependencies using `npm install` in `frontend/`.
2. Install Crow and PostgreSQL driver dependencies, then configure/build the C++ project using its CMake files and vcpkg.
3. Copy `.env.example` files to local `.env` files and supply your own credentials. Do not commit secrets.
4. Initialize PostgreSQL with the project SQL migrations and test the backend before connecting the frontend.

**Important:** This source-only archive does not contain an installed/working runtime.
If you have previously exposed your Gemini API key, revoke and rotate it before publishing the repository.
