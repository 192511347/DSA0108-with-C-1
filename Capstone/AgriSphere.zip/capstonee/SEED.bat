@echo off
title Seed Database
color 0E

echo ========================================
echo   Seeding AgriSphere Database
echo ========================================
echo.

REM Check if C++ backend is running (Docker container)
echo Checking C++ backend...
wsl -d Ubuntu bash -c "curl -s http://localhost:6001/api/v1/health" >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] C++ Backend is not running!
    echo.
    echo Please start C++ backend first:
    echo   START.bat
    echo.
    echo Or manually in WSL2:
    echo   wsl
    echo   cd /mnt/c/Users/Mohan/Downloads/capstonee/backend
    echo   docker-compose up -d
    echo.
    pause
    exit /b 1
)

echo [OK] C++ Backend is running
echo.

echo ========================================
echo   C++ BACKEND SEEDING NOT IMPLEMENTED
echo ========================================
echo.
echo The C++ backend uses its own seeding mechanism.
echo.
echo To seed the database, run:
echo   wsl
echo   cd /mnt/c/Users/Mohan/Downloads/capstonee/backend
echo   docker-compose exec backend /bin/bash
echo   # Inside container:
echo   ./seeds/seed-demo-data.sh
echo.
pause
