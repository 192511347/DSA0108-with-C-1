/**
 * AgriSphere Products E2E Tests
 * Tests product listing, filtering, and cart operations
 */

import { test, expect } from '@playwright/test';

const FRONTEND_URL = 'http://localhost:5000';

test.describe('Product Marketplace', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${FRONTEND_URL}/products`);
  });

  test('should display products page', async ({ page }) => {
    await expect(page.locator('h1, h2')).toContainText(/Products|Marketplace/i);
  });

  test('should load and display products', async ({ page }) => {
    // Wait for products to load
    await page.waitForSelector('[data-testid="product-card"], .product-card, article', { timeout: 10000 });
    
    // Should have at least one product
    const productCards = await page.locator('[data-testid="product-card"], .product-card, article').count();
    expect(productCards).toBeGreaterThan(0);
  });

  test('should filter products by category', async ({ page }) => {
    // Wait for products to load
    await page.waitForSelector('[data-testid="product-card"], .product-card, article', { timeout: 10000 });
    
    // Try to click a category filter
    const categories = ['Seeds', 'Fertilizers', 'Tools', 'Vegetables', 'Grains'];
    
    for (const category of categories) {
      const categoryButton = page.locator(`button:has-text("${category}")`);
      if (await categoryButton.isVisible()) {
        await categoryButton.click();
        
        // Wait for filter to apply
        await page.waitForTimeout(1000);
        
        // Products should still be visible
        const filteredProducts = await page.locator('[data-testid="product-card"], .product-card, article').count();
        expect(filteredProducts).toBeGreaterThan(0);
        
        break; // Test one category
      }
    }
  });

  test('should search for products', async ({ page }) => {
    // Look for search input
    const searchInput = page.locator('input[type="search"], input[placeholder*="Search"]');
    
    if (await searchInput.isVisible()) {
      await searchInput.fill('rice');
      await page.waitForTimeout(1000);
      
      // Should show filtered results
      const results = await page.locator('[data-testid="product-card"], .product-card, article').count();
      expect(results).toBeGreaterThanOrEqual(0);
    }
  });

  test('should view product details', async ({ page }) => {
    // Wait for products
    await page.waitForSelector('[data-testid="product-card"], .product-card, article', { timeout: 10000 });
    
    // Click first product
    const firstProduct = page.locator('[data-testid="product-card"], .product-card, article').first();
    await firstProduct.click();
    
    // Should navigate to product detail page
    await expect(page).toHaveURL(/\/products\/\d+/);
    
    // Should show product details
    await expect(page.locator('h1')).toBeVisible();
  });
});

test.describe('Cart Operations', () => {
  test.beforeEach(async ({ page }) => {
    // Login as buyer first
    await page.goto(`${FRONTEND_URL}/login`);
    await page.fill('input[type="email"]', 'buyer@agrisphere.in');
    await page.fill('input[type="password"]', 'Buyer@DemoOnly2024');
    await page.click('button[type="submit"]');
    await page.waitForURL(/\/dashboard/);
    
    // Navigate to products
    await page.goto(`${FRONTEND_URL}/products`);
  });

  test('should add product to cart', async ({ page }) => {
    // Wait for products
    await page.waitForSelector('[data-testid="product-card"], .product-card, article', { timeout: 10000 });
    
    // Click first product
    const firstProduct = page.locator('[data-testid="product-card"], .product-card, article').first();
    await firstProduct.click();
    
    // Click Add to Cart button
    const addToCartButton = page.locator('button:has-text("Add to Cart")');
    if (await addToCartButton.isVisible()) {
      await addToCartButton.click();
      
      // Should show success message
      await expect(page.locator('text=/Added|Success/i')).toBeVisible({ timeout: 5000 });
    }
  });

  test('should view cart', async ({ page }) => {
    // Navigate to cart
    await page.goto(`${FRONTEND_URL}/cart`);
    
    // Should show cart page
    await expect(page.locator('h1, h2')).toContainText(/Cart|Shopping Cart/i);
  });
});
