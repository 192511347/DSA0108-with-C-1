/**
 * AgriSphere E2E Test Setup
 * Verifies that both frontend and backend are running before tests execute
 */

import { test, expect } from '@playwright/test';

const FRONTEND_URL = 'http://localhost:5000';
const BACKEND_URL = 'http://localhost:6001';

test.describe('Environment Setup', () => {
  test('frontend should be accessible', async ({ page }) => {
    await page.goto(FRONTEND_URL);
    await expect(page).toHaveTitle(/AgriSphere/i);
  });

  test('backend health check should pass', async ({ request }) => {
    const response = await request.get(`${BACKEND_URL}/api/v1/health`);
    expect(response.ok()).toBeTruthy();
    
    const data = await response.json();
    expect(data.status).toBe('healthy');
  });

  test('backend should have database connected', async ({ request }) => {
    const response = await request.get(`${BACKEND_URL}/api/v1/health/status`);
    expect(response.ok()).toBeTruthy();
    
    const data = await response.json();
    expect(data.database).toBe('connected');
  });
});
