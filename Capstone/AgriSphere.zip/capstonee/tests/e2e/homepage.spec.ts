/**
 * AgriSphere Homepage E2E Tests
 * Tests all homepage buttons and navigation
 */

import { test, expect } from '@playwright/test';

const FRONTEND_URL = 'http://localhost:5000';

test.describe('Homepage Navigation', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(FRONTEND_URL);
  });

  test('should display homepage with hero section', async ({ page }) => {
    // Check hero heading
    await expect(page.locator('h1')).toContainText(/AgriSphere|Empowering/i);
    
    // Check tagline
    await expect(page.locator('text=/Digital ecosystem/i')).toBeVisible();
  });

  test('Browse Products button should navigate to marketplace', async ({ page }) => {
    // Click Browse Products button
    await page.click('text=/Browse Products/i');
    
    // Should navigate to products page
    await expect(page).toHaveURL(/\/products/);
    
    // Should show products page
    await expect(page.locator('h1, h2')).toContainText(/Products|Marketplace/i);
  });

  test('Find Services button should navigate to services', async ({ page }) => {
    // Click Find Services button
    await page.click('text=/Find Services/i');
    
    // Should navigate to services page
    await expect(page).toHaveURL(/\/services/);
  });

  test('Get Started button should navigate to registration', async ({ page }) => {
    // Click Get Started button
    const getStartedButton = page.locator('text=/Get Started/i').first();
    await getStartedButton.click();
    
    // Should navigate to register page
    await expect(page).toHaveURL(/\/register/);
  });

  test('Login button should navigate to login page', async ({ page }) => {
    // Click Login button in header
    await page.click('text=/Login|Sign In/i');
    
    // Should navigate to login page
    await expect(page).toHaveURL(/\/login/);
  });

  test('should display feature cards', async ({ page }) => {
    // Check for feature sections
    const features = [
      /Quality Products/i,
      /Expert Services/i,
      /Farm Experts/i,
      /Secure/i
    ];
    
    for (const feature of features) {
      await expect(page.locator(`text=${feature}`)).toBeVisible();
    }
  });

  test('navigation menu should work', async ({ page }) => {
    // Test Products link
    await page.click('nav >> text=/Products/i');
    await expect(page).toHaveURL(/\/products/);
    
    // Go back home
    await page.goto(FRONTEND_URL);
    
    // Test Services link
    await page.click('nav >> text=/Services/i');
    await expect(page).toHaveURL(/\/services/);
  });
});
