/**
 * AgriSphere Product Creation E2E Tests
 * Tests product listing form for farmers/sellers
 */

import { test, expect } from '@playwright/test';

const FRONTEND_URL = 'http://localhost:5000';

test.describe('Product Creation', () => {
  test.beforeEach(async ({ page }) => {
    // Login as farmer
    await page.goto(`${FRONTEND_URL}/login`);
    await page.fill('input[type="email"]', 'farmer@agrisphere.in');
    await page.fill('input[type="password"]', 'Farmer@DemoOnly2024');
    await page.click('button[type="submit"]');
    await page.waitForURL(/\/dashboard/);
    
    // Navigate to product creation
    await page.goto(`${FRONTEND_URL}/products/create`);
  });

  test('should display product creation form', async ({ page }) => {
    await expect(page.locator('h1')).toContainText(/List|Create|Add.*Product/i);
    
    // Should have all form fields
    await expect(page.locator('input[name="name"], input[placeholder*="Product Name"]')).toBeVisible();
    await expect(page.locator('select[name="category"], select')).toBeVisible();
    await expect(page.locator('textarea[name="description"]')).toBeVisible();
    await expect(page.locator('input[name="price"]')).toBeVisible();
    await expect(page.locator('input[name="quantity"]')).toBeVisible();
  });

  test('should show validation errors for empty form', async ({ page }) => {
    // Try to submit empty form
    const submitButton = page.locator('button[type="submit"]');
    await submitButton.click();
    
    // Should show validation errors
    await expect(page.locator('text=/required|Please fill/i')).toBeVisible({ timeout: 3000 });
  });

  test('should create product successfully', async ({ page }) => {
    // Fill in the form
    await page.fill('input[name="name"], input[placeholder*="Product Name"]', 'Test Rice Product');
    
    // Select category
    const categorySelect = page.locator('select[name="category"], select').first();
    await categorySelect.selectOption('grains');
    
    // Fill description
    await page.fill('textarea[name="description"]', 'This is a test rice product for E2E testing');
    
    // Fill price
    await page.fill('input[name="price"]', '500');
    
    // Fill quantity
    await page.fill('input[name="quantity"]', '100');
    
    // Fill unit
    const unitInput = page.locator('input[name="unit"], input[placeholder*="unit"]');
    if (await unitInput.isVisible()) {
      await unitInput.fill('kg');
    }
    
    // Fill location
    const locationInput = page.locator('input[name="location"]');
    if (await locationInput.isVisible()) {
      await locationInput.fill('Mumbai');
    }
    
    // Submit form
    await page.click('button[type="submit"]');
    
    // Should show success message or redirect
    await page.waitForTimeout(2000);
    
    // Check for success
    const successMessage = page.locator('text=/Success|Created|Listed/i');
    const urlChanged = page.url() !== `${FRONTEND_URL}/products/create`;
    
    expect(await successMessage.isVisible() || urlChanged).toBeTruthy();
  });
});
