/**
 * AgriSphere Authentication E2E Tests
 * Tests login functionality with all demo user roles
 */

import { test, expect } from '@playwright/test';

const FRONTEND_URL = 'http://localhost:5000';

const DEMO_USERS = [
  {
    email: 'farmer@agrisphere.in',
    password: 'Farmer@DemoOnly2024',
    role: 'farmer',
    name: 'Ramesh Kumar'
  },
  {
    email: 'buyer@agrisphere.in',
    password: 'Buyer@DemoOnly2024',
    role: 'buyer',
    name: 'Priya Sharma'
  },
  {
    email: 'seller@agrisphere.in',
    password: 'Seller@DemoOnly2024',
    role: 'seller',
    name: 'Arun Patel'
  },
  {
    email: 'provider@agrisphere.in',
    password: 'Provider@DemoOnly2024',
    role: 'provider',
    name: 'Lakshmi Nair'
  },
  {
    email: 'admin@agrisphere.in',
    password: 'Admin@DemoOnly2024',
    role: 'admin',
    name: 'Suresh Reddy'
  }
];

test.describe('Authentication', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${FRONTEND_URL}/login`);
  });

  test('login page should display correctly', async ({ page }) => {
    await expect(page.locator('h1, h2')).toContainText(/Login|Sign In/i);
    await expect(page.locator('input[type="email"]')).toBeVisible();
    await expect(page.locator('input[type="password"]')).toBeVisible();
    await expect(page.locator('button[type="submit"]')).toBeVisible();
  });

  for (const user of DEMO_USERS) {
    test(`should login successfully as ${user.role}`, async ({ page }) => {
      // Fill in credentials
      await page.fill('input[type="email"]', user.email);
      await page.fill('input[type="password"]', user.password);
      
      // Click login button
      await page.click('button[type="submit"]');
      
      // Wait for navigation
      await page.waitForURL(/\/dashboard/, { timeout: 10000 });
      
      // Should redirect to appropriate dashboard
      expect(page.url()).toContain('/dashboard');
      
      // Should show user name or welcome message
      await expect(page.locator(`text=/${user.name}|Welcome/i`)).toBeVisible({ timeout: 5000 });
    });
  }

  test('should show error for invalid credentials', async ({ page }) => {
    await page.fill('input[type="email"]', 'invalid@test.com');
    await page.fill('input[type="password"]', 'wrongpassword');
    await page.click('button[type="submit"]');
    
    // Should show error message
    await expect(page.locator('text=/Invalid|Error|Failed/i')).toBeVisible({ timeout: 5000 });
  });

  test('should navigate to registration page', async ({ page }) => {
    await page.click('text=/Sign Up|Register|Create Account/i');
    await expect(page).toHaveURL(/\/register/);
  });
});

test.describe('Logout', () => {
  test('should logout successfully', async ({ page }) => {
    // Login first
    await page.goto(`${FRONTEND_URL}/login`);
    await page.fill('input[type="email"]', DEMO_USERS[0].email);
    await page.fill('input[type="password"]', DEMO_USERS[0].password);
    await page.click('button[type="submit"]');
    
    await page.waitForURL(/\/dashboard/);
    
    // Click logout
    await page.click('text=/Logout|Sign Out/i');
    
    // Should redirect to home or login
    await expect(page).toHaveURL(/\/(login)?$/);
  });
});
