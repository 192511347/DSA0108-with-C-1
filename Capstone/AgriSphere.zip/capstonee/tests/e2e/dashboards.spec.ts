/**
 * AgriSphere Dashboard E2E Tests
 * Tests all role-specific dashboards
 */

import { test, expect } from '@playwright/test';

const FRONTEND_URL = 'http://localhost:5000';

const ROLES = [
  { email: 'farmer@agrisphere.in', password: 'Farmer@DemoOnly2024', role: 'farmer' },
  { email: 'buyer@agrisphere.in', password: 'Buyer@DemoOnly2024', role: 'buyer' },
  { email: 'seller@agrisphere.in', password: 'Seller@DemoOnly2024', role: 'seller' },
  { email: 'provider@agrisphere.in', password: 'Provider@DemoOnly2024', role: 'provider' },
  { email: 'admin@agrisphere.in', password: 'Admin@DemoOnly2024', role: 'admin' }
];

test.describe('Dashboard Access', () => {
  for (const user of ROLES) {
    test(`should access ${user.role} dashboard`, async ({ page }) => {
      // Login
      await page.goto(`${FRONTEND_URL}/login`);
      await page.fill('input[type="email"]', user.email);
      await page.fill('input[type="password"]', user.password);
      await page.click('button[type="submit"]');
      
      // Wait for dashboard
      await page.waitForURL(/\/dashboard/, { timeout: 10000 });
      
      // Should show dashboard
      await expect(page.locator('h1, h2')).toContainText(/Dashboard|Welcome/i);
      
      // Should show stats or widgets
      const statsCards = await page.locator('[data-testid="stat-card"], .stat-card, .stats').count();
      expect(statsCards).toBeGreaterThan(0);
    });
  }
});

test.describe('Farmer Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${FRONTEND_URL}/login`);
    await page.fill('input[type="email"]', 'farmer@agrisphere.in');
    await page.fill('input[type="password"]', 'Farmer@DemoOnly2024');
    await page.click('button[type="submit"]');
    await page.waitForURL(/\/dashboard/);
  });

  test('should display farmer statistics', async ({ page }) => {
    // Should show crop stats
    await expect(page.locator('text=/Active Crops|Total Income|Orders/i')).toBeVisible();
  });

  test('should navigate to list product', async ({ page }) => {
    const listProductButton = page.locator('button:has-text("List Product"), a:has-text("List Product")');
    if (await listProductButton.isVisible()) {
      await listProductButton.click();
      await expect(page).toHaveURL(/\/products\/create/);
    }
  });
});

test.describe('Seller Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${FRONTEND_URL}/login`);
    await page.fill('input[type="email"]', 'seller@agrisphere.in');
    await page.fill('input[type="password"]', 'Seller@DemoOnly2024');
    await page.click('button[type="submit"]');
    await page.waitForURL(/\/dashboard/);
  });

  test('should display sales statistics', async ({ page }) => {
    await expect(page.locator('text=/Total Sales|Products Listed|Revenue/i')).toBeVisible();
  });

  test('should show product listings', async ({ page }) => {
    await expect(page.locator('text=/My Products|Product Listings/i')).toBeVisible();
  });
});

test.describe('Provider Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${FRONTEND_URL}/login`);
    await page.fill('input[type="email"]', 'provider@agrisphere.in');
    await page.fill('input[type="password"]', 'Provider@DemoOnly2024');
    await page.click('button[type="submit"]');
    await page.waitForURL(/\/dashboard/);
  });

  test('should display service statistics', async ({ page }) => {
    await expect(page.locator('text=/Bookings|Services|Clients/i')).toBeVisible();
  });

  test('should show booking requests', async ({ page }) => {
    await expect(page.locator('text=/Pending Requests|Bookings/i')).toBeVisible();
  });
});

test.describe('Admin Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${FRONTEND_URL}/login`);
    await page.fill('input[type="email"]', 'admin@agrisphere.in');
    await page.fill('input[type="password"]', 'Admin@DemoOnly2024');
    await page.click('button[type="submit"]');
    await page.waitForURL(/\/dashboard/);
  });

  test('should display system health', async ({ page }) => {
    await expect(page.locator('text=/System Health|Platform Health/i')).toBeVisible();
  });

  test('should show pending approvals', async ({ page }) => {
    await expect(page.locator('text=/Pending Approvals|Approvals/i')).toBeVisible();
  });

  test('should show activity feed', async ({ page }) => {
    await expect(page.locator('text=/Recent Activity|Activity Feed/i')).toBeVisible();
  });
});
