# AgriSphere - Running the Application

## Quick Start

### Prerequisites
- PostgreSQL 18+ (running on port 5432)
- Node.js 20+ (for frontend only)
- Visual Studio 2026 BuildTools with MSVC
- vcpkg installed at `C:\dev\vcpkg`

### 1. Start PostgreSQL Database
Ensure PostgreSQL service is running:
```powershell
Get-Service postgresql-x64-18
```

### 2. Start C++ Backend
```powershell
cd backend\build
.\Release\AgriSphere.exe
```
Backend will run on **http://localhost:6001**

### 3. Start Frontend (in new terminal)
```powershell
cd frontend
npm run dev
```
Frontend will run on **http://localhost:5000**

### 4. Access Application
Open browser: **http://localhost:5000**

---

## Building the Backend

If you need to rebuild the C++ backend:

```powershell
cd backend
Remove-Item -Recurse -Force build
New-Item -ItemType Directory -Path build
cd build
cmake .. -DCMAKE_TOOLCHAIN_FILE=C:/dev/vcpkg/scripts/buildsystems/vcpkg.cmake -DCMAKE_BUILD_TYPE=Release
cmake --build . --config Release
```

---

## Technology Stack

| Component | Technology |
|-----------|-----------|
| Frontend | Next.js 14 + TypeScript + TailwindCSS |
| Backend | C++20 + Crow HTTP Framework |
| Database | PostgreSQL 18 |
| Authentication | JWT (pending implementation) |
| Password Hashing | Argon2id (pending implementation) |

---

## API Endpoints (Port 6001)

### Health
- `GET /api/v1/health` - Health check

### Authentication
- `POST /api/v1/auth/register` - User registration
- `POST /api/v1/auth/login` - User login

### Products
- `GET /api/v1/products` - List products with pagination
- `GET /api/v1/products/:id` - Get single product
- `POST /api/v1/products` - Create product (seller only)

### Cart
- `GET /api/v1/cart` - Get user's cart
- `POST /api/v1/cart/items` - Add item to cart

**Note:** All endpoints currently return stub data. Database integration is pending.

---

## Configuration

### Backend Environment (.env in backend/)
```
SERVER_PORT=6001
CORS_ORIGIN=http://localhost:5000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=agrisphere
DB_USER=postgres
DB_PASSWORD=<your-password>
JWT_SECRET=<your-jwt-secret>
```

### Frontend Environment (.env.local in frontend/)
```
NEXT_PUBLIC_API_URL=http://localhost:6001/api/v1
```

---

## Project Structure

```
capstonee/
├── backend/               # C++ Crow backend
│   ├── src/
│   │   └── main.cpp      # HTTP server + routes
│   ├── build/            # CMake build directory
│   ├── CMakeLists.txt    # Build configuration
│   └── .env              # Backend config
├── frontend/             # Next.js frontend
│   ├── src/
│   │   ├── app/         # App router pages
│   │   ├── components/  # React components
│   │   └── lib/         # Utilities + API client
│   └── package.json
├── change/              # Product images
├── docs/                # Documentation
└── tests/               # E2E tests
```

---

## Development Status

✅ **Completed:**
- Windows-native C++ backend with Crow framework
- All API endpoint stubs matching frontend contracts
- CORS configuration
- CMake build system with vcpkg integration
- Frontend Next.js application
- PostgreSQL database schema

🚧 **Pending:**
- PostgreSQL integration (libpq queries)
- JWT authentication implementation
- Password hashing (bcrypt/argon2)
- Real database queries replacing stub responses
- File upload for product images
- Payment integration
- Admin dashboard

---

## Troubleshooting

### Backend won't start
- Check if port 6001 is available
- Verify vcpkg dependencies are installed
- Check PostgreSQL is running

### Frontend can't connect to backend
- Ensure backend is running on port 6001
- Check CORS configuration in backend .env
- Verify API_URL in frontend .env.local

### Build errors
- Ensure Visual Studio 2026 BuildTools installed
- Verify vcpkg toolchain path in CMakeLists.txt
- Check all dependencies installed via vcpkg

---

## Database Seeding

Seed the database with sample data:
```powershell
.\SEED.bat
```

---

## Testing

Run E2E tests:
```powershell
.\TESTS.bat
```

---

## Contributing

1. Never modify frontend architecture
2. C++ backend is the authoritative implementation
3. Port 6001 is hardcoded - do not change
4. All changes must preserve existing API contracts
5. Test locally before committing
