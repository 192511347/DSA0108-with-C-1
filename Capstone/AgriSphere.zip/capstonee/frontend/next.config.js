/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  
  // Enable standalone output for Docker deployments
  output: 'standalone',
  
  // Environment variables
  env: {
    NEXT_PUBLIC_API_URL: '/backend-api',
  },
  
  // Image optimization
  images: {
    domains: ['localhost'],
    formats: ['image/avif', 'image/webp'],
  },
  
  // Security headers
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          {
            key: 'X-DNS-Prefetch-Control',
            value: 'on'
          },
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=63072000; includeSubDomains; preload'
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff'
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY'
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block'
          },
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin'
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()'
          }
        ],
      },
    ]
  },
  
  async rewrites() {
    return [{ source: '/backend-api/:path*', destination: 'http://127.0.0.1:6001/api/v1/:path*' }]
  },
  // Compression
  compress: true,
  
  // Performance optimizations
  swcMinify: true,
  
  // Production source maps (disable for security)
  productionBrowserSourceMaps: false,
}

module.exports = nextConfig
