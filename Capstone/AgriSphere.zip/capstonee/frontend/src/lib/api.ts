/**
 * API Client for AgriSphere Backend
 */

import axios, { AxiosError } from 'axios';

const API_URL = '/backend-api';

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('accessToken');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle token refresh
api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as any;
    
    // If error is 401 and we haven't retried yet
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        const refreshToken = localStorage.getItem('refreshToken');
        if (refreshToken) {
          const response = await axios.post(`${API_URL}/auth/refresh`, {
            refreshToken,
          });
          
          const accessToken = response.data.data?.tokens?.accessToken ?? response.data.data?.accessToken;
          if (!accessToken) throw new Error("Refresh response missing access token");
          localStorage.setItem('accessToken', accessToken);
          
          // Retry original request with new token
          originalRequest.headers.Authorization = `Bearer ${accessToken}`;
          return api(originalRequest);
        }
      } catch (refreshError) {
        // Refresh failed, logout user
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }
    
    return Promise.reject(error);
  }
);

// API Response types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    fields?: Record<string, string>;
  };
}

// Auth API
export const authApi = {
  register: (data: {
    email: string;
    password: string;
    fullName: string;
    phone: string;
    role: string;
    district?: string;
    state?: string;
  }) => api.post<ApiResponse<any>>('/auth/register', data),
  
  login: (data: { email: string; password: string }) =>
    api.post<ApiResponse<any>>('/auth/login', data),
  
  logout: (refreshToken: string) =>
    api.post<ApiResponse<any>>('/auth/logout', { refreshToken }),
  
  me: () => api.get<ApiResponse<any>>('/auth/me'),
  
  updateProfile: (data: any) =>
    api.put<ApiResponse<any>>('/auth/profile', data),
};

// Product API
export const productApi = {
  list: (params?: {
    search?: string;
    category?: string;
    district?: string;
    state?: string;
    minPrice?: number;
    maxPrice?: number;
    page?: number;
    pageSize?: number;
  }) => api.get<ApiResponse<any>>('/products', { params }),
  
  listCategories: () => api.get<ApiResponse<any>>('/products/categories'),
  
  getById: (id: string) => api.get<ApiResponse<any>>(`/products/${id}`),
  
  createProduct: (data: {
    name: string;
    description: string;
    category: string;
    price: number;
    quantity: number;
    unit: string;
    imageUrl?: string;
  }) => api.post<ApiResponse<any>>('/products', {
    name: data.name,
    description: data.description,
    category: data.category,
    pricePerUnit: Math.round(data.price * 100), // Convert to paise
    unit: data.unit,
    availableQuantity: data.quantity,
    images: data.imageUrl ? [data.imageUrl] : []
  }),
  
  getMyProducts: () => api.get<ApiResponse<any>>('/products/my/listings'),
};

// Category API
export const categoryApi = {
  list: () => api.get<ApiResponse<any>>('/products/categories'),
};

// Cart API
export const cartApi = {
  get: () => api.get<ApiResponse<any>>('/cart'),
  getCart: () => api.get<ApiResponse<any>>('/cart'),
  
  addItem: (data: { productId: string; quantity: number }) =>
    api.post<ApiResponse<any>>('/cart/items', data),
  
  updateItem: (itemId: string, data: { quantity: number }) =>
    api.put<ApiResponse<any>>(`/cart/items/${itemId}`, data),
  
  removeItem: (itemId: string) =>
    api.delete<ApiResponse<any>>(`/cart/items/${itemId}`),
  
  clear: () => api.delete<ApiResponse<any>>('/cart'),
};

// Service API (Mock for now - backend not implemented)
export const serviceApi = {
  list: () => Promise.resolve({
    data: {
      success: true,
      data: []
    }
  }),
  
  getById: (id: string) => Promise.resolve({
    data: {
      success: true,
      data: null
    }
  }),
};

export default api;
