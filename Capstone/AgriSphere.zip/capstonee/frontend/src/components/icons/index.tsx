// AgriSphere Icon System
// All icons from lucide-react with consistent sizing and styling

import {
  Sprout,
  ShoppingCart,
  Store,
  Wrench,
  User,
  Package,
  Home,
  Search,
  Star,
  Heart,
  MapPin,
  Phone,
  Mail,
  Calendar,
  Clock,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  XCircle,
  Info,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  Menu,
  X,
  Settings,
  LogOut,
  Edit,
  Trash2,
  Plus,
  Minus,
  Filter,
  Download,
  Upload,
  Eye,
  EyeOff,
  Bell,
  MessageCircle,
  Share2,
  ExternalLink,
  ArrowRight,
  ArrowLeft,
  MoreHorizontal,
  MoreVertical,
  Truck,
  CreditCard,
  Leaf,
  Tractor,
  Droplet,
  Sun,
  Cloud,
  Zap,
  Target,
  BarChart3,
  PieChart,
  DollarSign,
  Tag,
  ShoppingBag,
  Bookmark,
  FileText,
  Image as ImageIcon,
  Video,
  Mic,
  Send,
  RefreshCw,
  Copy,
  Check,
  AlertTriangle,
  HelpCircle,
  Shield,
  Lock,
  Unlock,
  Globe,
  Briefcase,
  Users,
  UserPlus,
  UserCheck,
  Building,
  Navigation,
  Compass,
  Map,
} from 'lucide-react'

// Common icon props
export interface IconProps {
  className?: string
  size?: number
}

// Role Icons
export const FarmerIcon = Sprout
export const BuyerIcon = ShoppingCart
export const SellerIcon = Store
export const ServiceProviderIcon = Wrench
export const AdminIcon = Shield

// Navigation Icons
export const HomeIcon = Home
export const SearchIcon = Search
export const CartIcon = ShoppingCart
export const UserIcon = User
export const PackageIcon = Package
export const MenuIcon = Menu
export const CloseIcon = X

// Action Icons
export const EditIcon = Edit
export const DeleteIcon = Trash2
export const AddIcon = Plus
export const RemoveIcon = Minus
export const SaveIcon = Check
export const CancelIcon = X
export const UploadIcon = Upload
export const DownloadIcon = Download
export const ShareIcon = Share2
export const SendIcon = Send
export const CopyIcon = Copy
export const RefreshIcon = RefreshCw

// Status Icons
export const SuccessIcon = CheckCircle
export const ErrorIcon = XCircle
export const WarningIcon = AlertTriangle
export const InfoIcon = Info
export const HelpIcon = HelpCircle

// UI Icons
export const StarIcon = Star
export const HeartIcon = Heart
export const BellIcon = Bell
export const SettingsIcon = Settings
export const LogOutIcon = LogOut
export const MoreIcon = MoreHorizontal
export const MoreVerticalIcon = MoreVertical
export const EyeIcon = Eye
export const EyeOffIcon = EyeOff
export const FilterIcon = Filter
export const BookmarkIcon = Bookmark

// Chevron Icons
export const ChevronRightIcon = ChevronRight
export const ChevronLeftIcon = ChevronLeft
export const ChevronDownIcon = ChevronDown
export const ChevronUpIcon = ChevronUp
export const ArrowRightIcon = ArrowRight
export const ArrowLeftIcon = ArrowLeft

// Communication Icons
export const PhoneIcon = Phone
export const MailIcon = Mail
export const MessageIcon = MessageCircle
export const MicIcon = Mic

// Location Icons
export const MapPinIcon = MapPin
export const MapIcon = Map
export const NavigationIcon = Navigation
export const CompassIcon = Compass
export const GlobeIcon = Globe

// Time Icons
export const CalendarIcon = Calendar
export const ClockIcon = Clock

// Commerce Icons
export const TruckIcon = Truck
export const CreditCardIcon = CreditCard
export const DollarSignIcon = DollarSign
export const TagIcon = Tag
export const ShoppingBagIcon = ShoppingBag

// Data Icons
export const TrendingUpIcon = TrendingUp
export const BarChartIcon = BarChart3
export const PieChartIcon = PieChart
export const TargetIcon = Target

// Agricultural Icons
export const LeafIcon = Leaf
export const TractorIcon = Tractor
export const DropletIcon = Droplet
export const SunIcon = Sun
export const CloudIcon = Cloud
export const ZapIcon = Zap

// File Icons
export const FileTextIcon = FileText
export const ImageIcon2 = ImageIcon
export const VideoIcon = Video

// Organization Icons
export const BriefcaseIcon = Briefcase
export const UsersIcon = Users
export const UserPlusIcon = UserPlus
export const UserCheckIcon = UserCheck
export const BuildingIcon = Building

// Security Icons
export const LockIcon = Lock
export const UnlockIcon = Unlock
export const ShieldIcon2 = Shield

// External
export const ExternalLinkIcon = ExternalLink

// Utility function for consistent icon styling
export function getIconClasses(size: 'sm' | 'md' | 'lg' | 'xl' = 'md'): string {
  const sizes = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
    xl: 'w-8 h-8',
  }
  return sizes[size]
}

// Icon wrapper component for consistent styling
export function Icon({ 
  icon: IconComponent, 
  size = 'md',
  className = '' 
}: { 
  icon: React.ComponentType<any>
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}) {
  return <IconComponent className={`${getIconClasses(size)} ${className}`} />
}
