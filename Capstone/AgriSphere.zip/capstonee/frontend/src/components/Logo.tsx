import { Wheat } from 'lucide-react'
import Link from 'next/link'

interface LogoProps {
  size?: 'sm' | 'md' | 'lg'
  variant?: 'primary' | 'white' | 'dark'
  showText?: boolean
  className?: string
}

export default function Logo({ 
  size = 'md', 
  variant = 'primary', 
  showText = true,
  className = '' 
}: LogoProps) {
  const sizes = {
    sm: { box: 'w-8 h-8', icon: 'w-4 h-4', text: 'text-lg' },
    md: { box: 'w-10 h-10', icon: 'w-5 h-5', text: 'text-display-sm' },
    lg: { box: 'w-12 h-12', icon: 'w-6 h-6', text: 'text-display-md' }
  }

  const variants = {
    primary: {
      box: 'bg-primary-500 shadow-soft group-hover:shadow-soft-lg',
      icon: 'text-white',
      text: 'text-primary-700 group-hover:text-primary-600'
    },
    white: {
      box: 'bg-white shadow-soft group-hover:shadow-soft-lg',
      icon: 'text-primary-600',
      text: 'text-white'
    },
    dark: {
      box: 'bg-primary-800 shadow-soft group-hover:shadow-soft-lg',
      icon: 'text-accent-200',
      text: 'text-primary-800 group-hover:text-primary-700'
    }
  }

  const sizeClasses = sizes[size]
  const variantClasses = variants[variant]

  return (
    <Link href="/" className={`flex items-center gap-3 group ${className}`}>
      <div className={`${sizeClasses.box} ${variantClasses.box} rounded-xl flex items-center justify-center transition-all duration-200`}>
        <Wheat className={`${sizeClasses.icon} ${variantClasses.icon}`} />
      </div>
      {showText && (
        <span className={`font-display ${sizeClasses.text} ${variantClasses.text} transition-colors`}>
          AgriSphere
        </span>
      )}
    </Link>
  )
}
