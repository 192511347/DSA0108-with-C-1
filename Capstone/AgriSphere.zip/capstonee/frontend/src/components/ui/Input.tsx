import React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'

const inputVariants = cva(
  'input',
  {
    variants: {
      inputSize: {
        sm: 'input-sm',
        md: '',
        lg: 'input-lg',
      },
      error: {
        true: 'input-error',
        false: '',
      },
    },
    defaultVariants: {
      inputSize: 'md',
      error: false,
    },
  }
)

export interface InputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'>,
    VariantProps<typeof inputVariants> {
  label?: string
  helperText?: string
  errorText?: string
  leftIcon?: React.ReactNode
  rightIcon?: React.ReactNode
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, inputSize, error, label, helperText, errorText, leftIcon, rightIcon, ...props }, ref) => {
    const hasError = !!errorText || error

    return (
      <div className="w-full">
        {label && (
          <label className="block text-body-sm font-medium text-secondary-700 mb-1.5">
            {label}
            {props.required && <span className="text-error-500 ml-1">*</span>}
          </label>
        )}
        <div className="relative">
          {leftIcon && (
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-secondary-400">
              {leftIcon}
            </div>
          )}
          <input
            ref={ref}
            className={inputVariants({ 
              inputSize, 
              error: hasError,
              className: `${leftIcon ? 'pl-10' : ''} ${rightIcon ? 'pr-10' : ''} ${className}`
            })}
            {...props}
          />
          {rightIcon && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-secondary-400">
              {rightIcon}
            </div>
          )}
        </div>
        {(helperText || errorText) && (
          <p className={`mt-1.5 text-body-xs ${errorText ? 'text-error-600' : 'text-secondary-500'}`}>
            {errorText || helperText}
          </p>
        )}
      </div>
    )
  }
)

Input.displayName = 'Input'
