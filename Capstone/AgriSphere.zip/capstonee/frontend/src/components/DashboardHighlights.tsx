'use client'
import { useQuery } from '@tanstack/react-query'
import Link from 'next/link'
import { api } from '@/lib/api'
import { useAuth } from '@/contexts/AuthContext'

/** Only recorded database facts appear here; zero means no recorded events. */
export default function DashboardHighlights(){
 const {user}=useAuth()
 const {data,error}=useQuery({queryKey:['dashboard-highlights'],queryFn:async()=>{const r=await api.get('/dashboard/metrics');return r.data.data}})
 const {data:bookings}=useQuery({queryKey:['dashboard-service-requests'],queryFn:async()=>{const r=await api.get('/services/requests');return r.data.data?.requests||[]}})
 const {data:farm}=useQuery({queryKey:['dashboard-farm-profile'],queryFn:async()=>{const r=await api.get('/farm/profile');return r.data.data?.profile||{}},enabled:user?.role==='FARMER'})
 const m=data?.metrics||{};const chart=data?.chart||[];const max=Math.max(1,...chart.map((x:any)=>Number(x.views)||0))
 return <section className="mb-8 space-y-5">
  <div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-2xl font-bold text-primary-800">My Marketplace Overview</h2><p className="text-sm text-gray-600">Live database information · No estimated historical views</p></div><Link className="text-primary-700 underline font-semibold" href="/dashboard/insights">Full Analytics & Land Profile</Link></div>
  {error&&<p className="text-red-700">Dashboard metrics unavailable. Check backend and database.</p>}
  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{([['Product Views',m.views],['Demo Sales',m.sales],['Sales ₹',(Number(m.revenue||0)/100).toFixed(2)],['My Purchases',m.purchases]] as [string,any][]).map(([label,val])=><div key={label} className="bg-white rounded-xl border p-4"><p className="text-xs text-gray-600">{label}</p><p className="text-2xl font-bold text-primary-800">{val??'—'}</p></div>)}</div>
  <div className="grid md:grid-cols-2 gap-4"><div className="bg-white border rounded-xl p-5"><h3 className="font-bold mb-1">Views · past 7 days</h3><p className="text-xs text-gray-500 mb-3">Counts start when view tracking was installed</p><div className="h-36 flex gap-2 items-end justify-around border-b pb-2">{chart.map((d:any)=><div key={d.day} className="flex-1 h-full flex flex-col justify-end items-center"><span className="text-xs">{d.views}</span><div className="bg-primary-600 rounded-t w-3/4" style={{height:`${Math.max(2,Number(d.views)/max*100)}px`}}/><span className="text-xs mt-1 text-gray-500">{d.day}</span></div>)}</div></div>
  <div className="bg-white border rounded-xl p-5"><h3 className="font-bold mb-3">Service Requests</h3>{!bookings?.length?<p className="text-gray-600">No service requests yet.</p>:<div className="space-y-2">{bookings.slice(0,3).map((b:any)=><p className="text-sm" key={b.id}><strong>{b.serviceName}</strong> · {b.status}</p>)}</div>}<Link href="/services/bookings" className="underline block mt-4 text-primary-700">View all requests</Link></div></div>
  {user?.role==='FARMER'&&<div className="bg-white border rounded-xl p-5"><h3 className="font-bold text-xl">My Farmland</h3><p className="mt-2">Land: {farm?.land_acres?`${farm.land_acres} acres`:'Not entered'} · Soil: {farm?.soil_type||'Not entered'} · Irrigation: {farm?.irrigation||'Not entered'}</p><p>Currently sown: <strong>{farm?.current_crops||'Not entered'}</strong></p><Link href="/dashboard/insights" className="underline text-primary-700">Edit land and crops</Link></div>}
 </section>
}
