'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui'
import { Wheat } from 'lucide-react'
import Logo from '@/components/Logo'
import { useAuth } from '@/contexts/AuthContext'

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { user, isAuthenticated, logout } = useAuth()
  const router = useRouter()

  const handleLogout = async () => {
    await logout()
    router.push('/login')
  }

  return (
    <header className="bg-white border-b-2 border-secondary-200 sticky top-0 z-50 shadow-soft">
      <div className="container-default">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Logo size="md" variant="primary" />

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            <Link 
              href="/products" 
              className="font-sans text-body-md font-medium text-secondary-700 hover:text-primary-600 transition-colors relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-primary-600 hover:after:w-full after:transition-all"
            >
              Products
            </Link>
            <Link 
              href="/services" 
              className="font-sans text-body-md font-medium text-secondary-700 hover:text-primary-600 transition-colors relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-primary-600 hover:after:w-full after:transition-all"
            >
              Services
            </Link>
            <Link href="/advisory" className="font-sans text-body-md font-semibold text-primary-700 hover:text-primary-600">AI Advisory</Link>
            <Link 
              href="/about" 
              className="font-sans text-body-md font-medium text-secondary-700 hover:text-primary-600 transition-colors relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-primary-600 hover:after:w-full after:transition-all"
            >
              About
            </Link>
            {isAuthenticated && (
              <Link 
                href="/cart" 
                className="font-sans text-body-md font-medium text-secondary-700 hover:text-primary-600 transition-colors flex items-center gap-2 relative"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                Cart
              </Link>
            )}
          </nav>

          {/* Auth Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            {isAuthenticated ? (
              <>
                <Link href="/dashboard">
                  <Button variant="ghost" size="md">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    {user?.fullName || 'Dashboard'}
                  </Button>
                </Link>
                <Button variant="secondary" size="md" onClick={handleLogout}>
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="secondary" size="md">
                    Login
                  </Button>
                </Link>
                <Link href="/register">
                  <Button variant="accent" size="md">
                    Get Started
                  </Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-secondary-700 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden py-6 border-t-2 border-secondary-200 animate-slide-up">
            <nav className="flex flex-col gap-4">
              <Link 
                href="/products" 
                className="font-sans text-body-md font-medium text-secondary-700 hover:text-primary-600 hover:bg-primary-50 py-3 px-4 rounded-xl transition-all"
                onClick={() => setMobileMenuOpen(false)}
              >
                Products
              </Link>
              <Link 
                href="/services" 
                className="font-sans text-body-md font-medium text-secondary-700 hover:text-primary-600 hover:bg-primary-50 py-3 px-4 rounded-xl transition-all"
                onClick={() => setMobileMenuOpen(false)}
              >
                Services
              </Link>
              <Link 
                href="/about" 
                className="font-sans text-body-md font-medium text-secondary-700 hover:text-primary-600 hover:bg-primary-50 py-3 px-4 rounded-xl transition-all"
                onClick={() => setMobileMenuOpen(false)}
              >
                About
              </Link>
              <Link href="/advisory" className="font-sans text-body-md font-semibold text-primary-700 px-4 py-3" onClick={() => setMobileMenuOpen(false)}>AI Advisory</Link>
              {isAuthenticated ? (
                <>
                  <Link 
                    href="/cart" 
                    className="font-sans text-body-md font-medium text-secondary-700 hover:text-primary-600 hover:bg-primary-50 py-3 px-4 rounded-xl transition-all flex items-center gap-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                    Cart
                  </Link>
                  <Link 
                    href="/dashboard" 
                    className="font-sans text-body-md font-medium text-secondary-700 hover:text-primary-600 hover:bg-primary-50 py-3 px-4 rounded-xl transition-all flex items-center gap-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    Dashboard
                  </Link>
                  <div className="border-t-2 border-secondary-200 pt-4 mt-2">
                    <Button variant="secondary" size="md" onClick={handleLogout} className="w-full">
                      Logout
                    </Button>
                  </div>
                </>
              ) : (
                <div className="flex flex-col gap-3 border-t-2 border-secondary-200 pt-4 mt-2">
                  <Link href="/login" onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="secondary" size="md" className="w-full">
                      Login
                    </Button>
                  </Link>
                  <Link href="/register" onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="accent" size="md" className="w-full">
                      Get Started
                    </Button>
                  </Link>
                </div>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
