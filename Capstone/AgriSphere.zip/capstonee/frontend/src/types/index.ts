/**
 * TypeScript types matching AgriSphere C++ Backend
 */

// User Roles
export type UserRole = 'FARMER' | 'BUYER' | 'SELLER' | 'SERVICE_PROVIDER' | 'ADMIN';

// User Status
export type UserStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED';

// Product Category
export type ProductCategory = 'GRAINS' | 'VEGETABLES' | 'FRUITS' | 'DAIRY' | 'SPICES' | 'OTHER';

// Product Status
export type ProductStatus = 'ACTIVE' | 'SOLD_OUT' | 'INACTIVE';

// User
export interface User {
  id: string;
  email: string;
  fullName: string;
  phone: string;
  role: UserRole;
  status: UserStatus;
  district?: string;
  state?: string;
  pinCode?: string;
  address?: string;
  profileImage?: string;
  lastLogin?: string;
  createdAt: string;
  updatedAt: string;
}

// Auth Tokens
export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

// Auth Response
export interface AuthResponse {
  user: User;
  tokens: AuthTokens;
}

// Product
export interface Product {
  id: string;
  name: string;
  description: string;
  category: ProductCategory;
  pricePerUnit: number; // in paisa
  unit: string;
  availableQuantity: number;
  minOrderQuantity?: number;
  sellerId: string;
  status: ProductStatus;
  images?: string[];
  createdAt: string;
  updatedAt: string;
}

// Cart Item
export interface CartItem {
  id: string;
  cartId: string;
  productId: string;
  quantity: number;
  product: {
    name: string;
    pricePerUnit: number;
    unit: string;
    availableQuantity: number;
  };
  subtotal: number;
  createdAt: string;
  updatedAt: string;
}

// Cart
export interface Cart {
  id: string;
  userId: string;
  items: CartItem[];
  totalItems: number;
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
}

// Pagination
export interface Pagination {
  page: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
}

// API Response
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    fields?: Record<string, string>;
  };
}

// Products List Response
export interface ProductsResponse {
  products: Product[];
  pagination: Pagination;
}

// Login Request
export interface LoginRequest {
  email: string;
  password: string;
}

// Register Request
export interface RegisterRequest {
  email: string;
  password: string;
  fullName: string;
  phone: string;
  role: UserRole;
  district?: string;
  state?: string;
}

// Add to Cart Request
export interface AddToCartRequest {
  productId: string;
  quantity: number;
}

// Create Product Request
export interface CreateProductRequest {
  name: string;
  description: string;
  category: ProductCategory;
  pricePerUnit: number;
  unit: string;
  availableQuantity: number;
  minOrderQuantity?: number;
}

// Price Helpers
export const formatPrice = (paisa: number): string => {
  const rupees = paisa / 100;
  return `₹${rupees.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

export const formatPriceShort = (paisa: number): string => {
  const rupees = paisa / 100;
  return `₹${rupees.toLocaleString('en-IN')}`;
};

export const parsePrice = (rupees: number): number => {
  return Math.round(rupees * 100);
};
