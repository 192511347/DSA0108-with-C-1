import { NextRequest, NextResponse } from 'next/server'
import { writeFile, mkdir } from 'node:fs/promises'
import { join } from 'node:path'
import { randomUUID } from 'node:crypto'

export const runtime = 'nodejs'

export async function POST(request: NextRequest) {
  try {
    const auth = request.headers.get('authorization') || ''
    if (!auth.startsWith('Bearer ')) return NextResponse.json({ error: 'Login required' }, { status: 401 })
    // Validate token with real Crow backend, not merely its presence.
    const verified = await fetch('http://127.0.0.1:6001/api/v1/auth/me', {
      headers: { Authorization: auth }, cache: 'no-store', signal: AbortSignal.timeout(6000)
    })
    if (!verified.ok) return NextResponse.json({ error: 'Invalid session' }, { status: 401 })
    const body = await request.formData()
    const file = body.get('file')
    if (!(file instanceof File)) return NextResponse.json({ error: 'Missing image file' }, { status: 400 })
    const types: Record<string,string> = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' }
    const ext = types[file.type]
    if (!ext || file.size > 3 * 1024 * 1024 || file.size === 0)
      return NextResponse.json({ error: 'JPEG, PNG or WebP image required (maximum 3 MB)' }, { status: 400 })
    const data = Buffer.from(await file.arrayBuffer())
    // Basic magic-byte verification prevents accepting arbitrary files renamed as images.
    const jpg = data.length >= 3 && data[0] === 0xff && data[1] === 0xd8 && data[2] === 0xff
    const png = data.length >= 8 && data.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))
    const webp = data.length >= 12 && data.toString('ascii',0,4) === 'RIFF' && data.toString('ascii',8,12) === 'WEBP'
    if (!((ext === '.jpg' && jpg) || (ext === '.png' && png) || (ext === '.webp' && webp)))
      return NextResponse.json({ error: 'Invalid image content' }, { status: 400 })
    const filename = randomUUID() + ext
    const dest = join(process.cwd(), 'public', 'uploads')
    await mkdir(dest, { recursive: true })
    await writeFile(join(dest, filename), data, { flag: 'wx' })
    return NextResponse.json({ url: '/uploads/' + filename })
  } catch (e) {
    console.error('Upload error:', e)
    return NextResponse.json({ error: 'Upload failed; verify backend is running' }, { status: 500 })
  }
}
