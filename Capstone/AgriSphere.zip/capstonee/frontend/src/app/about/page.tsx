import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { ShoppingCart, Tractor, BarChart3, Users } from 'lucide-react'

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow">
        <div className="bg-gradient-to-br from-primary-50 to-accent-50 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-5xl font-bold text-primary-800 mb-4">About AgriSphere</h1>
            <p className="text-xl text-secondary-700 max-w-3xl mx-auto">
              Empowering Indian agriculture through digital innovation
            </p>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="prose max-w-none">
            <h2 className="text-3xl font-bold text-primary-800 mb-4">Our Mission</h2>
            <p className="text-lg text-secondary-700 mb-6 leading-relaxed">
              AgriSphere is India's premier digital agriculture platform, connecting farmers, buyers, sellers, and service providers in a comprehensive ecosystem. We're committed to modernizing Indian agriculture through technology and innovation.
            </p>

            <h2 className="text-3xl font-bold text-primary-800 mb-4 mt-12">What We Offer</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
              <div className="bg-white p-6 rounded-xl border-2 border-secondary-200">
                <div className="flex items-center gap-3 mb-2">
                  <ShoppingCart className="w-6 h-6 text-primary-600" />
                  <h3 className="text-xl font-bold text-primary-800">Marketplace</h3>
                </div>
                <p className="text-secondary-700">Buy and sell agricultural products directly from verified sellers</p>
              </div>
              <div className="bg-white p-6 rounded-xl border-2 border-secondary-200">
                <div className="flex items-center gap-3 mb-2">
                  <Tractor className="w-6 h-6 text-primary-600" />
                  <h3 className="text-xl font-bold text-primary-800">Services</h3>
                </div>
                <p className="text-secondary-700">Access equipment rental, soil testing, and expert consultation</p>
              </div>
              <div className="bg-white p-6 rounded-xl border-2 border-secondary-200">
                <div className="flex items-center gap-3 mb-2">
                  <BarChart3 className="w-6 h-6 text-primary-600" />
                  <h3 className="text-xl font-bold text-primary-800">Analytics</h3>
                </div>
                <p className="text-secondary-700">Data-driven insights to optimize your farming operations</p>
              </div>
              <div className="bg-white p-6 rounded-xl border-2 border-secondary-200">
                <div className="flex items-center gap-3 mb-2">
                  <Users className="w-6 h-6 text-primary-600" />
                  <h3 className="text-xl font-bold text-primary-800">Community</h3>
                </div>
                <p className="text-secondary-700">Connect with fellow farmers and agricultural experts</p>
              </div>
            </div>

            <h2 className="text-3xl font-bold text-primary-800 mb-4">Contact Us</h2>
            <p className="text-lg text-secondary-700">
              Email: support@agrisphere.in<br />
              Phone: +91 1800 XXX XXXX<br />
              Address: Digital Agriculture Hub, India
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
