'use client'

import { useEffect, useMemo, useState } from 'react'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import Link from 'next/link'
import { useAuth } from '@/contexts/AuthContext'
import { api } from '@/lib/api'
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts'
import { Sprout, CloudSun, CloudRain, Droplets, TrendingUp, AlertTriangle, CheckCircle2, History, ArrowRight, Loader2, MapPin, ShieldAlert } from 'lucide-react'

type Crop = { name:string; suitability:string; reason:string; waterNeeds:string; duration:string; costAndProfit:string; risk:string }
type Advisory = { summary:string; directAnswer:string; recommendedCrops:Crop[]; actionSteps:string[]; risks:string[]; followUpQuestions:string[]; dataGaps:string[]; costBreakdown:string; financialSource:string; financialVerified:boolean; dataSources?:Record<string,string>; role?:string; language?:string }
type Weather = { location?:string;region?:string;provider?:string;current?:{ time?:string;temperature_2m?:number;relative_humidity_2m?:number;precipitation?:number;wind_speed_10m?:number };daily?:{time?:string[];temperature_2m_max?:number[];temperature_2m_min?:number[];precipitation_sum?:number[]}}
type Result = {advisory:Advisory;weather:Weather|null;weatherNote?:string;role:string;saved:boolean}
type RecordItem = {id:string;question:string;createdAt:string;location:string;language:string;answer:Advisory;weather:Weather|null}
const prompts:Record<string,string[]> = {
 FARMER:['Which crops can suit my land and irrigation this season?','Compare two crops by water needs, costs and harvest time','What should I do on my farm this week?'],
 SERVICE_PROVIDER:['Which real service requests match what I can offer?','How can I plan farm equipment rentals in my district?','How should I price and schedule local service work?'],
 BUYER:['How does my purchased crop reach my doorstep?','Explain how vegetables are grown, harvested and stored','How can I tell whether fresh produce is in good condition?']
}
const clean=(value:unknown)=>typeof value==='string'?value:''
function advisoryValid(input:any):input is Advisory {return !!input&&typeof input.summary==='string'&&typeof input.directAnswer==='string'}
function WeatherPanel({weather,note}:{weather:Weather|null;note:string}){
 const current=weather?.current
 const days=weather?.daily
 const forecast=(days?.time||[]).map((date,i)=>({date:date.slice(5),high:days?.temperature_2m_max?.[i],low:days?.temperature_2m_min?.[i],rain:days?.precipitation_sum?.[i]}))
 return <section className="rounded-2xl bg-white border border-emerald-100 shadow-sm p-5 md:p-6">
  <div className="flex items-center justify-between gap-3"><h3 className="text-lg font-bold text-emerald-950 flex items-center gap-2"><CloudSun size={22}/> Local weather</h3><span className="text-xs text-slate-500">{weather?.provider||'No live source'}</span></div>
  {current?<><p className="text-sm text-slate-500 mt-1 flex items-center gap-1"><MapPin size={14}/>{weather?.location}{weather?.region?`, ${weather.region}`:''} · {current.time||'Forecast'}</p>
   <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-5">
    {[['Temperature',current.temperature_2m,'°C'],['Humidity',current.relative_humidity_2m,'%'],['Precipitation',current.precipitation,'mm'],['Wind',current.wind_speed_10m,'km/h']].map(([label,value,unit])=><div key={String(label)} className="rounded-xl bg-emerald-50 p-3"><p className="text-xs text-slate-600">{label}</p><p className="text-xl font-semibold text-emerald-900">{typeof value==='number'?value:'—'} <span className="text-sm font-normal">{unit}</span></p></div>)}
   </div>
   {forecast.length>0&&<div className="h-60 mt-6" aria-label="Temperature forecast chart"><ResponsiveContainer width="100%" height="100%"><LineChart data={forecast}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="date" fontSize={12}/><YAxis fontSize={12} unit="°"/><Tooltip/><Legend/><Line type="monotone" dataKey="high" stroke="#047857" name="High °C" strokeWidth={2}/><Line type="monotone" dataKey="low" stroke="#d97706" name="Low °C" strokeWidth={2}/></LineChart></ResponsiveContainer></div>}
   {forecast.length>0&&<p className="text-sm text-slate-600 mt-2 flex gap-2"><CloudRain size={17}/> Forecast rain: {forecast.map(x=>`${x.date} ${typeof x.rain==='number'?x.rain+' mm':'unknown'}`).join(' · ')}</p>}
  </>:<p className="text-sm text-amber-800 mt-4 rounded-xl bg-amber-50 p-4">{note||'No current weather data available. Advice will not assume weather.'}</p>}
  <p className="text-xs text-slate-500 mt-3">Open-Meteo forecast, not an on-farm measurement. Weather and rainfall can change.</p>
 </section>
}
export default function AdvisoryPage(){
 const {user}=useAuth()
 const role=String(user?.role||'BUYER').toUpperCase()
 const [question,setQuestion]=useState('')
 const [location,setLocation]=useState('')
 const [language,setLanguage]=useState('en')
 const [result,setResult]=useState<Result|null>(null)
 const [history,setHistory]=useState<RecordItem[]>([])
 const [loading,setLoading]=useState(false)
 const [historyLoading,setHistoryLoading]=useState(false)
 const [error,setError]=useState('')
 const [showHistory,setShowHistory]=useState(false)
 const examples=prompts[role]||prompts.BUYER
 const weather=result?.weather||null
 const a=result?.advisory
 async function loadHistory(){
  setHistoryLoading(true)
  try {const r=await api.get('/advisory/history');setHistory(Array.isArray(r.data?.data?.history)?r.data.data.history:[])}
  catch(e:any){setError(e.response?.data?.error?.message||'Could not load advisory history')}
  finally{setHistoryLoading(false)}
 }
 useEffect(()=>{if(user)loadHistory()},[user?.id])
 async function ask(value=question){
  if(!value.trim()||loading)return
  setLoading(true);setError('');setResult(null)
  try {
   const r=await api.post('/advisory',{question:value.trim(),location:location.trim(),language})
   const data=r.data?.data
   if(!advisoryValid(data?.advisory))throw new Error('The advisory response was incomplete. Please retry.')
   setResult(data);loadHistory()
  }catch(e:any){setError(e.response?.data?.error?.message||e.message||'AI advisory unavailable. Please retry.')}
  finally{setLoading(false)}
 }
 const dateLabel=(date:string)=>{const d=new Date(date);return Number.isNaN(d.getTime())?'Previous question':d.toLocaleString()}
 return <div className="min-h-screen bg-[#f6f8f4] flex flex-col"><Header/>
 <main className="container-default w-full max-w-6xl flex-grow py-8 md:py-12">
  <div className="flex flex-wrap items-start justify-between gap-4 mb-8">
   <div><span className="inline-flex items-center gap-2 text-sm font-semibold text-emerald-700"><Sprout size={19}/> AGRISPHERE ADVISORY</span><h1 className="text-3xl md:text-4xl font-bold text-emerald-950 mt-2">Better decisions for your farm</h1><p className="text-slate-600 mt-2">Practical AI guidance tailored to your {role.toLowerCase().replace('_',' ')} profile.</p></div>
   <div className="flex gap-2"><Link href="/dashboard/insights" className="rounded-xl border bg-white px-4 py-2.5 text-sm font-semibold text-emerald-800">My farm & insights</Link><button onClick={()=>{setShowHistory(v=>!v);loadHistory()}} className="rounded-xl bg-emerald-800 text-white px-4 py-2.5 text-sm flex items-center gap-2"><History size={16}/> History</button></div>
  </div>
  <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_310px] gap-6 items-start">
   <div className="space-y-6 min-w-0">
    <section className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-5 md:p-7 space-y-5">
     <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-bold text-emerald-950">Ask your advisor</h2><label className="flex items-center gap-2 text-sm text-slate-600">Language <select className="border rounded-lg p-2 text-emerald-900" value={language} onChange={e=>setLanguage(e.target.value)}><option value="en">English</option><option value="ta">தமிழ்</option><option value="hi">हिन्दी</option></select></label></div>
     <div className="flex flex-wrap gap-2">{examples.map(item=><button key={item} onClick={()=>setQuestion(item)} className="text-left text-xs md:text-sm border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 rounded-xl px-3 py-2 text-emerald-900">{item}</button>)}</div>
     <div><label htmlFor="agri-location" className="block text-sm font-semibold mb-1 text-slate-700">Farm location <span className="font-normal text-slate-400">(optional; uses your district)</span></label><input id="agri-location" className="w-full rounded-xl border p-3 focus:outline-none focus:ring-2 focus:ring-emerald-500" placeholder="e.g. Vellore, Tamil Nadu" maxLength={100} value={location} onChange={e=>setLocation(e.target.value)}/></div>
     <div><label htmlFor="agri-question" className="block text-sm font-semibold mb-1 text-slate-700">What would you like to know?</label><textarea id="agri-question" className="w-full rounded-xl border p-4 min-h-[125px] focus:outline-none focus:ring-2 focus:ring-emerald-500" maxLength={1200} placeholder="Tell us about your crop, water, soil, or plans..." value={question} onChange={e=>setQuestion(e.target.value)}/><p className="text-xs text-slate-400 text-right">{question.length}/1200</p></div>
     <button disabled={loading||!question.trim()} onClick={()=>ask()} className="w-full md:w-auto rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold px-6 py-3 disabled:opacity-50 inline-flex justify-center items-center gap-2">{loading?<><Loader2 size={18} className="animate-spin"/>Analyzing your question...</>:<>Get practical advice <ArrowRight size={18}/></>}</button>
     {loading&&<div className="space-y-3 animate-pulse" aria-label="Advisory loading"><div className="bg-slate-100 h-5 rounded w-2/3"/><div className="bg-slate-100 h-16 rounded"/><div className="bg-slate-100 h-12 rounded"/></div>}
     {error&&<div role="alert" className="rounded-xl bg-rose-50 border border-rose-200 text-rose-800 p-4 text-sm flex items-start gap-2"><ShieldAlert size={18}/><span>{error} <button className="font-bold underline" onClick={()=>ask()}>Retry</button></span></div>}
    </section>
    {a&&<>
      <section className="rounded-2xl bg-emerald-950 p-6 md:p-8 text-white"><p className="text-xs uppercase tracking-wider text-emerald-200 mb-3">Your personalized recommendation</p><h2 className="text-2xl md:text-3xl font-bold leading-snug">{a.summary}</h2><p className="mt-4 text-emerald-50 text-base leading-7 whitespace-pre-line">{a.directAnswer}</p><div className="mt-5 text-xs text-emerald-200">Saved to your advisory history · AI-generated guidance</div></section>
      <WeatherPanel weather={weather} note={result?.weatherNote||''}/>
      {a.recommendedCrops?.length>0&&<section><h2 className="text-xl font-bold text-emerald-950 mb-3">Crop options worth comparing</h2><div className="grid md:grid-cols-2 gap-4">{a.recommendedCrops.map((crop,i)=><article key={crop.name+i} className="rounded-2xl bg-white border border-emerald-100 shadow-sm p-5 space-y-3"><div className="flex items-center justify-between"><h3 className="text-lg font-bold text-emerald-950">{crop.name}</h3><span className="text-xs rounded-full bg-emerald-100 text-emerald-800 px-2 py-1">{crop.suitability}</span></div><p className="text-sm text-slate-700">{crop.reason}</p><div className="grid grid-cols-2 gap-2 text-sm"><div className="bg-slate-50 rounded-lg p-3"><p className="text-xs text-slate-500">Water</p>{crop.waterNeeds}</div><div className="bg-slate-50 rounded-lg p-3"><p className="text-xs text-slate-500">Crop duration</p>{crop.duration}</div></div><p className="text-sm text-slate-700"><strong>Financial outlook:</strong> {crop.costAndProfit}</p><p className="text-sm text-amber-800"><strong>Risk:</strong> {crop.risk}</p></article>)}</div></section>}
      <section className="rounded-2xl bg-white border border-emerald-100 shadow-sm p-5 md:p-6"><h2 className="font-bold text-xl text-emerald-950 flex items-center gap-2"><TrendingUp size={21}/> Cost and profitability</h2><p className="mt-3 text-slate-700">{a.costBreakdown}</p><div className="mt-4 bg-amber-50 text-amber-900 rounded-xl p-3 text-sm"><strong>Financial data:</strong> {a.financialSource}. No verified profit chart is shown without sourced price and yield data.</div></section>
      {a.actionSteps?.length>0&&<section className="bg-white rounded-2xl border border-emerald-100 p-5 md:p-6"><h2 className="font-bold text-xl text-emerald-950 mb-4 flex items-center gap-2"><CheckCircle2 size={20}/> What to do next</h2><ol className="space-y-3">{a.actionSteps.map((step,i)=><li key={i} className="flex gap-3 text-slate-700"><span className="flex-shrink-0 w-7 h-7 rounded-full bg-emerald-100 text-emerald-900 text-sm font-bold flex items-center justify-center">{i+1}</span><span>{step}</span></li>)}</ol></section>}
      {a.risks?.length>0&&<section className="bg-white rounded-2xl border border-amber-200 p-5 md:p-6"><h2 className="font-bold text-lg text-amber-950 mb-3 flex items-center gap-2"><AlertTriangle size={19}/> Things to watch out for</h2><ul className="space-y-2 text-sm text-slate-700 list-disc pl-5">{a.risks.map((r,i)=><li key={i}>{r}</li>)}</ul></section>}
      {a.dataGaps?.length>0&&<section className="bg-slate-100 rounded-2xl p-5"><h2 className="font-bold text-slate-800">What we still need to know</h2><p className="mt-2 text-sm text-slate-600">{a.dataGaps.join(' · ')}</p></section>}
      {a.followUpQuestions?.length>0&&<section><h2 className="font-bold text-lg text-emerald-950 mb-3">Explore further</h2><div className="flex flex-wrap gap-2">{a.followUpQuestions.map((q,i)=><button key={i} onClick={()=>{setQuestion(q);window.scrollTo({top:0,behavior:'smooth'})}} className="px-4 py-2 rounded-xl border border-emerald-200 text-emerald-900 bg-white text-sm hover:bg-emerald-50">{q} →</button>)}</div></section>}
    </>}
   </div>
   <aside className="space-y-4 lg:sticky lg:top-5">
    <div className="rounded-2xl bg-white border border-emerald-100 p-5"><h3 className="font-bold text-emerald-950 mb-3">Your advisory understands</h3><ul className="text-sm text-slate-600 space-y-3"><li className="flex gap-2"><MapPin size={16}/> District and farm location</li><li className="flex gap-2"><Droplets size={16}/> Water availability when recorded</li><li className="flex gap-2"><Sprout size={16}/> Your current crops and land</li><li className="flex gap-2"><CloudRain size={16}/> Verified forecast when available</li></ul><Link href="/dashboard/insights" className="block mt-4 text-sm font-bold text-emerald-800 underline">Update my farm details</Link></div>
    <div className="rounded-2xl bg-white border border-emerald-100 p-5"><h3 className="font-bold text-emerald-950">Saved advice</h3><p className="text-xs text-slate-500 mt-1">Only your own questions are shown.</p><button className="text-sm text-emerald-700 underline mt-2" onClick={()=>{setShowHistory(v=>!v);loadHistory()}}>{showHistory?'Hide history':'View history'}</button>{showHistory&&<div className="mt-4 space-y-2 max-h-[470px] overflow-y-auto">{historyLoading&&<p className="text-sm text-slate-500">Loading...</p>}{!historyLoading&&history.length===0&&<p className="text-sm text-slate-500">No saved questions yet.</p>}{history.map(item=><button key={item.id} onClick={()=>{if(advisoryValid(item.answer)){setResult({advisory:item.answer,weather:item.weather,role:item.answer.role||role,saved:true});setQuestion(item.question);setLocation(item.location);window.scrollTo({top:0,behavior:'smooth'})}}} className="text-left w-full p-3 border rounded-xl hover:bg-emerald-50"><p className="text-sm font-semibold text-slate-800 line-clamp-2">{item.question}</p><p className="text-xs text-slate-500 mt-1">{dateLabel(item.createdAt)}</p></button>)}</div>}</div>
    <p className="text-xs text-slate-500 leading-5">This tool provides decision support, not guaranteed yields, medical diagnosis, financial advice, or verified crop prices. Confirm critical actions with local agricultural experts.</p>
   </aside>
  </div>
 </main><Footer/></div>
}
