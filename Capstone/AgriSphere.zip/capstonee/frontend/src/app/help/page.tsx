import Header from '@/components/Header'
import Footer from '@/components/Footer'

export default function HelpPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow bg-secondary-50 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-primary-800 mb-8">Help Center</h1>
          <div className="grid gap-6">
            {['How to buy products?', 'How to sell products?', 'Payment methods', 'Shipping policy', 'Returns & refunds'].map((topic, i) => (
              <div key={i} className="bg-white rounded-xl p-6 border-2 border-secondary-200">
                <h3 className="text-xl font-bold text-primary-800">{topic}</h3>
                <p className="text-secondary-700 mt-2">Detailed information coming soon...</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
