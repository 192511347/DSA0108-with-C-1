import Header from '@/components/Header'
import Footer from '@/components/Footer'

export default function PrivacyPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow bg-secondary-50 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-primary-800 mb-8">Privacy Policy</h1>
          <div className="bg-white rounded-xl p-8 border-2 border-secondary-200 prose max-w-none">
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Data Collection</h2>
            <p className="text-secondary-700 mb-6">
              We collect information you provide when registering and using our platform. This includes your name, email, phone number, and location.
            </p>
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Data Usage</h2>
            <p className="text-secondary-700 mb-6">
              Your data is used to provide services, process transactions, and improve your experience on AgriSphere.
            </p>
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Data Security</h2>
            <p className="text-secondary-700">
              We implement industry-standard security measures to protect your personal information.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
