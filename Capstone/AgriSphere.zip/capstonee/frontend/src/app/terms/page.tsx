import Header from '@/components/Header'
import Footer from '@/components/Footer'

export default function TermsPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow bg-secondary-50 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-primary-800 mb-8">Terms of Service</h1>
          <div className="bg-white rounded-xl p-8 border-2 border-secondary-200 prose max-w-none">
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Acceptance of Terms</h2>
            <p className="text-secondary-700 mb-6">
              By using AgriSphere, you agree to these terms of service.
            </p>
            <h2 className="text-2xl font-bold text-primary-800 mb-4">User Responsibilities</h2>
            <p className="text-secondary-700 mb-6">
              Users must provide accurate information and comply with applicable laws.
            </p>
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Service Modifications</h2>
            <p className="text-secondary-700">
              We reserve the right to modify or discontinue services with notice.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
