'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { cartApi } from '@/lib/api'
import Link from 'next/link'
import { ShoppingCart, Package } from 'lucide-react'
import { ProtectedRoute } from '@/components/ProtectedRoute'

function CartPageContent() {
  const router = useRouter()
  const queryClient = useQueryClient()

  const { data: cartData, isLoading, isError, error } = useQuery({
    queryKey: ['cart'],
    queryFn: async () => {
      const response = await cartApi.get()
      return response.data.data?.cart ?? response.data.data
    },
  })

  const updateMutation = useMutation({
    mutationFn: ({ itemId, quantity }: { itemId: string; quantity: number }) =>
      cartApi.updateItem(itemId, { quantity }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cart'] })
    },
  })

  const removeMutation = useMutation({
    mutationFn: (itemId: string) => cartApi.removeItem(itemId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cart'] })
    },
  })

  const clearMutation = useMutation({
    mutationFn: () => cartApi.clear(),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cart'] })
    },
  })

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mb-4"></div>
            <p className="text-secondary-600">Loading cart...</p>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  if (isError) {
    return <div className="min-h-screen"><Header /><main className="p-10 text-center text-red-700">Unable to load cart: {(error as any)?.response?.data?.error?.message || (error as Error)?.message || 'API error'}</main><Footer /></div>
  }

  const cart = cartData && Array.isArray(cartData.items) ? cartData : { items: [], totalItems: 0, totalAmount: 0 }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow bg-secondary-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-primary-800 mb-8">Shopping Cart</h1>

          {cart.items.length === 0 ? (
            <div className="bg-white rounded-xl p-12 text-center border-2 border-secondary-200">
              <ShoppingCart className="w-16 h-16 text-secondary-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-secondary-800 mb-2">Your cart is empty</h3>
              <p className="text-secondary-600 mb-6">Add some products to get started!</p>
              <Link
                href="/products"
                className="inline-block px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-semibold"
              >
                Browse Products
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Cart Items */}
              <div className="lg:col-span-2 space-y-4">
                {cart.items.map((item: any) => (
                  <div key={item.id} className="bg-white rounded-xl p-6 border-2 border-secondary-200">
                    <div className="flex gap-4">
                      <div className="w-24 h-24 bg-gradient-to-br from-primary-50 to-accent-50 rounded-lg flex items-center justify-center flex-shrink-0">
                        {(item.imageUrl || item.product?.images?.[0]) ? (
                          <img src={item.imageUrl || item.product?.images?.[0]} alt={item.productName || item.product?.name} className="w-full h-full object-cover rounded-lg" />
                        ) : (
                          <Package className="w-8 h-8 text-secondary-400" />
                        )}
                      </div>
                      <div className="flex-grow">
                        <h3 className="font-semibold text-lg text-secondary-800 mb-1">{item.productName || item.product?.name}</h3>
                        <p className="text-sm text-secondary-600 mb-2">Sold by: {item.sellerName || 'AgriSphere seller'}</p>
                        <p className="text-lg font-bold text-primary-600">
                          ₹{(Number(item.pricePerUnit ?? item.product?.pricePerUnit ?? 0) / 100).toFixed(2)} / {item.unit || item.product?.unit}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-secondary-200">
                      <div className="flex items-center gap-3">
                        <label className="text-sm font-medium text-secondary-700">Quantity:</label>
                        <input
                          type="number"
                          min="1"
                          max={item.availableQuantity ?? item.product?.availableQuantity}
                          value={item.quantity}
                          onChange={(e) => {
                            const newQty = parseInt(e.target.value) || 1
                            updateMutation.mutate({ itemId: item.id, quantity: newQty })
                          }}
                          className="w-20 px-3 py-2 border-2 border-secondary-300 rounded-lg text-center font-semibold"
                        />
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-sm text-secondary-600">Subtotal</div>
                          <div className="text-xl font-bold text-primary-600">
                            ₹{(Number(item.subtotal ?? (item.quantity * (item.pricePerUnit ?? item.product?.pricePerUnit ?? 0))) / 100).toFixed(2)}
                          </div>
                        </div>
                        <button
                          onClick={() => removeMutation.mutate(item.id)}
                          className="px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 font-medium transition-colors"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                <button
                  onClick={() => clearMutation.mutate()}
                  className="w-full px-4 py-3 bg-secondary-100 text-secondary-800 rounded-lg hover:bg-secondary-200 font-medium transition-colors"
                >
                  Clear Cart
                </button>
              </div>

              {/* Order Summary */}
              <div className="lg:col-span-1">
                <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 sticky top-20">
                  <h3 className="font-bold text-lg text-primary-800 mb-4">Order Summary</h3>
                  <div className="space-y-3 mb-6">
                    <div className="flex justify-between text-secondary-700">
                      <span>Total Items:</span>
                      <span className="font-semibold">{cart.totalItems}</span>
                    </div>
                    <div className="flex justify-between text-secondary-700">
                      <span>Subtotal:</span>
                      <span className="font-semibold">₹{(cart.totalAmount / 100).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-secondary-700">
                      <span>Delivery:</span>
                      <span className="font-semibold text-green-600">FREE</span>
                    </div>
                    <div className="border-t border-secondary-200 pt-3">
                      <div className="flex justify-between text-lg font-bold text-primary-800">
                        <span>Total:</span>
                        <span>₹{(cart.totalAmount / 100).toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => router.push('/checkout')}
                    className="w-full px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-semibold transition-colors mb-3"
                  >
                    Proceed to Checkout →
                  </button>
                  <Link
                    href="/products"
                    className="block text-center px-6 py-3 bg-secondary-100 text-secondary-800 rounded-lg hover:bg-secondary-200 font-medium transition-colors"
                  >
                    Continue Shopping
                  </Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}

export default function CartPage() {
  return (
    <ProtectedRoute>
      <CartPageContent />
    </ProtectedRoute>
  )
}
