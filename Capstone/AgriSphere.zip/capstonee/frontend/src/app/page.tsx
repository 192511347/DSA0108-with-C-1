'use client'

import Link from 'next/link'
import { useQuery } from '@tanstack/react-query'
import { productApi } from '@/lib/api'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { Button, Card, Badge } from '@/components/ui'

export default function HomePage() {
  const { data: productsData } = useQuery({
    queryKey: ['products', 'featured'],
    queryFn: async () => {
      const response = await productApi.list({ pageSize: 8 })
      return response.data.data
    },
  })

  return (
    <div className="min-h-screen flex flex-col bg-canvas">
      <Header />

      {/* Hero Section */}
      <section className="section-lg bg-gradient-to-br from-primary-50 via-canvas to-accent-50 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent-200 opacity-20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary-300 opacity-20 rounded-full blur-3xl"></div>
        
        <div className="container-default relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="font-display text-display-lg md:text-display-xl text-primary-800 mb-6 leading-tight animate-fade-in">
              India's Digital Agriculture Ecosystem
            </h1>
            <p className="text-body-lg text-secondary-700 mb-10 leading-relaxed max-w-2xl mx-auto">
              Connecting farmers, buyers, sellers, and service providers across India.
              Buy agricultural inputs, sell produce, find services, and grow your business.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 animate-slide-up">
              <Link href="/products">
                <Button variant="primary" size="lg">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  Browse Products
                </Button>
              </Link>
              <Link href="/services">
                <Button variant="secondary" size="lg">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  Find Services
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section bg-white">
        <div className="container-default">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card variant="interactive" padding="lg" className="text-center bg-gradient-to-br from-white to-primary-50">
              <div className="w-16 h-16 bg-primary-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-soft">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="font-sans text-heading-lg text-primary-800 mb-3">Buy & Sell</h3>
              <p className="text-body-md text-secondary-700 leading-relaxed mb-4">
                Access quality agricultural products directly from verified sellers across India
              </p>
              <Link href="/products">
                <Button variant="primary" size="md" className="w-full">
                  Browse Products
                </Button>
              </Link>
            </Card>

            <Card variant="interactive" padding="lg" className="text-center bg-gradient-to-br from-white to-accent-50">
              <div className="w-16 h-16 bg-accent-200 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-soft">
                <svg className="w-8 h-8 text-primary-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="font-sans text-heading-lg text-primary-800 mb-3">Book Services</h3>
              <p className="text-body-md text-secondary-700 leading-relaxed mb-4">
                Rent equipment, get soil testing, and hire agricultural experts on demand
              </p>
              <Link href="/services">
                <Button variant="secondary" size="md" className="w-full">
                  Find Services
                </Button>
              </Link>
            </Card>

            <Card variant="interactive" padding="lg" className="text-center bg-gradient-to-br from-white to-success-50">
              <div className="w-16 h-16 bg-success-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-soft">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <h3 className="font-sans text-heading-lg text-primary-800 mb-3">Grow Business</h3>
              <p className="text-body-md text-secondary-700 leading-relaxed mb-4">
                Reach more customers and expand your agricultural business digitally
              </p>
              <Link href="/register">
                <Button variant="accent" size="md" className="w-full">
                  Get Started
                </Button>
              </Link>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="section bg-white">
        <div className="container-default">
          <div className="text-center mb-12">
            <h2 className="font-display text-display-md text-primary-800 mb-4">Featured Products</h2>
            <p className="text-body-lg text-secondary-700">Quality products from verified sellers</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {productsData?.products?.slice(0, 8).map((product: any) => (
              <Link 
                key={product.id} 
                href={`/products/${product.id}`}
              >
                <Card variant="interactive" padding="none" className="overflow-hidden h-full">
                  <div className="h-48 bg-gradient-to-br from-primary-100 to-accent-100 flex items-center justify-center overflow-hidden">
                    {product.images?.[0] ? (
                      <img 
                        src={product.images[0]} 
                        alt={product.name} 
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" 
                      />
                    ) : (
                      <svg className="w-16 h-16 text-primary-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                      </svg>
                    )}
                  </div>
                  <div className="p-5">
                    <h4 className="font-sans text-body-md font-semibold text-secondary-800 mb-1 truncate">
                      {product.name}
                    </h4>
                    <p className="text-body-sm text-secondary-600 mb-4">{product.category}</p>
                    <div className="flex justify-between items-center">
                      <span className="font-sans text-heading-md text-primary-600 font-semibold">
                        ₹{(product.pricePerUnit / 100).toFixed(2)}
                        <span className="text-body-sm text-secondary-600 font-normal">/{product.unit}</span>
                      </span>
                      <Badge variant="success">In Stock</Badge>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link href="/products">
              <Button variant="primary" size="lg">
                View All Products
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-lg bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-accent-200 opacity-10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary-500 opacity-20 rounded-full blur-3xl"></div>
        
        <div className="container-narrow relative z-10 text-center">
          <h2 className="font-display text-display-md text-white mb-6">
            Ready to grow your agricultural business?
          </h2>
          <p className="text-body-lg text-primary-100 mb-10 leading-relaxed">
            Join thousands of farmers, buyers, and sellers on India's leading digital agriculture platform
          </p>
          <Link href="/register">
            <Button variant="accent" size="lg" className="shadow-elevated">
              Get Started Today
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  )
}
