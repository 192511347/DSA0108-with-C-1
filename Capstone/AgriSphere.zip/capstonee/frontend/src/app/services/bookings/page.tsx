'use client'
import { useQuery } from '@tanstack/react-query'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import Link from 'next/link'
import { api } from '@/lib/api'
export default function BookingRequestsPage(){
 const {data,isLoading,error}=useQuery({queryKey:['service-requests'],queryFn:async()=>{const r=await api.get('/services/requests');return r.data.data?.requests||[]}})
 return <div className="min-h-screen flex flex-col"><Header/><main className="container-default py-10 flex-grow"><h1 className="text-3xl font-bold text-primary-800 mb-2">My Service Requests</h1><p className="mb-5">Saved in PostgreSQL. Status changes when a provider accepts the request.</p>{isLoading?<p>Loading...</p>:error?<p className="text-red-700">Unable to load requests: {(error as Error).message}</p>:!data?.length?<p>No requests. <Link href="/services" className="underline">Browse services</Link></p>:<div className="space-y-4">{data.map((r:any)=><article className="bg-white border rounded-xl p-5" key={r.id}><h2 className="text-xl font-bold">{r.serviceName}</h2><p className="text-sm text-gray-500">{r.id}</p><p>Status: <strong>{r.status}</strong></p><p>Location: {r.location} · Preferred date: {r.date||'Not specified'}</p><p>Notes: {r.message||'None'}</p></article>)}</div>}</main><Footer/></div>
}
