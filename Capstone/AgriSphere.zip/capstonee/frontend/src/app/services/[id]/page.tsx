'use client'

import { useParams } from 'next/navigation'
import Link from 'next/link'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { Card } from '@/components/ui/Card'

export default function ServiceDetailPage() {
  const params = useParams()
  const serviceId = params.id as string

  // TODO: Fetch service data from API
  // const { data: service } = useQuery(['service', serviceId], ...)

  return (
    <div className="min-h-screen flex flex-col bg-canvas">
      <Header />

      <main className="flex-grow py-12">
        <div className="container-default">
          <div className="max-w-5xl mx-auto">
            {/* Breadcrumb */}
            <nav className="mb-6 text-body-sm">
              <ol className="flex items-center gap-2 text-secondary-600">
                <li>
                  <Link href="/" className="hover:text-primary-600">
                    Home
                  </Link>
                </li>
                <li>/</li>
                <li>
                  <Link href="/services" className="hover:text-primary-600">
                    Services
                  </Link>
                </li>
                <li>/</li>
                <li className="text-secondary-800">Service Details</li>
              </ol>
            </nav>

            <Card className="p-8">
              <h1 className="font-display text-display-md text-primary-800 mb-4">
                Service Detail Page
              </h1>
              <p className="text-body-lg text-secondary-600 mb-6">
                Service ID: {serviceId}
              </p>
              <div className="bg-accent-50 border-2 border-accent-200 rounded-xl p-6">
                <h2 className="text-heading-md font-semibold text-secondary-800 mb-2">
                  🚧 Coming Soon
                </h2>
                <p className="text-body-md text-secondary-700 mb-4">
                  Service booking functionality is being implemented. This page will show:
                </p>
                <ul className="list-disc list-inside space-y-2 text-body-md text-secondary-700">
                  <li>Service details and description</li>
                  <li>Provider information</li>
                  <li>Pricing and availability</li>
                  <li>Booking form</li>
                  <li>Customer reviews</li>
                </ul>
              </div>
              <div className="mt-8">
                <Link href="/services">
                  <button className="btn btn-secondary">
                    ← Back to Services
                  </button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
