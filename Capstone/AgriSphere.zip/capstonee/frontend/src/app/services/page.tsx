'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { useRouter } from 'next/navigation'
import { Tractor, FlaskConical, Bug, UserCheck, Droplets, Shield, X, CheckCircle, Calendar, Clock, MapPin, Phone, Mail, User as UserIcon } from 'lucide-react'
import { Button } from '@/components/ui'
import { api } from '@/lib/api'

interface BookingModalProps {
  isOpen: boolean
  onClose: () => void
  serviceName: string
  price: string
  icon: any
}

function BookingModal({ isOpen, onClose, serviceName, price, icon: Icon }: BookingModalProps) {
  const [step, setStep] = useState<'form' | 'success'>('form')
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    location: '',
    date: '',
    message: ''
  })

  useEffect(() => {
    if (!isOpen) return
    const stored = localStorage.getItem('user')
    if (!stored) return
    try {
      const user = JSON.parse(stored)
      setFormData(prev => ({ ...prev, name: prev.name || user.fullName || '', phone: prev.phone || user.phone || '', email: prev.email || user.email || '', location: prev.location || [user.district, user.state].filter(Boolean).join(', ') }))
    } catch { /* invalid stored profile */ }
  }, [isOpen])

  if (!isOpen) return null

  const [submitError, setSubmitError] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [requestId, setRequestId] = useState('')
  useEffect(() => { if (isOpen) { setStep('form'); setSubmitError(''); setRequestId('') } }, [isOpen, serviceName])
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    setSubmitError('')
    try {
      const saved = await api.post('/services/requests', { serviceName, ...formData })
      setRequestId(saved.data.data?.id || '')
      setStep('success')
    } catch (err: any) {
      setSubmitError(err?.response?.data?.error?.message || err.message || 'Could not save request')
    } finally { setSubmitting(false) }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fadeIn"
      style={{
        animation: 'fadeIn 0.3s ease-out'
      }}
    >
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
        style={{
          animation: 'fadeIn 0.3s ease-out'
        }}
      />

      {/* Modal */}
      <div 
        className="relative bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden"
        style={{
          animation: 'slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1)'
        }}
      >
        {step === 'form' ? (
          <>
            {/* Header */}
            <div className="relative bg-gradient-to-r from-primary-600 to-primary-700 p-8 text-white">
              <button
                onClick={onClose}
                className="absolute top-4 right-4 p-2 hover:bg-white/20 rounded-full transition-all"
              >
                <X className="w-6 h-6" />
              </button>
              
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
                  <Icon className="w-8 h-8" />
                </div>
                <div>
                  <h2 className="text-3xl font-bold">{serviceName}</h2>
                  <p className="text-primary-100 text-lg">{price}</p>
                </div>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-8 overflow-y-auto max-h-[60vh]">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Name */}
                  <div className="group">
                    <label className="block text-sm font-semibold text-secondary-700 mb-2">
                      <UserIcon className="inline w-4 h-4 mr-2" />
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      placeholder="Enter your name"
                      className="w-full px-4 py-3 border-2 border-secondary-200 rounded-xl focus:border-primary-500 focus:outline-none transition-all group-hover:border-secondary-300"
                    />
                  </div>

                  {/* Phone */}
                  <div className="group">
                    <label className="block text-sm font-semibold text-secondary-700 mb-2">
                      <Phone className="inline w-4 h-4 mr-2" />
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      placeholder="Enter phone number"
                      className="w-full px-4 py-3 border-2 border-secondary-200 rounded-xl focus:border-primary-500 focus:outline-none transition-all group-hover:border-secondary-300"
                    />
                  </div>
                </div>

                {/* Email */}
                <div className="group">
                  <label className="block text-sm font-semibold text-secondary-700 mb-2">
                    <Mail className="inline w-4 h-4 mr-2" />
                    Email Address
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Enter email address"
                    className="w-full px-4 py-3 border-2 border-secondary-200 rounded-xl focus:border-primary-500 focus:outline-none transition-all group-hover:border-secondary-300"
                  />
                </div>

                {/* Location */}
                <div className="group">
                  <label className="block text-sm font-semibold text-secondary-700 mb-2">
                    <MapPin className="inline w-4 h-4 mr-2" />
                    Location *
                  </label>
                  <input
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                    required
                    placeholder="Village/Town, District"
                    className="w-full px-4 py-3 border-2 border-secondary-200 rounded-xl focus:border-primary-500 focus:outline-none transition-all group-hover:border-secondary-300"
                  />
                </div>

                {/* Preferred Date */}
                <div className="group">
                  <label className="block text-sm font-semibold text-secondary-700 mb-2">
                    <Calendar className="inline w-4 h-4 mr-2" />
                    Preferred Date
                  </label>
                  <input
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleChange}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-3 border-2 border-secondary-200 rounded-xl focus:border-primary-500 focus:outline-none transition-all group-hover:border-secondary-300"
                  />
                </div>

                {/* Additional Message */}
                <div className="group">
                  <label className="block text-sm font-semibold text-secondary-700 mb-2">
                    Additional Requirements
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={4}
                    placeholder="Tell us more about your requirements..."
                    className="w-full px-4 py-3 border-2 border-secondary-200 rounded-xl focus:border-primary-500 focus:outline-none transition-all group-hover:border-secondary-300 resize-none"
                  />
                </div>
              </div>

              {submitError && <p role="alert" className="text-red-700 mt-4">{submitError}</p>}
              {/* Submit Button */}
              <div className="mt-8 flex gap-4">
                <Button
                  type="button"
                  variant="secondary"
                  size="lg"
                  onClick={onClose}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="lg"
                  className="flex-1 bg-gradient-to-r from-primary-600 to-primary-700 hover:from-primary-700 hover:to-primary-800 shadow-lg"
                >
                  {submitting ? 'Submitting...' : 'Submit Booking Request'}
                </Button>
              </div>
            </form>
          </>
        ) : (
          /* Success State */
          <div className="p-12 text-center">
            <div 
              className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
              style={{
                animation: 'scaleIn 0.5s cubic-bezier(0.16, 1, 0.3, 1)'
              }}
            >
              <CheckCircle className="w-14 h-14 text-green-600" />
            </div>
            
            <h3 className="text-3xl font-bold text-primary-800 mb-4">
              Booking Request Submitted
            </h3>
            
            <p className="text-lg text-secondary-700 mb-2">
              Your request for <span className="font-semibold text-primary-600">{serviceName}</span> has been saved in AgriSphere and is available for providers to accept.
            </p>
            
            {requestId && <p className="text-sm text-gray-600 mt-3">Booking ID: <code>{requestId}</code></p>}
            <div className="inline-flex items-center gap-2 px-6 py-3 bg-blue-50 border-2 border-blue-200 rounded-xl mt-4">
              <Clock className="w-5 h-5 text-blue-600" />
              <p className="text-sm text-blue-800 font-medium">
                Request received. Waiting for a service provider to accept it.
              </p>
            </div>

            <div className="mt-8"><Link href="/services/bookings" className="text-primary-700 underline font-semibold">View my service requests</Link></div>
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(20px) scale(0.95);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }

        @keyframes scaleIn {
          0% {
            transform: scale(0);
            opacity: 0;
          }
          50% {
            transform: scale(1.1);
          }
          100% {
            transform: scale(1);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  )
}

export default function ServicesPage() {
  const router = useRouter()
  const [modalOpen, setModalOpen] = useState(false)
  const [selectedService, setSelectedService] = useState<any>(null)

  const services = [
    { id: 1, name: 'Equipment Rental', Icon: Tractor, description: 'Rent tractors, harvesters, and other farm equipment', price: '₹500-2000/day', color: 'from-blue-500 to-blue-600' },
    { id: 2, name: 'Soil Testing', Icon: FlaskConical, description: 'Professional soil analysis and fertility testing', price: '₹300-800/test', color: 'from-green-500 to-green-600' },
    { id: 3, name: 'Pest Management', Icon: Bug, description: 'Expert pest control and crop protection services', price: '₹1000-5000/acre', color: 'from-red-500 to-red-600' },
    { id: 4, name: 'Consultation', Icon: UserCheck, description: 'Agricultural advisory from experienced experts', price: '₹500-1500/session', color: 'from-purple-500 to-purple-600' },
    { id: 5, name: 'Irrigation Services', Icon: Droplets, description: 'Installation and maintenance of irrigation systems', price: '₹5000-50000', color: 'from-cyan-500 to-cyan-600' },
    { id: 6, name: 'Crop Insurance', Icon: Shield, description: 'Protect your crops with comprehensive insurance', price: '₹2000-10000/season', color: 'from-amber-500 to-amber-600' },
  ]

  const handleBooking = (service: typeof services[0]) => {
    // Check if user is logged in
    const token = localStorage.getItem('accessToken')
    if (!token) {
      router.push('/login')
      return
    }

    setSelectedService(service)
    setModalOpen(true)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow">
        {/* Hero Section */}
        <div className="relative bg-gradient-to-br from-primary-50 via-white to-accent-50 py-20 overflow-hidden">
          {/* Animated Background Elements */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary-200 opacity-20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent-200 opacity-20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary-100 border border-primary-300 rounded-full mb-6 animate-bounce">
              <span className="w-2 h-2 bg-primary-600 rounded-full animate-pulse" />
              <span className="text-sm font-semibold text-primary-800">Professional Services</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold text-primary-800 mb-6 animate-fadeIn">
              Agricultural Services
            </h1>
            <p className="text-xl text-secondary-700 max-w-3xl mx-auto animate-fadeIn" style={{ animationDelay: '0.2s' }}>
              Access professional agricultural services to enhance your farming operations
            </p>
          </div>
        </div>

        {/* Services Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.Icon
              return (
                <div 
                  key={service.id}
                  className="group relative bg-white rounded-2xl p-8 border-2 border-secondary-200 hover:border-primary-300 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 cursor-pointer"
                  style={{
                    animation: `fadeInUp 0.6s ease-out ${index * 0.1}s both`
                  }}
                >
                  {/* Icon with Gradient Background */}
                  <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center mb-6 transform group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-lg`}>
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  
                  <h3 className="text-2xl font-bold text-primary-800 mb-3 group-hover:text-primary-600 transition-colors">
                    {service.name}
                  </h3>
                  
                  <p className="text-secondary-700 mb-4 leading-relaxed">
                    {service.description}
                  </p>
                  
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-lg font-bold text-accent-600">
                      {service.price}
                    </span>
                    <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                      Available
                    </span>
                  </div>
                  
                  <Button
                    variant="primary"
                    size="lg"
                    className="w-full bg-gradient-to-r from-primary-600 to-primary-700 hover:from-primary-700 hover:to-primary-800 transform group-hover:scale-105 transition-all shadow-lg"
                    onClick={() => handleBooking(service)}
                  >
                    Book Now
                    <svg className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </Button>

                  {/* Hover Effect Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary-500/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                </div>
              )
            })}
          </div>

          {/* How It Works Section */}
          <div className="mt-20 bg-gradient-to-r from-primary-50 to-accent-50 border-2 border-primary-200 rounded-3xl p-12 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary-300 opacity-10 rounded-full blur-3xl" />
            
            <h2 className="text-4xl font-bold text-primary-800 mb-12 text-center">How It Works</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
              {[
                { step: 1, title: 'Select Service', desc: 'Choose the service you need from our offerings' },
                { step: 2, title: 'Fill Details', desc: 'Provide your information and requirements' },
                { step: 3, title: 'Get Service', desc: 'Provider contacts you and delivers the service' }
              ].map((item, index) => (
                <div 
                  key={item.step}
                  className="relative text-center group"
                  style={{
                    animation: `fadeInUp 0.8s ease-out ${index * 0.2 + 0.5}s both`
                  }}
                >
                  <div className="w-20 h-20 bg-gradient-to-br from-primary-600 to-primary-700 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-xl transform group-hover:scale-110 transition-all">
                    {item.step}
                  </div>
                  <h3 className="text-xl font-bold text-primary-800 mb-3">{item.title}</h3>
                  <p className="text-secondary-700">{item.desc}</p>
                  
                  {/* Connection Line */}
                  {index < 2 && (
                    <div className="hidden md:block absolute top-10 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-primary-300 to-transparent" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />

      {/* Booking Modal */}
      {selectedService && (
        <BookingModal
          isOpen={modalOpen}
          onClose={() => setModalOpen(false)}
          serviceName={selectedService.name}
          price={selectedService.price}
          icon={selectedService.Icon}
        />
      )}

      <style jsx global>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  )
}
