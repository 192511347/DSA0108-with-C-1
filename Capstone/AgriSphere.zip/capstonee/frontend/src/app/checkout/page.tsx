'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { api, cartApi } from '@/lib/api'

export default function Checkout() {
 const router=useRouter();const [cart,setCart]=useState<any>(null);const [address,setAddress]=useState('');const [busy,setBusy]=useState(false);const [error,setError]=useState('');const [done,setDone]=useState<any>(null)
 useEffect(()=>{cartApi.get().then(r=>setCart(r.data.data?.cart||r.data.data)).catch(()=>setError('Cannot load cart: please log in and ensure backend is running'));
 try{const u=JSON.parse(localStorage.getItem('user')||'{}');setAddress([u.address,u.district,u.state,u.pinCode].filter(Boolean).join(', '))}catch{}},[])
 async function pay(){if(!address.trim()){setError('Enter your delivery address');return}setBusy(true);setError('');try{const r=await api.post('/orders/checkout',{shippingAddress:address});setDone(r.data.data);setCart(null)}catch(e:any){setError(e?.response?.data?.error?.message||e.message)}finally{setBusy(false)}}
 const amount=Number(cart?.totalAmount||0)/100
 return <div className="min-h-screen flex flex-col bg-secondary-50"><Header/><main className="flex-1 container-default py-12 max-w-3xl"><h1 className="text-3xl font-bold text-primary-800 mb-6">Demo Checkout</h1>
 {done?<div className="rounded-xl bg-white border p-8 space-y-4"><h2 className="text-2xl font-bold text-green-700">Order confirmed</h2><p>Payment simulated — <strong>no money was charged.</strong></p><p>{done.orders?.length||0} order(s) saved to PostgreSQL with confirmed status.</p>{(done.orders||[]).map((o:any)=><p key={o.id}>Order ID: <code>{o.id}</code> — ₹{(Number(o.total)/100).toFixed(2)}</p>)}<Link className="underline text-primary-700" href="/dashboard/orders">View order history</Link></div>:<div className="rounded-xl bg-white border p-8 space-y-5"><p className="text-amber-800 font-medium">Mock payment only. No bank, card, UPI or external payment gateway is used.</p><p>Cart total: <strong>₹{amount.toFixed(2)}</strong></p><label className="block font-semibold">Delivery address<textarea className="block w-full border rounded-lg p-3 mt-2" rows={3} value={address} onChange={e=>setAddress(e.target.value)} required/></label><p>Payment method: <strong>Simulated payment (demo)</strong></p><button disabled={busy||!cart?.items?.length} className="bg-primary-700 text-white px-6 py-3 rounded-lg disabled:opacity-40" onClick={pay}>{busy?'Processing...':'Simulate Payment & Confirm Order'}</button><p><Link href="/cart" className="underline">Back to cart</Link></p></div>}
 {error&&<p role="alert" className="text-red-700 mt-4">{error}</p>}</main><Footer/></div>
}
