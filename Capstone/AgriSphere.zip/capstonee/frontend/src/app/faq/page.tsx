import Header from '@/components/Header'
import Footer from '@/components/Footer'

export default function FAQPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow bg-secondary-50 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-primary-800 mb-8">Frequently Asked Questions</h1>
          <div className="space-y-6">
            {[
              {q: 'What is AgriSphere?', a: 'AgriSphere is a digital agriculture platform connecting farmers, buyers, and sellers across India.'},
              {q: 'How do I register?', a: 'Click the Register button and fill out the form with your details.'},
              {q: 'Is it free to use?', a: 'Registration and browsing is free. Small transaction fees may apply for sales.'},
              {q: 'How do payments work?', a: 'We support multiple payment methods including UPI, cards, and net banking.'},
            ].map((faq, i) => (
              <div key={i} className="bg-white rounded-xl p-6 border-2 border-secondary-200">
                <h3 className="text-xl font-bold text-primary-800 mb-2">{faq.q}</h3>
                <p className="text-secondary-700">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
