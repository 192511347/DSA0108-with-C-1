import type { Metadata } from 'next'
import '@fontsource-variable/fraunces'
import '@fontsource-variable/plus-jakarta-sans'
import '@fontsource/noto-sans-tamil'
import '@fontsource/noto-sans-devanagari'
import './globals.css'
import { Providers } from './providers'

export const metadata: Metadata = {
  title: 'AgriSphere - Digital Agriculture Ecosystem',
  description: 'Connecting farmers, buyers, sellers, and service providers across India',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="font-sans antialiased bg-canvas text-secondary-800">
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  )
}
