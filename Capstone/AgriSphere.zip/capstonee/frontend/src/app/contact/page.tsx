import Header from '@/components/Header'
import Footer from '@/components/Footer'

export default function ContactPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow bg-secondary-50 py-16">
        <div className="max-w-3xl mx-auto px-4">
          <div className="bg-white rounded-xl p-8 border-2 border-secondary-200">
            <h1 className="text-4xl font-bold text-primary-800 mb-6">Contact Us</h1>
            <div className="space-y-4 text-secondary-700">
              <p className="text-lg"><strong>Email:</strong> support@agrisphere.in</p>
              <p className="text-lg"><strong>Phone:</strong> +91 1800 XXX XXXX</p>
              <p className="text-lg"><strong>Address:</strong> Digital Agriculture Hub, India</p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
