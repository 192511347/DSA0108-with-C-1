'use client'

import { useState } from 'react'
import { productApi, authApi } from '@/lib/api'
import { Button } from '@/components/ui'

export default function TestAPIPage() {
  const [healthResult, setHealthResult] = useState<any>(null)
  const [productsResult, setProductsResult] = useState<any>(null)
  const [loginResult, setLoginResult] = useState<any>(null)
  const [error, setError] = useState<string>('')

  const testHealth = async () => {
    try {
      setError('')
      const response = await fetch('http://localhost:6001/api/v1/health')
      const data = await response.json()
      setHealthResult(data)
    } catch (err: any) {
      setError(`Health check failed: ${err.message}`)
    }
  }

  const testProducts = async () => {
    try {
      setError('')
      const response = await productApi.list({ pageSize: 5 })
      setProductsResult(response.data)
    } catch (err: any) {
      setError(`Products failed: ${err.message}`)
    }
  }

  const testLogin = async () => {
    try {
      setError('')
      // Try with a user that exists
      const response = await authApi.login({
        email: 'buyer@agrisphere.in',
        password: 'password123' // Try default password
      })
      setLoginResult(response.data)
    } catch (err: any) {
      setError(`Login failed: ${err.response?.data?.error?.message || err.message}`)
    }
  }

  return (
    <div className="min-h-screen bg-secondary-50 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">API Testing Page</h1>

        {error && (
          <div className="bg-red-50 border-2 border-red-500 text-red-800 p-4 rounded-lg mb-6">
            {error}
          </div>
        )}

        <div className="space-y-6">
          {/* Health Check */}
          <div className="bg-white p-6 rounded-xl border-2 border-secondary-200">
            <h2 className="text-2xl font-bold mb-4">1. Health Check</h2>
            <Button onClick={testHealth} variant="primary">
              Test Health Endpoint
            </Button>
            {healthResult && (
              <pre className="mt-4 p-4 bg-secondary-100 rounded overflow-auto">
                {JSON.stringify(healthResult, null, 2)}
              </pre>
            )}
          </div>

          {/* Products */}
          <div className="bg-white p-6 rounded-xl border-2 border-secondary-200">
            <h2 className="text-2xl font-bold mb-4">2. Products API</h2>
            <Button onClick={testProducts} variant="primary">
              Test Products Endpoint
            </Button>
            {productsResult && (
              <pre className="mt-4 p-4 bg-secondary-100 rounded overflow-auto max-h-96">
                {JSON.stringify(productsResult, null, 2)}
              </pre>
            )}
          </div>

          {/* Login */}
          <div className="bg-white p-6 rounded-xl border-2 border-secondary-200">
            <h2 className="text-2xl font-bold mb-4">3. Login API</h2>
            <Button onClick={testLogin} variant="primary">
              Test Login Endpoint
            </Button>
            {loginResult && (
              <pre className="mt-4 p-4 bg-secondary-100 rounded overflow-auto">
                {JSON.stringify(loginResult, null, 2)}
              </pre>
            )}
          </div>

          {/* Database Users */}
          <div className="bg-white p-6 rounded-xl border-2 border-secondary-200">
            <h2 className="text-2xl font-bold mb-4">Available Test Users</h2>
            <div className="space-y-2 text-sm">
              <p><strong>Email:</strong> buyer@agrisphere.in</p>
              <p><strong>Email:</strong> vdmohanraj007@gmail.com</p>
              <p><strong>Email:</strong> seller1@agrisphere.in</p>
              <p className="text-red-600">Password needs to be checked in database or reset</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
