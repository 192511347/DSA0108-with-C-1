'use client'
import DashboardHighlights from '@/components/DashboardHighlights'

import { useQuery } from '@tanstack/react-query'
import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { authApi } from '@/lib/api'
import Link from 'next/link'
import { useEffect } from 'react'
import { Wrench, Calendar, TrendingUp, Plus, Eye, Edit, Clock, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui'

export default function ProviderDashboard() {
  const router = useRouter()

  useEffect(() => {
    const token = localStorage.getItem('accessToken')
    if (!token) {
      router.push('/login')
    }
  }, [router])

  const { data: userData } = useQuery({
    queryKey: ['user'],
    queryFn: async () => {
      const response = await authApi.me()
      return response.data.data
    },
  })

  // Mock service data (replace with actual API call)
  const myServices = [
    { id: 1, name: 'Tractor Rental - 45HP', category: 'EQUIPMENT_RENTAL', price: 800, unit: 'DAY', bookings: 12 },
    { id: 2, name: 'Drone Spraying Service', category: 'TECHNOLOGY', price: 400, unit: 'ACRE', bookings: 8 },
    { id: 3, name: 'Soil Testing & Analysis', category: 'CONSULTATION', price: 500, unit: 'TEST', bookings: 15 },
  ]

  const totalServices = myServices.length
  const totalBookings = myServices.reduce((sum, s) => sum + s.bookings, 0)
  const pendingRequests = 3
  const completedToday = 2

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow bg-secondary-50 py-8">
        <div className="container-default py-4"><DashboardHighlights /></div>
        <div className="container-default py-3 flex flex-wrap gap-5"><a href="/dashboard/insights" className="underline text-primary-700 font-semibold">Dashboard Insights</a><a href="/dashboard/orders" className="underline text-primary-700 font-semibold">Orders & Sales</a><a href="/services/bookings" className="underline text-primary-700 font-semibold">Service Requests</a><a href="/services/opportunities" className="underline text-primary-700 font-semibold">Find Customers</a><a href="/advisory" className="underline text-primary-700 font-semibold">AI Advisory</a></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <Wrench className="w-8 h-8 text-primary-600" />
              <h1 className="text-4xl font-bold text-primary-800">Service Provider Dashboard</h1>
            </div>
            <p className="text-lg text-secondary-600">
              Welcome back, {userData?.fullName}! Manage your services and bookings.
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <Wrench className="w-10 h-10 text-primary-600" />
                <span className="text-3xl font-bold text-primary-800">{totalServices}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Active Services</h3>
              <p className="text-sm text-secondary-600 mt-1">Listed services</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-green-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <Calendar className="w-10 h-10 text-green-600" />
                <span className="text-3xl font-bold text-green-800">{totalBookings}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Total Bookings</h3>
              <p className="text-sm text-secondary-600 mt-1">All time</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-orange-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <Clock className="w-10 h-10 text-orange-600" />
                <span className="text-3xl font-bold text-orange-800">{pendingRequests}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Pending Requests</h3>
              <p className="text-sm text-secondary-600 mt-1">Awaiting response</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-accent-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <CheckCircle className="w-10 h-10 text-accent-600" />
                <span className="text-3xl font-bold text-accent-800">{completedToday}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Completed Today</h3>
              <p className="text-sm text-secondary-600 mt-1">Services delivered</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 mb-8">
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Quick Actions</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                variant="primary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/services/create')}
              >
                <Plus className="w-5 h-5" />
                Add New Service
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/services')}
              >
                <Eye className="w-5 h-5" />
                View All Services
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/dashboard/bookings')}
              >
                <Calendar className="w-5 h-5" />
                Manage Bookings
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/dashboard/profile')}
              >
                <Edit className="w-5 h-5" />
                Edit Profile
              </Button>
            </div>
          </div>

          {/* Booking Requests */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-primary-800">Pending Booking Requests</h2>
              <span className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-semibold">
                {pendingRequests} New
              </span>
            </div>

            <div className="space-y-4">
              <div className="p-4 border-2 border-orange-200 rounded-xl bg-orange-50">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-lg text-secondary-800">Tractor Rental Request</h3>
                    <p className="text-sm text-secondary-600">Ramesh Kumar · 5 acres land preparation</p>
                  </div>
                  <span className="px-2 py-1 bg-orange-200 text-orange-800 rounded text-sm font-medium">Pending</span>
                </div>
                <div className="flex items-center gap-4 mb-3">
                  <span className="text-sm text-secondary-600">📅 Tomorrow, 8:00 AM</span>
                  <span className="text-sm font-semibold text-primary-600">₹800/day</span>
                </div>
                <div className="flex gap-3">
                  <Button variant="primary" size="sm">Accept</Button>
                  <Button variant="secondary" size="sm">Decline</Button>
                  <Button variant="secondary" size="sm">Message Customer</Button>
                </div>
              </div>

              <div className="p-4 border-2 border-orange-200 rounded-xl bg-orange-50">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-lg text-secondary-800">Soil Testing Request</h3>
                    <p className="text-sm text-secondary-600">Priya Sharma · 3 samples needed</p>
                  </div>
                  <span className="px-2 py-1 bg-orange-200 text-orange-800 rounded text-sm font-medium">Pending</span>
                </div>
                <div className="flex items-center gap-4 mb-3">
                  <span className="text-sm text-secondary-600">📅 Nov 12, 10:00 AM</span>
                  <span className="text-sm font-semibold text-primary-600">₹1,500 total</span>
                </div>
                <div className="flex gap-3">
                  <Button variant="primary" size="sm">Accept</Button>
                  <Button variant="secondary" size="sm">Decline</Button>
                  <Button variant="secondary" size="sm">Message Customer</Button>
                </div>
              </div>
            </div>
          </div>

          {/* My Services */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-primary-800">My Services</h2>
              <Link href="/services/create" className="text-primary-600 font-medium hover:underline">
                + Add New Service
              </Link>
            </div>

            {myServices && myServices.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {myServices.map((service) => (
                  <div key={service.id} className="border-2 border-secondary-200 rounded-xl p-4 hover:border-primary-300 transition-all">
                    <div className="flex items-center gap-2 mb-3">
                      <Wrench className="w-5 h-5 text-primary-600" />
                      <span className="text-xs font-medium text-secondary-600 uppercase">{service.category}</span>
                    </div>
                    <h3 className="font-semibold text-lg text-secondary-800 mb-2">{service.name}</h3>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xl font-bold text-primary-600">
                        ₹{service.price}/{service.unit}
                      </span>
                      <span className="text-sm text-secondary-600">{service.bookings} bookings</span>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="secondary" size="sm" className="flex-1">Edit</Button>
                      <Button variant="secondary" size="sm" className="flex-1">View Stats</Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Wrench className="w-16 h-16 text-secondary-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-secondary-800 mb-2">No Services Listed</h3>
                <p className="text-secondary-600 mb-6">Start offering your agricultural services</p>
                <Button variant="primary" onClick={() => router.push('/services/create')}>
                  Add Your First Service
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
