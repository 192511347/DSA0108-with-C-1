'use client'
import DashboardHighlights from '@/components/DashboardHighlights'

import { useQuery } from '@tanstack/react-query'
import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { authApi, productApi } from '@/lib/api'
import Link from 'next/link'
import { useEffect } from 'react'
import { Store, Package, TrendingUp, Plus, Eye, Edit, DollarSign, BarChart3 } from 'lucide-react'
import { Button } from '@/components/ui'

export default function SellerDashboard() {
  const router = useRouter()

  useEffect(() => {
    const token = localStorage.getItem('accessToken')
    if (!token) {
      router.push('/login')
    }
  }, [router])

  const { data: userData } = useQuery({
    queryKey: ['user'],
    queryFn: async () => {
      const response = await authApi.me()
      return response.data.data
    },
  })

  const { data: myProducts } = useQuery({
    queryKey: ['my-products'],
    queryFn: async () => {
      const response = await productApi.getMyProducts()
      return response.data.data.products || []
    },
  })

  const totalProducts = myProducts?.length || 0
  const totalRevenue = myProducts?.reduce((sum: number, p: any) => {
    // Estimate revenue based on sold quantity (assume 30% of stock sold)
    const soldQty = Math.floor(p.availableQuantity * 0.3)
    return sum + (p.pricePerUnit * soldQty)
  }, 0) || 0
  const activeProducts = myProducts?.filter((p: any) => p.availableQuantity > 0)?.length || 0
  const lowStockProducts = myProducts?.filter((p: any) => p.availableQuantity > 0 && p.availableQuantity < 50)?.length || 0

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow bg-secondary-50 py-8">
        <div className="container-default py-4"><DashboardHighlights /></div>
        <div className="container-default py-3 flex flex-wrap gap-5"><a href="/dashboard/insights" className="underline text-primary-700 font-semibold">Dashboard Insights</a><a href="/dashboard/orders" className="underline text-primary-700 font-semibold">Orders & Sales</a><a href="/services/bookings" className="underline text-primary-700 font-semibold">Service Requests</a><a href="/advisory" className="underline text-primary-700 font-semibold">AI Advisory</a></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <Store className="w-8 h-8 text-primary-600" />
              <h1 className="text-4xl font-bold text-primary-800">Seller Dashboard</h1>
            </div>
            <p className="text-lg text-secondary-600">
              Welcome back, {userData?.fullName}! Manage your store and track sales.
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <Package className="w-10 h-10 text-primary-600" />
                <span className="text-3xl font-bold text-primary-800">{totalProducts}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Total Products</h3>
              <p className="text-sm text-secondary-600 mt-1">Listed on marketplace</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-green-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <TrendingUp className="w-10 h-10 text-green-600" />
                <span className="text-3xl font-bold text-green-800">{activeProducts}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Active Listings</h3>
              <p className="text-sm text-secondary-600 mt-1">In stock</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-accent-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <DollarSign className="w-10 h-10 text-accent-600" />
                <span className="text-3xl font-bold text-accent-800">
                  ₹{(totalRevenue / 1000).toFixed(1)}k
                </span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Est. Revenue</h3>
              <p className="text-sm text-secondary-600 mt-1">Estimated sales value</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-orange-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <BarChart3 className="w-10 h-10 text-orange-600" />
                <span className="text-3xl font-bold text-orange-800">{lowStockProducts}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Low Stock</h3>
              <p className="text-sm text-secondary-600 mt-1">Items below 50 units</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 mb-8">
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Quick Actions</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                variant="primary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/products/create')}
              >
                <Plus className="w-5 h-5" />
                Add New Product
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/products')}
              >
                <Eye className="w-5 h-5" />
                View Marketplace
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/dashboard/orders')}
              >
                <Package className="w-5 h-5" />
                Manage Orders
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/dashboard/profile')}
              >
                <Edit className="w-5 h-5" />
                Edit Profile
              </Button>
            </div>
          </div>

          {/* Sales Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
              <h2 className="text-2xl font-bold text-primary-800 mb-4">Top Categories</h2>
              <div className="space-y-3">
                {['GRAINS', 'VEGETABLES', 'FRUITS', 'DAIRY', 'SPICES'].map((category) => {
                  const categoryProducts = myProducts?.filter((p: any) => p.category === category) || []
                  const count = categoryProducts.length
                  return (
                    <div key={category} className="flex items-center justify-between p-3 bg-secondary-50 rounded-lg">
                      <span className="font-medium text-secondary-800">{category}</span>
                      <span className="text-primary-600 font-semibold">{count} products</span>
                    </div>
                  )
                })}
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
              <h2 className="text-2xl font-bold text-primary-800 mb-4">Recent Activity</h2>
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium text-secondary-800">Store Active</p>
                    <p className="text-sm text-secondary-600">All systems operational</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium text-secondary-800">{totalProducts} Products Listed</p>
                    <p className="text-sm text-secondary-600">Ready for customers</p>
                  </div>
                </div>
                {lowStockProducts > 0 && (
                  <div className="flex items-start gap-3 p-3 bg-orange-50 rounded-lg">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-secondary-800">{lowStockProducts} Items Low Stock</p>
                      <p className="text-sm text-secondary-600">Consider restocking soon</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* My Products List */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-primary-800">My Products</h2>
              <Link href="/products/create" className="text-primary-600 font-medium hover:underline">
                + Add New Product
              </Link>
            </div>

            {myProducts && myProducts.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b-2 border-secondary-200">
                      <th className="text-left py-3 px-4 font-semibold text-secondary-800">Product</th>
                      <th className="text-left py-3 px-4 font-semibold text-secondary-800">Category</th>
                      <th className="text-left py-3 px-4 font-semibold text-secondary-800">Price</th>
                      <th className="text-left py-3 px-4 font-semibold text-secondary-800">Stock</th>
                      <th className="text-left py-3 px-4 font-semibold text-secondary-800">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {myProducts.slice(0, 10).map((product: any) => (
                      <tr key={product.id} className="border-b border-secondary-200 hover:bg-secondary-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            {product.imageUrl ? (
                              <img src={product.imageUrl} alt={product.name} className="w-12 h-12 object-cover rounded-lg" />
                            ) : (
                              <div className="w-12 h-12 bg-secondary-200 rounded-lg flex items-center justify-center">
                                <Package className="w-6 h-6 text-secondary-400" />
                              </div>
                            )}
                            <span className="font-medium text-secondary-800">{product.name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-secondary-600">{product.category}</td>
                        <td className="py-3 px-4 font-semibold text-primary-600">₹{product.price}/{product.unit}</td>
                        <td className="py-3 px-4">
                          <span className={`${product.quantity < 50 ? 'text-orange-600' : 'text-secondary-600'}`}>
                            {product.quantity} {product.unit}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 rounded text-sm ${
                            product.quantity > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {product.quantity > 0 ? 'In Stock' : 'Out of Stock'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {myProducts.length > 10 && (
                  <p className="text-center text-secondary-600 mt-4">
                    Showing 10 of {myProducts.length} products
                  </p>
                )}
              </div>
            ) : (
              <div className="text-center py-12">
                <Store className="w-16 h-16 text-secondary-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-secondary-800 mb-2">No Products Listed</h3>
                <p className="text-secondary-600 mb-6">Start adding products to your store</p>
                <Button variant="primary" onClick={() => router.push('/products/create')}>
                  Add Your First Product
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
