'use client'

import { useQuery } from '@tanstack/react-query'
import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { authApi } from '@/lib/api'
import { useEffect } from 'react'
import { Shield, Users, Package, Wrench, TrendingUp, AlertCircle, CheckCircle, Clock } from 'lucide-react'
import { Button } from '@/components/ui'

export default function AdminDashboard() {
  const router = useRouter()

  useEffect(() => {
    const token = localStorage.getItem('accessToken')
    if (!token) {
      router.push('/login')
    }
  }, [router])

  const { data: userData } = useQuery({
    queryKey: ['user'],
    queryFn: async () => {
      const response = await authApi.me()
      return response.data.data
    },
  })

  // Mock stats (replace with actual API calls)
  const stats = {
    totalUsers: 156,
    newUsersToday: 8,
    totalProducts: 342,
    totalServices: 48,
    pendingApprovals: 5,
    activeOrders: 23,
    flaggedContent: 2,
    systemHealth: 98
  }

  const pendingApprovals = [
    { id: 1, type: 'SELLER', name: 'Green Valley Agro', email: 'contact@greenvalley.com', date: '2 hours ago' },
    { id: 2, type: 'SERVICE_PROVIDER', name: 'Farm Equipment Rentals', email: 'info@farmequip.com', date: '5 hours ago' },
    { id: 3, type: 'PRODUCT', name: 'Organic Red Chilli Powder', seller: 'Spice Hub', date: '1 day ago' },
  ]

  const recentActivity = [
    { id: 1, action: 'New user registered', user: 'Ramesh K.', role: 'FARMER', time: '10 mins ago' },
    { id: 2, action: 'Product listed', user: 'Meera Patel', product: 'Fresh Tomatoes', time: '25 mins ago' },
    { id: 3, action: 'Service booked', user: 'Anita S.', service: 'Tractor Rental', time: '1 hour ago' },
    { id: 4, action: 'Seller approved', user: 'Vikram Singh', role: 'SELLER', time: '2 hours ago' },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow bg-secondary-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <Shield className="w-8 h-8 text-primary-600" />
              <h1 className="text-4xl font-bold text-primary-800">Admin Dashboard</h1>
            </div>
            <p className="text-lg text-secondary-600">
              Welcome back, {userData?.fullName}! System overview and management tools.
            </p>
          </div>

          {/* System Health Alert */}
          <div className="bg-green-50 border-2 border-green-200 rounded-xl p-4 mb-8 flex items-center gap-3">
            <CheckCircle className="w-6 h-6 text-green-600" />
            <div className="flex-grow">
              <h3 className="font-semibold text-green-800">System Status: Operational</h3>
              <p className="text-sm text-green-700">All services running smoothly · Uptime: 99.8%</p>
            </div>
            <span className="text-2xl font-bold text-green-800">{stats.systemHealth}%</span>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <Users className="w-10 h-10 text-primary-600" />
                <span className="text-3xl font-bold text-primary-800">{stats.totalUsers}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Total Users</h3>
              <p className="text-sm text-green-600 mt-1">+{stats.newUsersToday} today</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <Package className="w-10 h-10 text-blue-600" />
                <span className="text-3xl font-bold text-blue-800">{stats.totalProducts}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Total Products</h3>
              <p className="text-sm text-secondary-600 mt-1">Listed on marketplace</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <Wrench className="w-10 h-10 text-purple-600" />
                <span className="text-3xl font-bold text-purple-800">{stats.totalServices}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Total Services</h3>
              <p className="text-sm text-secondary-600 mt-1">Active offerings</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-orange-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <Clock className="w-10 h-10 text-orange-600" />
                <span className="text-3xl font-bold text-orange-800">{stats.pendingApprovals}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Pending Approvals</h3>
              <p className="text-sm text-orange-600 mt-1">Requires attention</p>
            </div>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
              <div className="flex items-center gap-3 mb-3">
                <TrendingUp className="w-6 h-6 text-green-600" />
                <h3 className="font-semibold text-lg text-secondary-800">Active Orders</h3>
              </div>
              <p className="text-3xl font-bold text-primary-800 mb-1">{stats.activeOrders}</p>
              <p className="text-sm text-secondary-600">Orders being processed</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
              <div className="flex items-center gap-3 mb-3">
                <AlertCircle className="w-6 h-6 text-orange-600" />
                <h3 className="font-semibold text-lg text-secondary-800">Flagged Content</h3>
              </div>
              <p className="text-3xl font-bold text-orange-800 mb-1">{stats.flaggedContent}</p>
              <p className="text-sm text-secondary-600">Items needing review</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
              <div className="flex items-center gap-3 mb-3">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <h3 className="font-semibold text-lg text-secondary-800">System Health</h3>
              </div>
              <p className="text-3xl font-bold text-green-800 mb-1">{stats.systemHealth}%</p>
              <p className="text-sm text-secondary-600">All systems operational</p>
            </div>
          </div>

          {/* Pending Approvals */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-primary-800">Pending Approvals</h2>
              <span className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-semibold">
                {stats.pendingApprovals} Pending
              </span>
            </div>

            <div className="space-y-4">
              {pendingApprovals.map((item) => (
                <div key={item.id} className="p-4 border-2 border-secondary-200 rounded-xl hover:border-primary-300 transition-all">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-grow">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`px-2 py-1 rounded text-xs font-semibold ${
                          item.type === 'SELLER' ? 'bg-blue-100 text-blue-800' :
                          item.type === 'SERVICE_PROVIDER' ? 'bg-purple-100 text-purple-800' :
                          'bg-green-100 text-green-800'
                        }`}>
                          {item.type}
                        </span>
                        <span className="text-sm text-secondary-600">{item.date}</span>
                      </div>
                      <h3 className="font-semibold text-lg text-secondary-800">{item.name}</h3>
                      <p className="text-sm text-secondary-600">
                        {item.email || item.seller}
                      </p>
                    </div>
                    <span className="px-2 py-1 bg-orange-100 text-orange-800 rounded text-sm font-medium">Pending</span>
                  </div>
                  <div className="flex gap-3">
                    <Button variant="primary" size="sm">Approve</Button>
                    <Button variant="secondary" size="sm">Reject</Button>
                    <Button variant="secondary" size="sm">View Details</Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 mb-8">
            <h2 className="text-2xl font-bold text-primary-800 mb-6">Recent Activity</h2>
            <div className="space-y-3">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3 p-3 bg-secondary-50 rounded-lg">
                  <div className="w-2 h-2 bg-primary-500 rounded-full mt-2"></div>
                  <div className="flex-grow">
                    <p className="font-medium text-secondary-800">
                      {activity.action}
                      {activity.product && ` - ${activity.product}`}
                      {activity.service && ` - ${activity.service}`}
                    </p>
                    <p className="text-sm text-secondary-600">
                      {activity.user}
                      {activity.role && ` (${activity.role})`} · {activity.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Admin Tools</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                variant="primary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/admin/users')}
              >
                <Users className="w-5 h-5" />
                Manage Users
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/admin/products')}
              >
                <Package className="w-5 h-5" />
                Manage Products
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/admin/services')}
              >
                <Wrench className="w-5 h-5" />
                Manage Services
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/admin/reports')}
              >
                <TrendingUp className="w-5 h-5" />
                View Reports
              </Button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
