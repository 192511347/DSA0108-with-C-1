'use client'
import DashboardHighlights from '@/components/DashboardHighlights'

import { useQuery } from '@tanstack/react-query'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { cartApi } from '@/lib/api'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ShoppingCart, Package, Search, Clock } from 'lucide-react'
import { Button } from '@/components/ui'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import { useAuth } from '@/contexts/AuthContext'

function BuyerDashboardContent() {
  const { user } = useAuth()
  const router = useRouter()

  const { data: cart, isLoading } = useQuery({
    queryKey: ['cart'],
    queryFn: async () => {
      const response = await cartApi.get()
      return response.data.data
    },
  })

  const cartItems = cart?.items?.length || 0
  const cartTotal = (cart?.totalAmount || 0) / 100

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow bg-secondary-50 py-8">
        <div className="container-default py-4"><DashboardHighlights /></div>
        <div className="container-default py-3 flex flex-wrap gap-5"><a href="/dashboard/insights" className="underline text-primary-700 font-semibold">Dashboard Insights</a><a href="/dashboard/orders" className="underline text-primary-700 font-semibold">Orders & Sales</a><a href="/services/bookings" className="underline text-primary-700 font-semibold">Service Requests</a><a href="/advisory" className="underline text-primary-700 font-semibold">AI Advisory</a></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <ShoppingCart className="w-8 h-8 text-primary-600" />
              <h1 className="text-4xl font-bold text-primary-800">Buyer Dashboard</h1>
            </div>
            <p className="text-lg text-secondary-600">
              Welcome back, {user?.fullName || 'Buyer'}! Discover fresh agricultural products.
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <ShoppingCart className="w-10 h-10 text-primary-600" />
                <span className="text-3xl font-bold text-primary-800">{cartItems}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Cart Items</h3>
              <p className="text-sm text-secondary-600 mt-1">Ready to checkout</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-accent-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <span className="text-2xl">₹</span>
                <span className="text-3xl font-bold text-accent-800">
                  {cartTotal.toFixed(0)}
                </span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Cart Total</h3>
              <p className="text-sm text-secondary-600 mt-1">Current basket value</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-green-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <Package className="w-10 h-10 text-green-600" />
                <span className="text-3xl font-bold text-green-800">0</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Past Orders</h3>
              <p className="text-sm text-secondary-600 mt-1">Coming soon</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 mb-8">
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Quick Actions</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Link href="/products">
                <Button variant="primary" size="lg" className="w-full flex items-center justify-center gap-2">
                  <Search className="w-5 h-5" />
                  Browse Products
                </Button>
              </Link>
              <Link href="/cart">
                <Button variant="accent" size="lg" className="w-full flex items-center justify-center gap-2">
                  <ShoppingCart className="w-5 h-5" />
                  View Cart ({cartItems})
                </Button>
              </Link>
              <Link href="/dashboard/orders">
                <Button variant="secondary" size="lg" className="w-full flex items-center justify-center gap-2">
                  <Package className="w-5 h-5" />
                  My Orders
                </Button>
              </Link>
              <Link href="/services">
                <Button variant="secondary" size="lg" className="w-full flex items-center justify-center gap-2">
                  <Clock className="w-5 h-5" />
                  Book Services
                </Button>
              </Link>
            </div>
          </div>

          {/* Shopping Categories */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 mb-8">
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Shop by Category</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {['GRAINS', 'VEGETABLES', 'FRUITS', 'DAIRY', 'SPICES'].map((category) => (
                <Link
                  key={category}
                  href={`/products?category=${category}`}
                  className="bg-gradient-to-br from-primary-50 to-accent-50 rounded-xl p-6 text-center hover:shadow-lg transition-all border-2 border-secondary-200 hover:border-primary-300"
                >
                  <div className="text-4xl mb-2">
                    {category === 'GRAINS' && '🌾'}
                    {category === 'VEGETABLES' && '🥬'}
                    {category === 'FRUITS' && '🍎'}
                    {category === 'DAIRY' && '🥛'}
                    {category === 'SPICES' && '🌶️'}
                  </div>
                  <h3 className="font-semibold text-primary-800">{category}</h3>
                </Link>
              ))}
            </div>
          </div>

          {/* Current Cart */}
          {!isLoading && cart && cart.items && cart.items.length > 0 && (
            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-primary-800">Your Cart</h2>
                <Link href="/cart" className="text-primary-600 font-medium hover:underline">
                  View Full Cart →
                </Link>
              </div>

              <div className="space-y-4">
                {cart.items.slice(0, 3).map((item: any) => (
                  <div key={item.id} className="flex items-center gap-4 p-4 border-2 border-secondary-200 rounded-xl">
                    {item.imageUrl ? (
                      <img src={item.imageUrl} alt={item.productName} className="w-20 h-20 object-cover rounded-lg" />
                    ) : (
                      <div className="w-20 h-20 bg-secondary-100 rounded-lg flex items-center justify-center">
                        <Package className="w-8 h-8 text-secondary-400" />
                      </div>
                    )}
                    <div className="flex-grow">
                      <h3 className="font-semibold text-secondary-800">{item.productName}</h3>
                      <p className="text-sm text-secondary-600">Quantity: {item.quantity} {item.unit}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-primary-600">
                        ₹{((item.subtotal || 0) / 100).toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}

                {cart.items.length > 3 && (
                  <p className="text-center text-secondary-600">
                    + {cart.items.length - 3} more items
                  </p>
                )}
              </div>

              <div className="mt-6 pt-6 border-t-2 border-secondary-200">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-xl font-semibold text-secondary-800">Total:</span>
                  <span className="text-2xl font-bold text-primary-600">₹{cartTotal.toFixed(2)}</span>
                </div>
                <Link href="/cart">
                  <Button variant="accent" size="lg" className="w-full">
                    Proceed to Checkout
                  </Button>
                </Link>
              </div>
            </div>
          )}

          {!isLoading && (!cart || !cart.items || cart.items.length === 0) && (
            <div className="bg-white rounded-xl p-12 border-2 border-secondary-200 text-center">
              <ShoppingCart className="w-16 h-16 text-secondary-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-secondary-800 mb-2">Your cart is empty</h3>
              <p className="text-secondary-600 mb-6">Start shopping to add products to your cart</p>
              <Link href="/products">
                <Button variant="primary">
                  Browse Products
                </Button>
              </Link>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}

export default function BuyerDashboard() {
  return (
    <ProtectedRoute requiredRole={['BUYER']}>
      <BuyerDashboardContent />
    </ProtectedRoute>
  )
}
