'use client'

import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import Link from 'next/link'
import { useEffect } from 'react'
import { User, Package, ShoppingCart } from 'lucide-react'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import { useAuth } from '@/contexts/AuthContext'

function DashboardContent() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  // Redirect to role-specific dashboard
  useEffect(() => {
    if (user?.role) {
      switch (user.role) {
        case 'FARMER':
          router.push('/dashboard/farmer')
          break
        case 'BUYER':
          router.push('/dashboard/buyer')
          break
        case 'SELLER':
          router.push('/dashboard/seller')
          break
        case 'SERVICE_PROVIDER':
          router.push('/dashboard/provider')
          break
        case 'ADMIN':
          router.push('/dashboard/admin')
          break
        default:
          // Stay on generic dashboard
          break
      }
    }
  }, [user, router])

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow bg-secondary-50 py-8 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
            <p className="text-secondary-600">Loading your dashboard...</p>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow bg-secondary-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-primary-800 mb-8">Dashboard</h1>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
              <User className="w-10 h-10 text-primary-600 mb-3" />
              <h3 className="font-semibold text-lg text-secondary-800 mb-2">Profile</h3>
              <p className="text-secondary-600 text-sm mb-4">Manage your account details</p>
              <Link href="/dashboard/profile" className="text-primary-600 font-medium hover:underline">
                View Profile →
              </Link>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
              <Package className="w-10 h-10 text-primary-600 mb-3" />
              <h3 className="font-semibold text-lg text-secondary-800 mb-2">Orders</h3>
              <p className="text-secondary-600 text-sm mb-4">Track your order history</p>
              <Link href="/dashboard/orders" className="text-primary-600 font-medium hover:underline">
                View Orders →
              </Link>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
              <ShoppingCart className="w-10 h-10 text-primary-600 mb-3" />
              <h3 className="font-semibold text-lg text-secondary-800 mb-2">Cart</h3>
              <p className="text-secondary-600 text-sm mb-4">View your shopping cart</p>
              <Link href="/cart" className="text-primary-600 font-medium hover:underline">
                Go to Cart →
              </Link>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Account Information</h2>
            {user && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-secondary-600">Full Name</label>
                  <p className="text-lg text-secondary-800">{user.fullName}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-secondary-600">Email</label>
                  <p className="text-lg text-secondary-800">{user.email}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-secondary-600">Phone</label>
                  <p className="text-lg text-secondary-800">{user.phone}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-secondary-600">Role</label>
                  <p className="text-lg text-secondary-800">{user.role}</p>
                </div>
                {user.district && (
                  <div>
                    <label className="text-sm font-medium text-secondary-600">Location</label>
                    <p className="text-lg text-secondary-800">{user.district}, {user.state}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

export default function DashboardPage() {
  return (
    <ProtectedRoute>
      <DashboardContent />
    </ProtectedRoute>
  )
}
