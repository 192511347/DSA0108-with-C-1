'use client'
import DashboardHighlights from '@/components/DashboardHighlights'

import { useQuery } from '@tanstack/react-query'
import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { authApi, productApi } from '@/lib/api'
import Link from 'next/link'
import { useEffect } from 'react'
import { Sprout, Package, TrendingUp, Plus, Eye, Edit } from 'lucide-react'
import { Button } from '@/components/ui'

export default function FarmerDashboard() {
  const router = useRouter()

  useEffect(() => {
    const token = localStorage.getItem('accessToken')
    if (!token) {
      router.push('/login')
    }
  }, [router])

  const { data: userData } = useQuery({
    queryKey: ['user'],
    queryFn: async () => {
      const response = await authApi.me()
      return response.data.data
    },
  })

  const { data: myProducts, isError: myProductsError, error: myProductsErrorDetail } = useQuery({
    queryKey: ['my-products'],
    queryFn: async () => {
      const response = await productApi.getMyProducts()
      return response.data.data?.products || []
    },
  })

  const totalProducts = myProducts?.length || 0
  const totalValue = myProducts?.reduce((sum: number, p: any) => sum + (p.pricePerUnit * p.availableQuantity), 0) || 0
  const activeProducts = myProducts?.filter((p: any) => p.availableQuantity > 0)?.length || 0

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow bg-secondary-50 py-8">
        <div className="container-default py-4"><DashboardHighlights /></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <Sprout className="w-8 h-8 text-primary-600" />
              <h1 className="text-4xl font-bold text-primary-800">Farmer Dashboard</h1>
            </div>
            <p className="text-lg text-secondary-600">
              Welcome back, {userData?.fullName}! Manage your products and farm operations.
            </p>
          </div>

          <div className="mb-6 bg-white border rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
            <div><h2 className="font-bold text-xl">Farm Insights & Crop Advisory</h2><p className="text-sm text-gray-500">Product views, sales trends, land details, and currently sown crops</p></div>
            <div className="flex gap-4"><Link href="/dashboard/insights" className="underline text-primary-700 font-semibold">Analytics & Land Profile</Link><Link href="/advisory" className="underline text-primary-700 font-semibold">AI Advisory</Link><Link href="/services/bookings" className="underline text-primary-700 font-semibold">Service Requests</Link></div>
          </div>
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <Package className="w-10 h-10 text-primary-600" />
                <span className="text-3xl font-bold text-primary-800">{totalProducts}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Total Products</h3>
              <p className="text-sm text-secondary-600 mt-1">Listed on marketplace</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-green-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <TrendingUp className="w-10 h-10 text-green-600" />
                <span className="text-3xl font-bold text-green-800">{activeProducts}</span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Active Listings</h3>
              <p className="text-sm text-secondary-600 mt-1">Products in stock</p>
            </div>

            <div className="bg-white rounded-xl p-6 border-2 border-accent-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <span className="text-2xl">₹</span>
                <span className="text-3xl font-bold text-accent-800">
                  {(totalValue / 100000).toFixed(1)}k
                </span>
              </div>
              <h3 className="font-semibold text-lg text-secondary-800">Inventory Value</h3>
              <p className="text-sm text-secondary-600 mt-1">Total stock worth</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200 mb-8">
            <h2 className="text-2xl font-bold text-primary-800 mb-4">Quick Actions</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                variant="primary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/products/create')}
              >
                <Plus className="w-5 h-5" />
                List New Product
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/products')}
              >
                <Eye className="w-5 h-5" />
                View Marketplace
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/dashboard/orders')}
              >
                <Package className="w-5 h-5" />
                My Orders
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="flex items-center justify-center gap-2"
                onClick={() => router.push('/dashboard/profile')}
              >
                <Edit className="w-5 h-5" />
                Edit Profile
              </Button>
            </div>
          </div>

          {/* My Products List */}
          <div className="bg-white rounded-xl p-6 border-2 border-secondary-200">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-primary-800">My Products</h2>
              <Link href="/products/create" className="text-primary-600 font-medium hover:underline">
                + Add New Product
              </Link>
            </div>

            {myProductsError ? (<p className="text-red-700">Could not load your listings: {(myProductsErrorDetail as any)?.response?.data?.error?.message || 'Check backend API and your role.'}</p>) : myProducts && myProducts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {myProducts.map((product: any) => (
                  <div key={product.id} className="border-2 border-secondary-200 rounded-xl p-4 hover:border-primary-300 transition-all">
                    {product.images?.[0] && (
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-full h-40 object-cover rounded-lg mb-3"
                      />
                    )}
                    <h3 className="font-semibold text-lg text-secondary-800 mb-1">{product.name}</h3>
                    <p className="text-sm text-secondary-600 mb-2">{product.category}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold text-primary-600">
                        ₹{(Number(product.pricePerUnit || 0) / 100).toFixed(2)}/{product.unit}
                      </span>
                      <span className={`text-sm px-2 py-1 rounded ${
                        product.availableQuantity > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        Stock: {product.availableQuantity}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Package className="w-16 h-16 text-secondary-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-secondary-800 mb-2">No Products Listed</h3>
                <p className="text-secondary-600 mb-6">Start listing your agricultural products to reach buyers</p>
                <Button variant="primary" onClick={() => router.push('/products/create')}>
                  List Your First Product
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
