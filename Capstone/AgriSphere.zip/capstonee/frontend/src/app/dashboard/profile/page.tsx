'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { authApi } from '@/lib/api'
import { User, Mail, Phone, MapPin, Save, AlertCircle } from 'lucide-react'
import { Button } from '@/components/ui'

export default function ProfilePage() {
  const router = useRouter()
  const queryClient = useQueryClient()
  const [isEditing, setIsEditing] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null)

  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    district: '',
    state: ''
  })

  useEffect(() => {
    const token = localStorage.getItem('accessToken')
    if (!token) {
      router.push('/login')
    }
  }, [router])

  const { data: userData, isLoading } = useQuery({
    queryKey: ['user'],
    queryFn: async () => {
      const response = await authApi.me()
      return response.data.data
    },
  })

  // Set form data when user data is loaded
  useEffect(() => {
    if (userData) {
      setFormData({
        fullName: userData.fullName || '',
        phone: userData.phone || '',
        district: userData.district || '',
        state: userData.state || ''
      })
    }
  }, [userData])

  const updateMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await authApi.updateProfile(data)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user'] })
      setIsEditing(false)
      setMessage({ type: 'success', text: 'Profile updated successfully!' })
      setTimeout(() => setMessage(null), 3000)
    },
    onError: (error: any) => {
      setMessage({ 
        type: 'error', 
        text: error.response?.data?.error?.message || 'Failed to update profile'
      })
      setTimeout(() => setMessage(null), 3000)
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    updateMutation.mutate(formData)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto"></div>
            <p className="mt-4 text-secondary-600">Loading profile...</p>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-secondary-50">
      <Header />

      <main className="flex-grow py-8">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-primary-800 mb-2">My Profile</h1>
            <p className="text-lg text-secondary-600">Manage your account information</p>
          </div>

          {/* Message */}
          {message && (
            <div className={`mb-6 p-4 rounded-lg border-2 ${
              message.type === 'success' 
                ? 'bg-green-50 border-green-300 text-green-800' 
                : 'bg-red-50 border-red-300 text-red-800'
            }`}>
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                <p>{message.text}</p>
              </div>
            </div>
          )}

          {/* Profile Card */}
          <div className="bg-white rounded-xl border-2 border-secondary-200 shadow-sm overflow-hidden">
            <div className="bg-gradient-to-r from-primary-600 to-primary-700 p-6">
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center">
                  <User className="w-10 h-10 text-primary-600" />
                </div>
                <div className="text-white">
                  <h2 className="text-2xl font-bold">{userData?.fullName}</h2>
                  <p className="text-primary-100">{userData?.role}</p>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-6">
              <div className="space-y-6">
                {/* Email (Read-only) */}
                <div>
                  <label className="block text-sm font-semibold text-secondary-700 mb-2">
                    <Mail className="inline w-4 h-4 mr-2" />
                    Email
                  </label>
                  <input
                    type="email"
                    value={userData?.email || ''}
                    disabled
                    className="w-full px-4 py-3 bg-secondary-100 border-2 border-secondary-200 rounded-lg text-secondary-700 cursor-not-allowed"
                  />
                  <p className="text-xs text-secondary-500 mt-1">Email cannot be changed</p>
                </div>

                {/* Full Name */}
                <div>
                  <label htmlFor="fullName" className="block text-sm font-semibold text-secondary-700 mb-2">
                    <User className="inline w-4 h-4 mr-2" />
                    Full Name
                  </label>
                  <input
                    id="fullName"
                    name="fullName"
                    type="text"
                    value={formData.fullName}
                    onChange={handleChange}
                    disabled={!isEditing}
                    required
                    className={`w-full px-4 py-3 border-2 rounded-lg transition-colors ${
                      isEditing
                        ? 'border-secondary-300 focus:border-primary-500 focus:outline-none'
                        : 'bg-secondary-50 border-secondary-200 cursor-not-allowed'
                    }`}
                  />
                </div>

                {/* Phone */}
                <div>
                  <label htmlFor="phone" className="block text-sm font-semibold text-secondary-700 mb-2">
                    <Phone className="inline w-4 h-4 mr-2" />
                    Phone Number
                  </label>
                  <input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleChange}
                    disabled={!isEditing}
                    required
                    className={`w-full px-4 py-3 border-2 rounded-lg transition-colors ${
                      isEditing
                        ? 'border-secondary-300 focus:border-primary-500 focus:outline-none'
                        : 'bg-secondary-50 border-secondary-200 cursor-not-allowed'
                    }`}
                  />
                </div>

                {/* District */}
                <div>
                  <label htmlFor="district" className="block text-sm font-semibold text-secondary-700 mb-2">
                    <MapPin className="inline w-4 h-4 mr-2" />
                    District
                  </label>
                  <input
                    id="district"
                    name="district"
                    type="text"
                    value={formData.district}
                    onChange={handleChange}
                    disabled={!isEditing}
                    className={`w-full px-4 py-3 border-2 rounded-lg transition-colors ${
                      isEditing
                        ? 'border-secondary-300 focus:border-primary-500 focus:outline-none'
                        : 'bg-secondary-50 border-secondary-200 cursor-not-allowed'
                    }`}
                  />
                </div>

                {/* State */}
                <div>
                  <label htmlFor="state" className="block text-sm font-semibold text-secondary-700 mb-2">
                    <MapPin className="inline w-4 h-4 mr-2" />
                    State
                  </label>
                  <input
                    id="state"
                    name="state"
                    type="text"
                    value={formData.state}
                    onChange={handleChange}
                    disabled={!isEditing}
                    className={`w-full px-4 py-3 border-2 rounded-lg transition-colors ${
                      isEditing
                        ? 'border-secondary-300 focus:border-primary-500 focus:outline-none'
                        : 'bg-secondary-50 border-secondary-200 cursor-not-allowed'
                    }`}
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-8 flex gap-4">
                {!isEditing ? (
                  <Button
                    type="button"
                    variant="primary"
                    size="lg"
                    onClick={() => setIsEditing(true)}
                    className="flex-1"
                  >
                    Edit Profile
                  </Button>
                ) : (
                  <>
                    <Button
                      type="submit"
                      variant="primary"
                      size="lg"
                      disabled={updateMutation.isPending}
                      className="flex-1"
                    >
                      <Save className="w-5 h-5 mr-2" />
                      {updateMutation.isPending ? 'Saving...' : 'Save Changes'}
                    </Button>
                    <Button
                      type="button"
                      variant="secondary"
                      size="lg"
                      onClick={() => {
                        setIsEditing(false)
                        setFormData({
                          fullName: userData?.fullName || '',
                          phone: userData?.phone || '',
                          district: userData?.district || '',
                          state: userData?.state || ''
                        })
                      }}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                  </>
                )}
              </div>
            </form>
          </div>

          {/* Additional Info */}
          <div className="mt-6 bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-800 mb-2">Account Information</h3>
            <div className="text-sm text-blue-700 space-y-1">
              <p><strong>Role:</strong> {userData?.role}</p>
              <p><strong>Status:</strong> {userData?.status}</p>
              <p><strong>Member Since:</strong> {new Date(userData?.createdAt).toLocaleDateString()}</p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
