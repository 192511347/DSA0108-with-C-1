'use client'
import { useQuery } from '@tanstack/react-query'
import Link from 'next/link'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { api } from '@/lib/api'
export default function OrderHistory(){
 const {data,isLoading,error}=useQuery({queryKey:['real-orders'],queryFn:async()=>{const r=await api.get('/orders');return r.data.data?.orders||[]}})
 return <div className="min-h-screen flex flex-col bg-secondary-50"><Header/><main className="container-default py-10 flex-grow"><h1 className="text-3xl text-primary-800 font-bold mb-2">Orders & Sales</h1><p className="mb-6 text-secondary-600">Confirmed simulated payments and marketplace orders, stored in PostgreSQL.</p>{isLoading?<p>Loading orders...</p>:error?<p className="text-red-700">{(error as any)?.response?.data?.error?.message||(error as Error).message}</p>:!data?.length?<p>No orders yet. <Link className="underline" href="/products">Browse products</Link></p>:<div className="space-y-5">{data.map((o:any)=><article key={o.id} className="bg-white border shadow-sm rounded-xl p-6"><div className="flex justify-between flex-wrap gap-2"><div><h2 className="font-bold text-lg">Order #{o.orderNumber}</h2><p className="text-sm text-gray-500">{new Date(o.createdAt).toLocaleString()}</p></div><div className="text-right"><p className="font-bold text-primary-800">₹{(Number(o.total)/100).toFixed(2)}</p><p className="text-green-700">{o.status} · {o.paymentStatus} ({o.paymentMethod==='MOCK'?'simulated':o.paymentMethod})</p></div></div><div className="border-t mt-4 pt-4 space-y-1">{(o.items||[]).map((i:any)=><p key={i.id}>{i.productName} · {i.quantity} × ₹{(Number(i.price)/100).toFixed(2)}</p>)}</div><p className="mt-2 text-sm text-gray-600">Delivery: {o.shippingAddress}</p><Link href={`/orders/${o.id}`} className="underline text-primary-700 font-semibold">View crop-to-doorstep journey</Link></article>)}</div>}</main><Footer/></div>
}
