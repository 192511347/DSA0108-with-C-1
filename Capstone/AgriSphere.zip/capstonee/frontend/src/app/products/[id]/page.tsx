'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { productApi, cartApi, api } from '@/lib/api'
import { Button, Card, Badge, Alert } from '@/components/ui'

export default function ProductDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const queryClient = useQueryClient()
  const [quantity, setQuantity] = useState(1)
  const [message, setMessage] = useState('')
  const [messageType, setMessageType] = useState<'success' | 'error'>('success')

  const { data: productData, isLoading } = useQuery({
    queryKey: ['product', params?.id],
    queryFn: async () => {
      const response = await productApi.getById(params?.id as string)
      return response.data.data?.product ?? response.data.data
    },
  })

  useEffect(() => {
    const id = params?.id
    if (typeof id !== 'string') return
    api.post(`/products/${encodeURIComponent(id)}/view`).catch(() => {})
  }, [params?.id])

  const addToCartMutation = useMutation({
    mutationFn: (data: { productId: string; quantity: number }) => cartApi.addItem(data),
    onSuccess: () => {
      setMessage('Added to cart successfully!')
      setMessageType('success')
      queryClient.invalidateQueries({ queryKey: ['cart'] })
      setTimeout(() => setMessage(''), 4000)
    },
    onError: (error: any) => {
      setMessage(error.response?.data?.error?.message || 'Failed to add to cart')
      setMessageType('error')
      setTimeout(() => setMessage(''), 4000)
    },
  })

  const handleAddToCart = () => {
    const token = localStorage.getItem('accessToken')
    if (!token) {
      router.push('/login')
      return
    }
    addToCartMutation.mutate({ productId: productData?.id ?? (params?.id as string), quantity })
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col bg-canvas">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-16 w-16 border-4 border-primary-200 border-t-primary-600 mb-4"></div>
            <p className="text-body-md text-secondary-600">Loading product details...</p>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  if (!productData) {
    return (
      <div className="min-h-screen flex flex-col bg-canvas">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <Card padding="lg" className="text-center max-w-md mx-4">
            <svg className="w-24 h-24 mx-auto text-secondary-300 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
            </svg>
            <h2 className="font-sans text-heading-xl text-secondary-800 mb-3">Product not found</h2>
            <p className="text-body-md text-secondary-600 mb-6">The product you're looking for doesn't exist or has been removed.</p>
            <Link href="/products">
              <Button variant="primary">
                Browse Products
              </Button>
            </Link>
          </Card>
        </main>
        <Footer />
      </div>
    )
  }

  const product = productData

  return (
    <div className="min-h-screen flex flex-col bg-canvas">
      <Header />

      <main className="flex-grow section">
        <div className="container-default">
          {/* Breadcrumb */}
          <nav className="mb-8 flex items-center gap-2 text-body-sm text-secondary-600">
            <Link href="/" className="hover:text-primary-600 transition-colors">Home</Link>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
            <Link href="/products" className="hover:text-primary-600 transition-colors">Products</Link>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
            <span className="text-secondary-800 font-medium">{product.name}</span>
          </nav>

          {/* Message */}
          {message && (
            <div className="mb-6 animate-slide-up">
              <Alert variant={messageType === 'success' ? 'success' : 'error'}>
                {message}
              </Alert>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Product Image */}
            <div>
              <Card padding="lg" className="sticky top-24">
                <div className="aspect-square bg-gradient-to-br from-primary-100 to-accent-100 rounded-2xl flex items-center justify-center overflow-hidden">
                  {product.images?.[0] ? (
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <svg className="w-32 h-32 text-primary-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                  )}
                </div>
              </Card>
            </div>

            {/* Product Details */}
            <div>
              <Card padding="lg" className="mb-6">
                <h1 className="font-display text-display-sm text-primary-800 mb-4">{product.name}</h1>
                
                <div className="flex items-baseline gap-4 mb-8">
                  <span className="font-sans text-display-sm text-primary-600 font-semibold">
                    ₹{(Number(product.pricePerUnit || 0) / 100).toFixed(2)}
                  </span>
                  <span className="text-body-lg text-secondary-600">per {product.unit}</span>
                </div>

                <div className="space-y-4 mb-8">
                  <div className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                    </svg>
                    <div>
                      <span className="text-body-sm text-secondary-600">Category</span>
                      <div className="mt-1">
                        <Badge variant="primary">{product.category}</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-success-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <div>
                      <span className="text-body-sm text-secondary-600">Availability</span>
                      <div className="mt-1">
                        <Badge variant="success">{product.availableQuantity} {product.unit} available</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <div>
                      <span className="text-body-sm text-secondary-600">Seller</span>
                      <p className="text-body-md text-primary-700 font-medium mt-1">{product.sellerName}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <div>
                      <span className="text-body-sm text-secondary-600">Location</span>
                      <p className="text-body-md text-secondary-800 mt-1">{product.sellerDistrict}, {product.sellerState}</p>
                    </div>
                  </div>
                </div>

                <div className="border-t-2 border-secondary-200 pt-6 mb-8">
                  <h3 className="font-sans text-heading-md text-secondary-800 mb-3 flex items-center gap-2">
                    <svg className="w-5 h-5 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
                    </svg>
                    Description
                  </h3>
                  <p className="text-body-md text-secondary-700 leading-relaxed">
                    {product.description || 'Quality agricultural product from a verified seller. Contact the seller for more details about this product.'}
                  </p>
                </div>

                <div className="border-t-2 border-secondary-200 pt-6">
                  <label className="block text-body-sm font-medium text-secondary-700 mb-3">
                    Quantity ({product.unit})
                  </label>
                  <div className="flex flex-col sm:flex-row gap-6 mb-8">
                    <div className="flex-shrink-0">
                      <input
                        type="number"
                        min={product.minOrderQuantity || 1}
                        max={product.availableQuantity}
                        value={quantity}
                        onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                        className="input w-32 text-center font-semibold text-body-lg"
                      />
                    </div>
                    <div className="flex-grow bg-primary-50 rounded-xl p-4 border-2 border-primary-200">
                      <div className="text-body-sm text-secondary-700 mb-1">Total Price</div>
                      <div className="font-sans text-heading-xl text-primary-700 font-semibold">
                        ₹{((product.pricePerUnit * quantity) / 100).toFixed(2)}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button
                      variant="primary"
                      size="lg"
                      onClick={handleAddToCart}
                      isLoading={addToCartMutation.isPending}
                      className="flex-1"
                      leftIcon={
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                      }
                    >
                      {addToCartMutation.isPending ? 'Adding to Cart...' : 'Add to Cart'}
                    </Button>
                    <Link href="/products" className="flex-shrink-0">
                      <Button variant="secondary" size="lg" className="w-full sm:w-auto">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                        </svg>
                        Back to Products
                      </Button>
                    </Link>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
