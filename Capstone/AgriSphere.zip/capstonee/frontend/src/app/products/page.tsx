'use client'

import { useState, Suspense } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { productApi } from '@/lib/api'
import { Button, Card, Badge, Input } from '@/components/ui'

function ProductsContent() {
  const searchParams = useSearchParams()
  const categoryParam = searchParams?.get('category')
  
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState(categoryParam || '')
  const [minPrice, setMinPrice] = useState('')
  const [maxPrice, setMaxPrice] = useState('')
  
  const { data: productsData, isLoading, isError, error } = useQuery({
    queryKey: ['products', search, category, minPrice, maxPrice],
    queryFn: async () => {
      const response = await productApi.list({
        search: search || undefined,
        category: category || undefined,
        minPrice: minPrice ? parseInt(minPrice) * 100 : undefined,
        maxPrice: maxPrice ? parseInt(maxPrice) * 100 : undefined,
        pageSize: 24,
      })
      return response.data.data
    },
  })

  const { data: categoriesData } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const response = await productApi.listCategories()
      return response.data.data
    },
  })

  const clearFilters = () => {
    setSearch('')
    setCategory('')
    setMinPrice('')
    setMaxPrice('')
  }

  return (
    <div className="min-h-screen flex flex-col bg-canvas">
      <Header />
      
      <main className="flex-grow">
        <div className="container-default section">
          {/* Header */}
          <div className="mb-10">
            <h1 className="font-display text-display-md text-primary-800 mb-3">All Products</h1>
            <p className="text-body-lg text-secondary-700">Browse our complete range of agricultural products</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Filters Sidebar */}
            <aside className="lg:col-span-1">
              <Card padding="lg" className="sticky top-24">
                <h3 className="font-sans text-heading-lg text-primary-800 mb-6 flex items-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                  </svg>
                  Filters
                </h3>
                
                {/* Search */}
                <div className="mb-6">
                  <Input
                    label="Search Products"
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search by name..."
                    leftIcon={
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                      </svg>
                    }
                  />
                </div>

                {/* Category */}
                <div className="mb-6">
                  <label className="block text-body-sm font-medium text-secondary-700 mb-2">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="input w-full"
                  >
                    <option value="">All Categories</option>
                    {categoriesData?.categories?.map((cat: any) => (
                      <option key={cat.name} value={cat.name}>{cat.name}</option>
                    ))}
                  </select>
                </div>

                {/* Price Range */}
                <div className="mb-6">
                  <label className="block text-body-sm font-medium text-secondary-700 mb-2">
                    Price Range (₹)
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="number"
                      value={minPrice}
                      onChange={(e) => setMinPrice(e.target.value)}
                      placeholder="Min"
                      className="input"
                    />
                    <input
                      type="number"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(e.target.value)}
                      placeholder="Max"
                      className="input"
                    />
                  </div>
                </div>

                {/* Clear Filters */}
                <Button
                  variant="secondary"
                  onClick={clearFilters}
                  className="w-full"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  Clear Filters
                </Button>

                {/* Active Filters */}
                {(search || category || minPrice || maxPrice) && (
                  <div className="mt-6 pt-6 border-t-2 border-secondary-200">
                    <h4 className="font-sans text-body-sm font-semibold text-secondary-700 mb-3">Active Filters:</h4>
                    <div className="flex flex-wrap gap-2">
                      {search && (
                        <Badge variant="primary">Search: {search}</Badge>
                      )}
                      {category && (
                        <Badge variant="primary">{category}</Badge>
                      )}
                      {minPrice && (
                        <Badge variant="primary">Min: ₹{minPrice}</Badge>
                      )}
                      {maxPrice && (
                        <Badge variant="primary">Max: ₹{maxPrice}</Badge>
                      )}
                    </div>
                  </div>
                )}
              </Card>
            </aside>

            {/* Products Grid */}
            <div className="lg:col-span-3">
              {isLoading ? (
                <div className="text-center py-20">
                  <div className="inline-block animate-spin rounded-full h-16 w-16 border-4 border-primary-200 border-t-primary-600 mb-4"></div>
                  <p className="text-body-md text-secondary-600">Loading products...</p>
                </div>
              ) : isError ? (
                <Card padding="lg" className="text-center">
                  <h3 className="font-semibold text-red-700">Products API unavailable</h3>
                  <p className="mt-3 text-sm">{error instanceof Error ? error.message : 'Check backend connection'}</p>
                  <p className="mt-2 text-sm">Check http://localhost:5000/backend-api/products</p>
                </Card>
              ) : productsData?.products?.length === 0 ? (
                <Card padding="lg" className="text-center">
                  <svg className="w-24 h-24 mx-auto text-secondary-300 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                  </svg>
                  <h3 className="font-sans text-heading-xl text-secondary-800 mb-3">No products found</h3>
                  <p className="text-body-md text-secondary-600 mb-6 max-w-md mx-auto">
                    We couldn't find any products matching your criteria. Try adjusting your filters or search terms.
                  </p>
                  <Button variant="primary" onClick={clearFilters}>
                    Clear All Filters
                  </Button>
                </Card>
              ) : (
                <>
                  <div className="mb-6 flex items-center justify-between">
                    <p className="text-body-md text-secondary-700">
                      Found <span className="font-semibold text-primary-700">{productsData?.products?.length}</span> products
                    </p>
                    <select className="input input-sm">
                      <option>Sort by: Newest</option>
                      <option>Price: Low to High</option>
                      <option>Price: High to Low</option>
                      <option>Name: A to Z</option>
                    </select>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {productsData?.products?.map((product: any) => (
                      <Link
                        key={product.id}
                        href={`/products/${product.id}`}
                      >
                        <Card variant="interactive" padding="none" className="overflow-hidden h-full">
                          <div className="h-52 bg-gradient-to-br from-primary-100 to-accent-100 flex items-center justify-center overflow-hidden relative">
                            {product.images?.[0] ? (
                              <img
                                src={product.images[0]}
                                alt={product.name}
                                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                              />
                            ) : (
                              <svg className="w-20 h-20 text-primary-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                              </svg>
                            )}
                          </div>
                          <div className="p-5">
                            <h3 className="font-sans text-body-md font-semibold text-secondary-800 mb-2 line-clamp-2 min-h-[3rem]">
                              {product.name}
                            </h3>
                            <p className="text-body-sm text-secondary-600 mb-4">{product.category}</p>
                            <div className="flex justify-between items-center">
                              <span className="font-sans text-heading-md text-primary-600 font-semibold">
                                ₹{(product.pricePerUnit / 100).toFixed(2)}
                                <span className="text-body-sm text-secondary-600 font-normal">/{product.unit}</span>
                              </span>
                              <Badge variant="success">In Stock</Badge>
                            </div>
                          </div>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

export default function ProductsPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex flex-col bg-canvas">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-16 w-16 border-4 border-primary-200 border-t-primary-600 mb-4"></div>
            <p className="text-body-md text-secondary-600">Loading products...</p>
          </div>
        </main>
        <Footer />
      </div>
    }>
      <ProductsContent />
    </Suspense>
  )
}
