'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { productApi } from '@/lib/api'
import { Button, Input, Card } from '@/components/ui'
import { Package, Upload, Save, X } from 'lucide-react'

const CATEGORIES = [
  { value: 'GRAINS', label: 'Grains & Cereals' },
  { value: 'VEGETABLES', label: 'Vegetables' },
  { value: 'FRUITS', label: 'Fruits' },
  { value: 'DAIRY', label: 'Dairy Products' },
  { value: 'SPICES', label: 'Spices & Herbs' },
  { value: 'SEEDS', label: 'Seeds' },
  { value: 'FERTILIZERS', label: 'Fertilizers' },
  { value: 'EQUIPMENT', label: 'Equipment' },
  { value: 'OTHER', label: 'Other' }
]

const UNITS = [
  { value: 'KG', label: 'Kilogram (KG)' },
  { value: 'GRAM', label: 'Gram (G)' },
  { value: 'LITRE', label: 'Litre (L)' },
  { value: 'ML', label: 'Millilitre (ML)' },
  { value: 'PIECE', label: 'Piece' },
  { value: 'DOZEN', label: 'Dozen' },
  { value: 'QUINTAL', label: 'Quintal' },
  { value: 'TON', label: 'Ton' },
  { value: 'BAG', label: 'Bag' }
]

export default function CreateProductPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [selectedImage, setSelectedImage] = useState<File | null>(null)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'GRAINS',
    price: '',
    quantity: '',
    unit: 'KG',
    imageUrl: '',
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    // Validation
    if (!formData.name || !formData.description || !formData.price || !formData.quantity) {
      setError('Please fill in all required fields')
      setLoading(false)
      return
    }

    if (parseFloat(formData.price) <= 0) {
      setError('Price must be greater than zero')
      setLoading(false)
      return
    }

    if (parseInt(formData.quantity) < 0) {
      setError('Quantity cannot be negative')
      setLoading(false)
      return
    }

    try {
      let imageUrl = formData.imageUrl
      if (selectedImage) {
        const token = localStorage.getItem('accessToken')
        if (!token) throw new Error('Login required before uploading images')
        const payload = new FormData()
        payload.append('file', selectedImage)
        const upload = await fetch('/api/uploads', { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: payload })
        const result = await upload.json()
        if (!upload.ok) throw new Error(result.error || 'Image upload failed')
        imageUrl = result.url
      }
      const response = await productApi.createProduct({
        name: formData.name,
        description: formData.description,
        category: formData.category,
        price: parseFloat(formData.price),
        quantity: parseInt(formData.quantity),
        unit: formData.unit,
        imageUrl: imageUrl || undefined,
      })

      if (response.data.success) {
        setSuccess(true)
        setTimeout(() => {
          router.push('/dashboard')
        }, 2000)
      }
    } catch (err: any) {
      setError(
        err.response?.data?.error?.message || err.message ||
        'Failed to create product. Please try again.'
      )
    } finally {
      setLoading(false)
    }
  }

  const handleClear = () => {
    setFormData({
      name: '',
      description: '',
      category: 'GRAINS',
      price: '',
      quantity: '',
      unit: 'KG',
      imageUrl: '',
    })
    setError('')
    setSelectedImage(null)
    setSuccess(false)
  }

  if (success) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow bg-secondary-50 py-8 flex items-center justify-center">
          <div className="text-center max-w-md">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Package className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-primary-800 mb-2">Product Created Successfully!</h2>
            <p className="text-secondary-600 mb-6">
              Your product has been listed on the marketplace.
            </p>
            <p className="text-sm text-secondary-500">Redirecting to dashboard...</p>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow bg-secondary-50 py-8">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <Package className="w-8 h-8 text-primary-600" />
              <h1 className="text-4xl font-bold text-primary-800">List New Product</h1>
            </div>
            <p className="text-lg text-secondary-600">
              Add your agricultural product to the marketplace
            </p>
          </div>

          <Card padding="lg" className="shadow-elevated">
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4 flex items-start gap-3">
                  <X className="w-5 h-5 text-red-600 mt-0.5" />
                  <p className="text-red-800">{error}</p>
                </div>
              )}

              {/* Product Name */}
              <Input
                label="Product Name"
                type="text"
                required
                placeholder="e.g., Premium Basmati Rice"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                helperText="Enter a clear, descriptive name for your product"
              />

              {/* Description */}
              <div>
                <label className="block text-body-sm font-medium text-secondary-700 mb-2">
                  Description <span className="text-error-500">*</span>
                </label>
                <textarea
                  required
                  rows={4}
                  className="input w-full resize-none"
                  placeholder="Describe your product, its features, quality, origin, etc."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
                <p className="text-body-xs text-secondary-600 mt-1">
                  Provide detailed information to help buyers make informed decisions
                </p>
              </div>

              {/* Category and Unit Row */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-body-sm font-medium text-secondary-700 mb-2">
                    Category <span className="text-error-500">*</span>
                  </label>
                  <select
                    className="input w-full"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat.value} value={cat.value}>
                        {cat.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-body-sm font-medium text-secondary-700 mb-2">
                    Unit of Measurement <span className="text-error-500">*</span>
                  </label>
                  <select
                    className="input w-full"
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                  >
                    {UNITS.map((unit) => (
                      <option key={unit.value} value={unit.value}>
                        {unit.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Price and Quantity Row */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Input
                  label="Price per Unit (₹)"
                  type="number"
                  required
                  min="0"
                  step="0.01"
                  placeholder="e.g., 85.00"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  helperText="Enter price in Indian Rupees"
                />

                <Input
                  label="Available Quantity"
                  type="number"
                  required
                  min="0"
                  step="1"
                  placeholder="e.g., 500"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  helperText={`In ${formData.unit || 'selected unit'}`}
                />
              </div>

              <div>
                <label className="block text-body-sm font-medium text-secondary-700 mb-2">Upload Product Image (JPEG, PNG or WebP; up to 3 MB)</label>
                <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setSelectedImage(e.target.files?.[0] ?? null)} className="block w-full" />
                {selectedImage && <p className="text-sm mt-2">Selected: {selectedImage.name}</p>}
              </div>
              {/* Image URL */}
              <div>
                <label className="block text-body-sm font-medium text-secondary-700 mb-2">
                  Product Image URL (Optional)
                </label>
                <Input
                  type="url"
                  placeholder="https://example.com/image.jpg"
                  value={formData.imageUrl}
                  onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                  helperText="Provide a URL to your product image. Leave blank for default image."
                  leftIcon={<Upload className="w-5 h-5" />}
                />
                {formData.imageUrl && (
                  <div className="mt-3">
                    <p className="text-sm text-secondary-600 mb-2">Image Preview:</p>
                    <img
                      src={formData.imageUrl}
                      alt="Product preview"
                      className="w-full max-w-xs h-48 object-cover rounded-lg border-2 border-secondary-200"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://via.placeholder.com/400x300?text=Invalid+Image+URL'
                      }}
                    />
                  </div>
                )}
              </div>

              {/* Price Summary */}
              {formData.price && formData.quantity && (
                <div className="bg-primary-50 border-2 border-primary-200 rounded-xl p-4">
                  <h3 className="font-semibold text-primary-800 mb-2">Listing Summary</h3>
                  <div className="space-y-1 text-sm text-secondary-700">
                    <p>Price per {formData.unit || 'unit'}: <span className="font-semibold">₹{formData.price}</span></p>
                    <p>Total quantity: <span className="font-semibold">{formData.quantity} {formData.unit}</span></p>
                    <p>Total value: <span className="font-semibold text-primary-700">
                      ₹{(parseFloat(formData.price || '0') * parseInt(formData.quantity || '0')).toFixed(2)}
                    </span></p>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="submit"
                  variant="primary"
                  size="lg"
                  isLoading={loading}
                  className="flex-1 h-12 flex items-center justify-center gap-2"
                >
                  <Save className="w-5 h-5" />
                  {loading ? 'Creating Product...' : 'List Product'}
                </Button>
                <Button
                  type="button"
                  variant="secondary"
                  size="lg"
                  onClick={handleClear}
                  className="flex items-center justify-center gap-2"
                >
                  <X className="w-5 h-5" />
                  Clear
                </Button>
              </div>

              <p className="text-center text-body-sm text-secondary-600 pt-2">
                By listing this product, you agree to our{' '}
                <a href="/terms" className="text-primary-600 hover:underline">Terms of Service</a>
                {' '}and{' '}
                <a href="/seller-policy" className="text-primary-600 hover:underline">Seller Policy</a>
              </p>
            </form>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
