'use client'

import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { authApi } from '@/lib/api'
import { User } from '@/types'

interface AuthContextType {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const refreshUser = async () => {
    try {
      const token = localStorage.getItem('accessToken')
      if (!token) {
        setUser(null)
        return
      }

      // Try to fetch user data - but if endpoint doesn't exist, use stored data
      try {
        const response = await authApi.me()
        if (response.data.success && response.data.data) {
          setUser(response.data.data.user ?? response.data.data)
        }
      } catch (error: any) {
        // If /auth/me doesn't exist (404), try to use stored user data
        if (error.response?.status === 404) {
          const storedUser = localStorage.getItem('user')
          if (storedUser) {
            setUser(JSON.parse(storedUser))
          }
        } else {
          throw error
        }
      }
    } catch (error) {
      console.error('Failed to fetch user:', error)
      setUser(null)
      localStorage.removeItem('accessToken')
      localStorage.removeItem('refreshToken')
      localStorage.removeItem('user')
    }
  }

  const login = async (email: string, password: string) => {
    const response = await authApi.login({ email, password })
    if (response.data.success && response.data.data) {
      const { user: userData, tokens } = response.data.data
      const accessToken = tokens?.accessToken
      const refreshToken = tokens?.refreshToken
      if (!accessToken || !userData) throw new Error('Invalid login response from backend')
      localStorage.setItem('accessToken', accessToken)
      localStorage.setItem('refreshToken', refreshToken)
      localStorage.setItem('user', JSON.stringify(userData))
      setUser(userData)
    }
  }

  const logout = async () => {
    try {
      const refreshToken = localStorage.getItem('refreshToken')
      if (refreshToken) {
        try {
          await authApi.logout(refreshToken)
        } catch (error) {
          // Ignore error if logout endpoint doesn't exist
          console.log('Logout endpoint not available, clearing local storage only')
        }
      }
    } catch (error) {
      console.error('Logout error:', error)
    } finally {
      localStorage.removeItem('accessToken')
      localStorage.removeItem('refreshToken')
      localStorage.removeItem('user')
      setUser(null)
    }
  }

  useEffect(() => {
    const initAuth = async () => {
      await refreshUser()
      setIsLoading(false)
    }
    initAuth()
  }, [])

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
