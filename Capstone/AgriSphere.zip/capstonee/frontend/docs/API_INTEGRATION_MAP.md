# AgriSphere API Integration Map

**Backend:** C++20 Crow HTTP Server  
**Backend Port:** 6001  
**Backend Base URL:** `http://localhost:6001/api/v1`  
**Last Updated:** 2025-01-18

---

## Backend API Discovery

### Working Endpoints (7/8)

| Feature | Endpoint | Method | Auth | Request | Response | Status |
|---------|----------|--------|------|---------|----------|--------|
| Health Check | `/health` | GET | No | None | `{success, data: {status, service, database, timestamp}}` | ✅ Working |
| Register User | `/auth/register` | POST | No | `{email, password, fullName, phone, role, district?, state?}` | `{success, data: {user, tokens}}` | ✅ Working |
| Login | `/auth/login` | POST | No | `{email, password}` | `{success, data: {user, tokens}}` | ✅ Working |
| Get Products | `/products` | GET | No | Query: `page, pageSize, category` | `{success, data: {products[], pagination}}` | ✅ Working |
| Get Product by ID | `/products/:id` | GET | No | Param: `id` | `{success, data: {product}}` | ✅ Working |
| Get Cart | `/cart` | GET | **Yes** | Header: `Authorization: Bearer <token>` | `{success, data: {cart}}` | ✅ Working |
| Add to Cart | `/cart/items` | POST | **Yes** | `{productId, quantity}` + Auth header | `{success, data: {cart}}` | ✅ Working |
| Create Product | `/products` | POST | **Yes** | `{name, description, category, pricePerUnit, unit, availableQuantity}` | Stub | ⚠️ Stub |

### Authentication

**Type:** JWT Bearer Token  
**Header:** `Authorization: Bearer <accessToken>`  
**Token Location:** Response from `/auth/login` and `/auth/register`  
**Token Structure:**
```json
{
  "accessToken": "eyJ...",
  "refreshToken": "eyJ..."
}
```

**User Object:**
```json
{
  "id": "uuid",
  "email": "string",
  "fullName": "string",
  "phone": "string",
  "role": "FARMER|BUYER|SELLER|SERVICE_PROVIDER|ADMIN",
  "status": "ACTIVE|INACTIVE|SUSPENDED",
  "district": "string?",
  "state": "string?",
  "createdAt": "timestamp",
  "updatedAt": "timestamp"
}
```

### User Roles

| Role | Description |
|------|-------------|
| `FARMER` | Can list produce, manage inventory, access soil/crop recommendations |
| `BUYER` | Can browse, purchase products, manage cart and orders |
| `SELLER` | Can manage product inventory, handle orders |
| `SERVICE_PROVIDER` | Can list equipment/services, manage bookings |
| `ADMIN` | Full platform access, user management, moderation |

### Response Format

**Success:**
```json
{
  "success": true,
  "data": { /* response data */ }
}
```

**Error:**
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human readable message"
  }
}
```

### Product Schema

```typescript
{
  id: string;
  name: string;
  description: string;
  category: "GRAINS" | "VEGETABLES" | "FRUITS" | "DAIRY" | "SPICES" | "OTHER";
  pricePerUnit: number; // in paisa (₹1 = 100 paisa)
  unit: string; // "KG", "QUINTAL", "TON", "BAG", "LITRE", etc.
  availableQuantity: number;
  sellerId: string;
  status: "ACTIVE" | "SOLD_OUT" | "INACTIVE";
  images?: string[];
  createdAt: string;
  updatedAt: string;
}
```

### Cart Schema

```typescript
{
  id: string;
  userId: string;
  items: Array<{
    id: string;
    cartId: string;
    productId: string;
    quantity: number;
    product: {
      name: string;
      pricePerUnit: number;
      unit: string;
      availableQuantity: number;
    };
    subtotal: number;
    createdAt: string;
    updatedAt: string;
  }>;
  totalItems: number;
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
}
```

---

## Missing/Unavailable Endpoints

These features are **NOT YET IMPLEMENTED** in the C++ backend:

### Authentication
- ❌ POST `/auth/logout`
- ❌ POST `/auth/refresh`
- ❌ GET `/auth/me`
- ❌ PUT `/auth/profile`
- ❌ POST `/auth/forgot-password`
- ❌ POST `/auth/reset-password`

### Products
- ❌ GET `/products/categories`
- ❌ PUT `/products/:id`
- ❌ DELETE `/products/:id`
- ❌ GET `/products/my/listings` (farmer's products)

### Cart
- ❌ PUT `/cart/items/:id` (update quantity)
- ❌ DELETE `/cart/items/:id` (remove item)
- ❌ DELETE `/cart` (clear cart)

### Orders
- ❌ POST `/orders` (create order from cart)
- ❌ GET `/orders` (user's orders)
- ❌ GET `/orders/:id`
- ❌ PUT `/orders/:id/status`
- ❌ POST `/orders/:id/cancel`

### Payments
- ❌ POST `/payments/initiate`
- ❌ POST `/payments/verify`
- ❌ GET `/payments/:id`

### Equipment/Services
- ❌ GET `/equipment`
- ❌ GET `/equipment/:id`
- ❌ POST `/equipment`
- ❌ GET `/services`
- ❌ GET `/services/:id`
- ❌ POST `/services`

### Bookings
- ❌ GET `/bookings`
- ❌ POST `/bookings`
- ❌ GET `/bookings/:id`
- ❌ PUT `/bookings/:id/status`
- ❌ DELETE `/bookings/:id`

### Soil Management
- ❌ GET `/soil-profiles`
- ❌ POST `/soil-profiles`
- ❌ GET `/soil-profiles/:id`
- ❌ PUT `/soil-profiles/:id`

### AI Recommendations
- ❌ POST `/recommendations/crops`
- ❌ GET `/recommendations/history`

### Weather
- ❌ GET `/weather`
- ❌ GET `/weather/:location`

### Analytics
- ❌ GET `/analytics/dashboard`
- ❌ GET `/analytics/sales`
- ❌ GET `/analytics/products`
- ❌ GET `/analytics/market`

### Admin
- ❌ GET `/admin/users`
- ❌ PUT `/admin/users/:id/status`
- ❌ GET `/admin/products`
- ❌ PUT `/admin/products/:id/approve`
- ❌ GET `/admin/orders`
- ❌ GET `/admin/reports`

### Reviews
- ❌ GET `/reviews`
- ❌ POST `/reviews`
- ❌ GET `/reviews/:id`
- ❌ PUT `/reviews/:id`
- ❌ DELETE `/reviews/:id`

### Notifications
- ❌ GET `/notifications`
- ❌ PUT `/notifications/:id/read`
- ❌ DELETE `/notifications/:id`

### WebSocket
- ❌ WS `/ws` (real-time notifications)

---

## Frontend Integration Status

### Implemented & Connected
- ✅ Health check endpoint
- ✅ User registration
- ✅ User login
- ✅ Products listing with pagination
- ✅ Single product detail
- ✅ Cart retrieval
- ✅ Add to cart

### Frontend Features Requiring Backend

| Feature | Required Endpoint | Status |
|---------|------------------|--------|
| Logout | POST `/auth/logout` | ❌ Missing - Can do client-side token clear |
| Profile | GET/PUT `/auth/me`, `/auth/profile` | ❌ Missing |
| My Products | GET `/products/my/listings` | ❌ Missing |
| Create Product | POST `/products` | ⚠️ Stub exists |
| Update Cart Item | PUT `/cart/items/:id` | ❌ Missing |
| Remove Cart Item | DELETE `/cart/items/:id` | ❌ Missing |
| Checkout | POST `/orders` | ❌ Missing |
| Order History | GET `/orders` | ❌ Missing |
| Equipment/Services | Full CRUD | ❌ Missing |
| Soil Profiles | Full CRUD | ❌ Missing |
| AI Recommendations | POST `/recommendations/crops` | ❌ Missing |
| Weather | GET `/weather` | ❌ Missing |
| Admin Panel | Multiple endpoints | ❌ Missing |

---

## Database Tables Available

From PostgreSQL schema (8 tables):

1. **users** - 11 records
2. **products** - 84 records ✅
3. **carts** - Auto-created per user
4. **cart_items** - Cart line items
5. **orders** - Order records
6. **order_items** - Order line items
7. **reviews** - Product/service reviews
8. **refresh_tokens** - JWT refresh tokens

---

## Frontend Action Plan

### Phase 1: Core (Working Endpoints)
- ✅ Configure API base URL to `http://localhost:6001/api/v1`
- ✅ Implement auth service (login, register)
- ✅ Implement auth context/store
- ✅ Implement products service
- ✅ Implement cart service
- ✅ Protected routes
- ✅ Token management

### Phase 2: Public Pages
- ✅ Landing page
- ✅ Products marketplace
- ✅ Product detail page
- ✅ Search & filters
- ✅ Cart page

### Phase 3: Authentication
- ✅ Login page
- ✅ Register page
- ⚠️ Profile page (show data, edit blocked)
- ✅ Role-based routing

### Phase 4: Buyer Dashboard
- ✅ Dashboard overview
- ✅ Browse products
- ✅ Cart management
- ⚠️ Orders (mock until backend ready)
- ⚠️ Order tracking (mock)

### Phase 5: Farmer Dashboard
- ⚠️ My products (mock until GET `/products/my/listings`)
- ⚠️ Create product (stub endpoint exists)
- ⚠️ Inventory (mock)
- ⚠️ Soil profiles (mock)
- ⚠️ AI recommendations (mock)

### Phase 6: Seller/Provider Dashboards
- ⚠️ Equipment/Service listings (mock)
- ⚠️ Bookings (mock)

### Phase 7: Admin Dashboard
- ⚠️ User management (mock)
- ⚠️ Product moderation (mock)
- ⚠️ Analytics (mock)

### Phase 8: Advanced Features
- ⚠️ Weather (mock)
- ⚠️ Market analytics (mock)
- ⚠️ Real-time notifications (not available)

---

## Implementation Strategy

### For Missing Endpoints:

1. **Document** the missing API clearly in UI
2. **Show placeholder** data with disclaimer
3. **Use local state** for temporary data
4. **Add "Coming Soon"** badges
5. **Create API request** but handle 404 gracefully
6. **DO NOT** fake success responses
7. **DO NOT** create Next.js API routes as replacement

### Example Missing Feature Handling:

```typescript
// ❌ DON'T: Fake API route
// pages/api/orders.ts - NO!

// ✅ DO: Handle missing endpoint
async function getOrders() {
  try {
    const res = await fetch('/api/v1/orders');
    if (res.status === 404) {
      return { 
        success: false, 
        error: 'Orders API not yet implemented' 
      };
    }
    return res.json();
  } catch (error) {
    return {
      success: false,
      error: 'Backend endpoint unavailable'
    };
  }
}
```

---

## Notes

- Backend runs on port **6001**, not 8080
- All monetary values in **paisa** (divide by 100 for rupees)
- Database has **84 real products** available
- JWT tokens expire (check backend config)
- Some endpoints are stubs returning hardcoded data
- Missing endpoints should show graceful errors, not fake success

---

**Last Backend Commit:** 7d9d000 - Fix database column queries  
**Backend Status:** Fully functional for core marketplace  
**Missing Features:** Advanced features (orders, equipment, AI, admin)
