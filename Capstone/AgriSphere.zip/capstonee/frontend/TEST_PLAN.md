# AgriSphere Frontend - Integration Testing Plan

## Phase 2 Implementation Status: COMPLETED ✅

### Completed Features

1. **Auth Context & State Management** ✅
   - Created `AuthContext` with React Context API
   - Centralized user authentication state
   - Automatic token refresh on 401 errors
   - User data fetching and management

2. **Protected Routes** ✅
   - Created `ProtectedRoute` component
   - Automatic redirect to login for unauthenticated users
   - Role-based access control support
   - Loading states during auth check

3. **Global Auth Integration** ✅
   - Updated `Providers` to include `AuthProvider`
   - Header component now uses auth context
   - Login page integrated with auth context
   - Cart page protected with route wrapper

4. **API Compatibility** ✅
   - Fixed TanStack Query v5 compatibility issues
   - Removed deprecated `onSuccess` callbacks
   - Added cart API alias methods for backward compatibility
   - All TypeScript errors resolved

## Manual Testing Guide

### 1. Authentication Flow

#### Test Case 1.1: User Registration
1. Navigate to http://localhost:5000/register
2. Fill in the registration form:
   - Full Name: Test User
   - Email: test@example.com
   - Password: Test@1234
   - Phone: 9876543210
   - Role: BUYER
   - District: Bangalore
   - State: Karnataka
3. Click "Register"
4. Expected: Redirect to login page with success message

#### Test Case 1.2: User Login
1. Navigate to http://localhost:5000/login
2. Enter credentials:
   - Email: test@example.com
   - Password: Test@1234
3. Click "Sign in"
4. Expected: 
   - Redirect to /dashboard
   - User info visible in header
   - "Logout" button appears

#### Test Case 1.3: Protected Route Access
1. In browser, clear localStorage (F12 > Application > Local Storage > Clear All)
2. Navigate to http://localhost:5000/cart
3. Expected: Automatic redirect to /login?redirect=/cart
4. After login, should redirect back to /cart

#### Test Case 1.4: Logout Flow
1. While logged in, click "Logout" in header
2. Expected:
   - Redirect to /login
   - Header shows "Login" and "Get Started" buttons
   - Attempting to access /cart redirects to login

### 2. Product Browsing

#### Test Case 2.1: View Products List
1. Navigate to http://localhost:5000/products
2. Expected:
   - List of products from backend API
   - Categories filter working
   - Search functionality operational
   - Price range filter functional

#### Test Case 2.2: Product Details
1. Click on any product card
2. Expected:
   - Navigate to /products/[id]
   - Product details loaded from backend
   - Price displayed in ₹ (divided by 100 from paisa)
   - "Add to Cart" button visible (if logged in)

#### Test Case 2.3: Category Filtering
1. On products page, select a category from dropdown
2. Expected:
   - Products filtered by selected category
   - Active filter badge visible
   - Product count updated

### 3. Cart Management

#### Test Case 3.1: Add Product to Cart
1. Login as a buyer
2. Navigate to a product detail page
3. Set quantity
4. Click "Add to Cart"
5. Expected:
   - Success message displayed
   - Cart icon in header shows items (future enhancement)
   - Product added to cart on backend

#### Test Case 3.2: View Cart
1. Navigate to http://localhost:5000/cart
2. Expected:
   - List of cart items loaded from backend
   - Correct prices displayed (paisa ÷ 100)
   - Quantity controls functional
   - Total amount calculated correctly

#### Test Case 3.3: Update Cart Quantity
1. In cart, change quantity of an item
2. Expected:
   - Backend updated via API
   - Subtotal recalculated
   - Total amount updated
   - No page reload required

#### Test Case 3.4: Remove Cart Item
1. Click "Remove" on a cart item
2. Expected:
   - Item removed from cart via API
   - Cart UI updated
   - Total amount recalculated

#### Test Case 3.5: Clear Cart
1. Click "Clear Cart" button
2. Expected:
   - All items removed via API
   - "Your cart is empty" message shown
   - "Browse Products" link displayed

### 4. Error Handling

#### Test Case 4.1: Invalid Login
1. Enter wrong email/password on login page
2. Expected: Error message displayed from backend

#### Test Case 4.2: Network Error
1. Stop backend server
2. Try to load products page
3. Expected: Appropriate error message (no crash)

#### Test Case 4.3: Token Expiration
1. In localStorage, modify accessToken to invalid value
2. Try to access cart
3. Expected: Automatic attempt to refresh token, then redirect to login

### 5. User Experience

#### Test Case 5.1: Loading States
1. On slow connection, observe loading indicators
2. Expected:
   - Spinner shown while data loads
   - "Loading..." messages appropriate
   - No flash of empty content

#### Test Case 5.2: Mobile Responsiveness
1. Resize browser window to mobile size (375px)
2. Expected:
   - Mobile menu icon visible
   - All content readable
   - Forms still functional

## Backend Integration Status

### Working Endpoints (7/8)
- ✅ `GET /api/v1/health` - Health check
- ✅ `POST /api/v1/auth/register` - User registration
- ✅ `POST /api/v1/auth/login` - User login
- ✅ `GET /api/v1/products` - List products (with filters)
- ✅ `GET /api/v1/products/:id` - Product details
- ✅ `GET /api/v1/cart` - Get cart
- ✅ `POST /api/v1/cart/items` - Add to cart

### Missing Endpoints (Need Backend Implementation)
- ❌ `GET /api/v1/auth/me` - Get current user (used by AuthContext)
- ❌ `PUT /api/v1/cart/items/:id` - Update cart item quantity
- ❌ `DELETE /api/v1/cart/items/:id` - Remove cart item
- ❌ `DELETE /api/v1/cart` - Clear cart
- ❌ `POST /api/v1/auth/logout` - Logout
- ❌ `POST /api/v1/auth/refresh` - Refresh access token
- ❌ `PUT /api/v1/auth/profile` - Update user profile

## Known Issues & Workarounds

### Issue 1: Missing `/auth/me` Endpoint
**Impact**: AuthContext cannot fetch user data after page refresh
**Workaround**: Frontend stores user data temporarily, but refresh loses auth state
**Solution**: Backend needs to implement this endpoint

### Issue 2: Missing Cart Update/Remove Endpoints
**Impact**: Cart quantity changes and item removal don't persist to backend
**Workaround**: Frontend shows UI updates, but they're lost on refresh
**Solution**: Backend needs to implement PUT and DELETE cart item endpoints

### Issue 3: Token Refresh Not Implemented
**Impact**: Users get logged out after access token expires
**Workaround**: None - user must login again
**Solution**: Backend needs to implement `/auth/refresh` endpoint

## Next Steps

### Phase 3: Dashboard Pages (Priority: HIGH)
- [ ] Implement farmer dashboard
- [ ] Implement buyer dashboard  
- [ ] Implement seller dashboard
- [ ] Create "My Orders" page (when backend ready)
- [ ] Create "My Products" page for sellers

### Phase 4: Form Enhancements (Priority: MEDIUM)
- [ ] Add product creation form (sellers)
- [ ] Add service request form
- [ ] Add profile edit form
- [ ] Implement image upload for products

### Phase 5: Polish & UX (Priority: MEDIUM)
- [ ] Add cart item count badge in header
- [ ] Add toast notifications for actions
- [ ] Implement optimistic UI updates
- [ ] Add skeleton loaders
- [ ] Add animations and transitions

### Phase 6: Backend Coordination (Priority: HIGH)
- [ ] Request backend team to implement missing endpoints
- [ ] Test with real backend once endpoints are ready
- [ ] Update API error handling based on actual responses
- [ ] Add retry logic for failed requests

## Test Results Log

### Test Run: [Date/Time]
**Tester**: [Name]
**Backend Status**: Running on port 6001
**Frontend Status**: Running on port 5000

| Test Case | Status | Notes |
|-----------|--------|-------|
| 1.1 Registration | ⏸️ Pending | Need to test with backend |
| 1.2 Login | ⏸️ Pending | Need to test with backend |
| 1.3 Protected Route | ⏸️ Pending | Need to test |
| 1.4 Logout | ⏸️ Pending | Need backend endpoint |
| 2.1 Products List | ⏸️ Pending | Need to test |
| 2.2 Product Details | ⏸️ Pending | Need to test |
| 2.3 Category Filter | ⏸️ Pending | Need to test |
| 3.1 Add to Cart | ⏸️ Pending | Need to test |
| 3.2 View Cart | ⏸️ Pending | Need to test |
| 3.3 Update Quantity | ❌ Blocked | Backend endpoint missing |
| 3.4 Remove Item | ❌ Blocked | Backend endpoint missing |
| 3.5 Clear Cart | ❌ Blocked | Backend endpoint missing |
| 4.1 Invalid Login | ⏸️ Pending | Need to test |
| 4.2 Network Error | ⏸️ Pending | Need to test |
| 4.3 Token Expiration | ❌ Blocked | Backend endpoint missing |

---

**Last Updated**: Phase 2 Complete
**Next Milestone**: Manual testing and dashboard implementation
