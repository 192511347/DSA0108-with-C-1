import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // wisprflow.ai-inspired agricultural palette
        // Canvas: Cream for warmth and organic feel
        canvas: '#FFFFEB',  // Cream canvas - using simple value for bg-canvas class
        // Primary: Forest Green for agriculture and growth
        primary: {
          50: '#E6F2F0',
          100: '#CCE5E1',
          200: '#99CBC3',
          300: '#66B1A5',
          400: '#339787',
          500: '#034F46',  // Forest Green - main brand color
          600: '#02453D',
          700: '#023B34',
          800: '#01302B',
          900: '#012622',
        },
        // Secondary: Soil tones for grounding
        secondary: {
          50: '#F5F3F2',
          100: '#EBE7E5',
          200: '#D7CFCB',
          300: '#C3B7B1',
          400: '#AF9F97',
          500: '#8B7570',  // Warm soil brown
          600: '#6F5E5A',
          700: '#534745',
          800: '#372F2E',
          900: '#2B2520',
        },
        // Accent: Lavender for CTAs and highlights
        accent: {
          50: '#FCF7FF',
          100: '#F9EFFF',
          200: '#F0D7FF',  // Lavender CTA
          300: '#E7BFFF',
          400: '#DEA7FF',
          500: '#D58FFF',
          600: '#CC77FF',
          700: '#B347FF',
          800: '#9A17FF',
          900: '#7A00CC',
        },
        // Success: Vibrant green for growth/success states
        success: {
          50: '#EDFBF3',
          100: '#D4F5E1',
          200: '#AAECC3',
          300: '#7FE2A5',
          400: '#55D987',
          500: '#2ACF69',
          600: '#22A654',
          700: '#1A7D3F',
          800: '#11532A',
          900: '#092A15',
        },
        // Warning: Turmeric yellow for caution
        warning: {
          50: '#FEF9E7',
          100: '#FDF1C2',
          200: '#FBE288',
          300: '#F9CE44',
          400: '#E3A008',
          500: '#D18E07',
          600: '#B57004',
          700: '#915107',
          800: '#78400C',
          900: '#66350D',
        },
        // Error: Terra cotta for errors
        error: {
          50: '#FEF2F2',
          100: '#FEE2E2',
          200: '#FECACA',
          300: '#FCA5A5',
          400: '#F87171',
          500: '#DC2626',
          600: '#B91C1C',
          700: '#991B1B',
          800: '#7F1D1D',
          900: '#651C1C',
        },
      },
      fontFamily: {
        // Display: Fraunces for warm, agricultural aesthetic
        display: ['Fraunces Variable', 'Georgia', 'serif'],
        // UI: Plus Jakarta Sans for clean, modern interface
        sans: ['Plus Jakarta Sans Variable', 'system-ui', '-apple-system', 'sans-serif'],
        // Regional: Noto fonts for Tamil and Hindi
        tamil: ['Noto Sans Tamil', 'sans-serif'],
        devanagari: ['Noto Sans Devanagari', 'sans-serif'],
        // Fallback
        mono: ['ui-monospace', 'Consolas', 'monospace'],
      },
      fontSize: {
        // Display sizes (EB Garamond)
        'display-xl': ['4.5rem', { lineHeight: '1.1', letterSpacing: '-0.02em', fontWeight: '600' }],
        'display-lg': ['3.75rem', { lineHeight: '1.1', letterSpacing: '-0.02em', fontWeight: '600' }],
        'display-md': ['3rem', { lineHeight: '1.2', letterSpacing: '-0.01em', fontWeight: '600' }],
        'display-sm': ['2.25rem', { lineHeight: '1.3', letterSpacing: '-0.01em', fontWeight: '600' }],
        // Heading sizes (Figtree)
        'heading-xl': ['2rem', { lineHeight: '1.3', fontWeight: '600' }],
        'heading-lg': ['1.5rem', { lineHeight: '1.4', fontWeight: '600' }],
        'heading-md': ['1.25rem', { lineHeight: '1.4', fontWeight: '600' }],
        'heading-sm': ['1.125rem', { lineHeight: '1.5', fontWeight: '600' }],
        // Body sizes (Figtree)
        'body-lg': ['1.125rem', { lineHeight: '1.7', fontWeight: '400' }],
        'body-md': ['1rem', { lineHeight: '1.6', fontWeight: '400' }],
        'body-sm': ['0.875rem', { lineHeight: '1.6', fontWeight: '400' }],
        'body-xs': ['0.75rem', { lineHeight: '1.5', fontWeight: '400' }],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '112': '28rem',
        '128': '32rem',
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.25rem',
        '3xl': '1.5rem',
        '4xl': '2rem',
      },
      boxShadow: {
        'soft': '0 2px 8px rgba(3, 79, 70, 0.08)',
        'soft-lg': '0 4px 16px rgba(3, 79, 70, 0.12)',
        'elevated': '0 8px 24px rgba(3, 79, 70, 0.16)',
        'elevated-lg': '0 16px 48px rgba(3, 79, 70, 0.2)',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'scale-in': 'scaleIn 0.2s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        scaleIn: {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}

export default config
