# AgriSphere Frontend

Next.js 14 frontend for the AgriSphere digital agriculture ecosystem.

## Features

- ✅ Next.js 14 with App Router
- ✅ TypeScript for type safety
- ✅ Tailwind CSS with custom agricultural theme
- ✅ TanStack Query for data fetching
- ✅ Axios API client with auto-refresh
- ✅ Authentication flow (login/register)
- ✅ Responsive design
- ✅ Agricultural color palette (Paddy Green + Soil Brown + Turmeric Yellow)

## Getting Started

### Prerequisites
- Node.js 18+ and npm

### Installation

```bash
npm install
```

### Configuration

Copy `.env.example` to `.env.local`:

```bash
cp .env.example .env.local
```

Update the API URL if needed:
```
NEXT_PUBLIC_API_URL=http://localhost:8080/api/v1
```

### Development

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Build for Production

```bash
npm run build
npm start
```

## Project Structure

```
frontend/
├── src/
│   ├── app/              # Next.js 14 App Router pages
│   │   ├── layout.tsx    # Root layout
│   │   ├── page.tsx      # Homepage
│   │   ├── login/        # Login page
│   │   ├── register/     # Registration page
│   │   └── globals.css   # Global styles
│   ├── lib/
│   │   └── api.ts        # API client
│   └── components/       # Reusable components (to be added)
├── tailwind.config.ts    # Tailwind configuration
├── tsconfig.json         # TypeScript configuration
└── package.json
```

## Design System

The design follows the agricultural theme defined in `DESIGN.md`:

### Colors
- **Primary (Paddy Green):** #1F5A3A - Headers, buttons, links
- **Secondary (Soil Brown):** #2B2520 - Text, borders
- **Accent (Turmeric Yellow):** #E3A008 - Highlights, CTAs

### Typography
- **Font:** Inter Variable with support for Devanagari and Tamil
- **Scale:** 4XL (36px) for hero, down to SM (14px) for body

### Components
- Buttons: `.btn-primary`, `.btn-secondary`, `.btn-accent`
- Inputs: `.input` with focus rings
- Cards: `.card` with hover effects

## API Integration

The frontend connects to the C++20/Drogon backend:

- **Auth:** Login, Register, Profile
- **Products:** List, Search, Create
- **Categories:** Browse

API client includes:
- Automatic token refresh
- Request/response interceptors
- Error handling
- Type-safe responses

## Pages Implemented

1. **Homepage** (`/`)
   - Hero section
   - Category grid
   - Featured products
   - Responsive header/footer

2. **Login** (`/login`)
   - Email/mobile authentication
   - Remember me option
   - Password reset link
   - Error handling

3. **Register** (`/register`)
   - Multi-role registration (FARMER, BUYER, SELLER, SERVICE_PROVIDER)
   - Field validation
   - Password strength check
   - Approval notice for sellers/providers

## Next Steps

To complete the frontend:

1. **Dashboard Pages** - Role-specific dashboards
2. **Product Pages** - Browse, search, product details
3. **Cart & Checkout** - Shopping cart, order placement
4. **Services** - Service listing, booking interface
5. **Profile** - User profile management
6. **Admin** - Admin dashboard (user approval, analytics)

## Development Notes

- All API calls use the `api` client from `@/lib/api.ts`
- Authentication state managed via localStorage
- Tokens automatically refreshed on 401 responses
- All forms have client-side validation
- Error messages displayed to users

## Testing

To be implemented:
- Component tests (Vitest + React Testing Library)
- E2E tests (Playwright)
- Accessibility tests (axe)

## Deployment

Build the production bundle:
```bash
npm run build
```

The static export will be in the `.next` folder.

Deploy to:
- Vercel (recommended for Next.js)
- Docker container
- Static hosting (Netlify, CloudFlare Pages)

---

**Status:** Frontend foundation complete, ready for feature development.
