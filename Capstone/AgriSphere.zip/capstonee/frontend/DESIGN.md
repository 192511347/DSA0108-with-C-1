# AGRISPHERE DESIGN SYSTEM

**Version:** 1.0  
**Last Updated:** 2026-11-10  
**Status:** Foundation specification (pre-implementation)

---

## DESIGN PHILOSOPHY

AgriSphere's interface should feel like it belongs in the agricultural ecosystem—not like a generic SaaS dashboard or e-commerce template. The design draws from the physical world of Indian agriculture: farm gates, mandi price boards, seed packets, crop calendars, monsoon timing, soil reports, and the rupee economy.

**Core Principles:**

1. **Grounded in Agriculture:** Visual language references real agricultural artifacts—not abstract tech metaphors. Price displays echo handwritten mandi boards. Product cards feel like seed packets. The calendar shows actual crop seasons.

2. **Accessible Across Digital Literacy:** From first-time smartphone users in villages to urban buyers on desktops. Clear hierarchy, large touch targets, obvious affordances, forgiving interactions.

3. **Information Density with Breathing Room:** Agricultural decisions need data (price/kg, location, stock, season), but the interface must never feel cramped. Strategic use of white space around critical actions.

4. **Honest and Direct:** No marketing fluff, no "revolutionary" or "game-changing" copy. Buttons say what they do. Errors explain the fix. Empty states guide the next step. Agricultural advice includes appropriate disclaimers.

5. **Regionally Appropriate:** INR with Indian digit grouping (₹1,25,000 not ₹125,000), units that farmers use (quintal, acre), support for Devanagari and Tamil from day one, with expansion-safe layouts.

---

## COLOR PALETTE

### Foundation Colors

**Primary: Paddy Green Family**
- `paddy-900`: `#0F3D29` — Deep shade for text on light backgrounds, footer
- `paddy-700`: `#1F5A3A` — Primary brand color, main CTAs, active states
- `paddy-500`: `#2E7D4E` — Hover states, borders
- `paddy-300`: `#5BA876` — Lighter accents, success messages background
- `paddy-100`: `#E8F5EE` — Subtle fills, disabled button backgrounds

**Secondary: Earth Neutrals**
- `soil-900`: `#2B2520` — Body text, headings
- `soil-700`: `#4A3F37` — Secondary text
- `soil-500`: `#6B5E54` — Muted text, placeholders
- `soil-300`: `#9D9288` — Borders, dividers
- `soil-100`: `#E5E0DB` — Light borders, disabled text
- `soil-50`: `#FAFAF5` — Page background (warm white, not pure white)

**Accent: Turmeric (used sparingly)**
- `turmeric-700`: `#C48B00` — Dark shade for text on light
- `turmeric-500`: `#E3A008` — Primary accent, price emphasis, key CTAs
- `turmeric-300`: `#F5C84C` — Hover states
- `turmeric-100`: `#FFF4D1` — Light fills, highlights

**Semantic Colors**

- **Success:** `leaf-600`: `#2D7A4A`, `leaf-100`: `#D4F4DD`
- **Warning:** `mustard-600`: `#B7791F`, `mustard-100`: `#FFF3CD`
- **Danger:** `clay-600`: `#C1440E`, `clay-100`: `#FFE0D4`
- **Info:** `sky-600`: `#0369A1`, `sky-100`: `#E0F2FE`

**Focus Ring:** `paddy-500` with 40% opacity, 3px offset

### Dark Mode Values

Dark mode uses inverted neutrals with adjusted greens:

- Background: `soil-900` (`#2B2520`)
- Surface: `soil-800` (`#3A332B`)
- Text: `soil-50` (`#FAFAF5`)
- Primary: `paddy-400` (`#4CC981`) — brighter for contrast
- Accent: `turmeric-400` (`#F0B429`) — slightly lighter

### Rationale

This palette **avoids generic defaults:**
- Not the standard blue+gray SaaS palette
- Not cream+terracotta editorial
- Not pure black/white
- Not a single green at multiple opacities

Instead, it uses a **purposeful agricultural color story**: paddy field green (India's most important crop), soil brown for text (not pure black), turmeric yellow (spice, auspiciousness, price emphasis), and a warm off-white surface (not clinical white).

---

## TYPOGRAPHY

### Font Families

**Headings: Inter Variable**
- Modern, excellent Devanagari support via Inter's extended character set
- Clean geometry appropriate for agricultural commerce (not too playful, not too corporate)
- Variable font for efficient loading and flexible weights

**Body: Inter Variable**
- Same family for cohesion and simplicity
- Proven readability at small sizes on mobile
- Excellent support for Devanagari, Latin Extended

**Monospace (prices, numbers, codes): JetBrains Mono**
- Tabular figures for price alignment
- High readability for numeric data
- Used sparingly: price displays, order IDs, PINcodes

### Fallback Stack

```css
font-family: 'Inter Variable', 'Noto Sans Devanagari', 'Noto Sans Tamil', 
             system-ui, -apple-system, sans-serif;
```

**Rationale:** If Inter fails, Noto Sans provides comprehensive Indic script coverage. System fonts as final fallback.

### Type Scale (base 16px)

- `text-xs`: 12px / 1rem × 0.75 — Helper text, labels
- `text-sm`: 14px / 1rem × 0.875 — Body small, table cells
- `text-base`: 16px / 1rem — Primary body text
- `text-lg`: 18px / 1rem × 1.125 — Emphasized body, large labels
- `text-xl`: 20px / 1rem × 1.25 — Small headings, card titles
- `text-2xl`: 24px / 1rem × 1.5 — Section headings
- `text-3xl`: 30px / 1rem × 1.875 — Page headings
- `text-4xl`: 36px / 1rem × 2.25 — Hero headings
- `text-5xl`: 48px / 1rem × 3 — Marketing hero (landing page only)

### Weights

- `font-normal`: 400 — Body text
- `font-medium`: 500 — Emphasized text, labels
- `font-semibold`: 600 — Headings, buttons
- `font-bold`: 700 — Hero headings, strong emphasis

### Line Heights

- **Headings:** 1.2 (tight)
- **Body:** 1.6 (comfortable for reading)
- **UI elements (buttons, inputs):** 1.5

### Line Length

- Maximum 70 characters for long-form content
- Product descriptions and articles constrained to `max-w-prose` (65ch)

### Rationale

This typography **avoids generic defaults:**
- Not using a serif for headings (no editorial magazine vibe)
- Not using Poppins or Montserrat (overused in Indian web projects)
- Not mixing three different font families
- Not using tracked-out uppercase for labels

Instead: **one workhorse family** (Inter) with excellent Indic support, strategic weight variation, and monospace reserved for numeric data where it adds clarity.

---

## LAYOUT SYSTEM

### Grid and Spacing

**Base Unit:** 4px  
**Spacing Scale:** 0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96

```
spacing-1  = 4px    spacing-8  = 32px
spacing-2  = 8px    spacing-10 = 40px
spacing-3  = 12px   spacing-12 = 48px
spacing-4  = 16px   spacing-16 = 64px
spacing-5  = 20px   spacing-20 = 80px
spacing-6  = 24px   spacing-24 = 96px
```

### Container Widths

- `max-w-sm`: 640px — Forms, narrow content
- `max-w-md`: 768px — Product detail content
- `max-w-lg`: 1024px — Standard page width
- `max-w-xl`: 1280px — Wide layouts (dashboards, tables)
- `max-w-2xl`: 1536px — Maximum content width

### Breakpoints

- `sm`: 640px — Large phone
- `md`: 768px — Tablet
- `lg`: 1024px — Desktop
- `xl`: 1280px — Large desktop

### Layout Principles

- **Left-aligned by default** (no centered paragraphs)
- **Mobile-first** (stack vertically, expand horizontally at breakpoints)
- **Touch-first** (44×44px minimum tap targets)
- **Predictable navigation** (logo top-left, actions top-right, primary nav consistent)

---

## LAYOUT CONCEPTS (ASCII WIREFRAMES)

### Landing Page

```
┌─────────────────────────────────────────────────────────────┐
│  [Logo] AgriSphere              [Login] [Register] [Lang ▾] │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  🌾 What's in Season Now in Maharashtra                │  │
│  │                                                         │  │
│  │  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐             │  │
│  │  │Rice │ │Wheat│ │Ctn  │ │Soy  │ │Toor │  [...more]  │  │
│  │  │₹42/k│ │₹38/k│ │₹68/k│ │₹89/k│ │₹125 │             │  │
│  │  └─────┘ └─────┘ └─────┘ └─────┘ └─────┘             │  │
│  │                                                         │  │
│  │  [View All Seasonal Products →]                        │  │
│  └───────────────────────────────────────────────────────┘  │
│                 ↑ SIGNATURE ELEMENT: Seasonal Crop Hero      │
│                                                               │
│  Browse by Category                                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │  Seeds   │ │Fertilizer│ │ Equipment│ │  Fresh   │       │
│  │    🌱    │ │    🧪    │ │    🚜    │ │ Produce  │       │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘       │
│                                                               │
│  How AgriSphere Works  |  For Farmers  |  For Buyers        │
│  [Quiet, informational sections with clear next steps]      │
└─────────────────────────────────────────────────────────────┘
```

### Product Listing (Marketplace)

```
Desktop:
┌─────────────────────────────────────────────────────────────┐
│ [Header Navigation]                                          │
├──────────────┬──────────────────────────────────────────────┤
│              │  🔍 Search: "tomato seeds"    [Sort ▾]       │
│  Filters     │                                               │
│  ─────────   │  Showing 47 results                          │
│  Category    │                                               │
│  □ Seeds     │  ┌────────────────────────────────────────┐  │
│  ☑ Fert.     │  │ ┌──┐  Tomato Hybrid Seed - F1           │  │
│  □ Equip.    │  │ │📷│  ₹450 / 100g                        │  │
│              │  │ └──┘  Verified Seller | ⭐ 4.6 (89)     │  │
│  Price       │  │       Stock: 245 packets | Nashik       │  │
│  ₹[═══●═══]₹ │  └────────────────────────────────────────┘  │
│              │                                               │
│  Location    │  [More product cards...]                     │
│  ◉ All India │                                               │
│  ○ My State  │                                               │
│  ○ District  │  [Load More] or [Infinite Scroll]           │
│              │                                               │
│  [Reset]     │                                               │
└──────────────┴──────────────────────────────────────────────┘

Mobile: Filters in bottom drawer, cards stack vertically
```

### Product Detail

```
Desktop:
┌─────────────────────────────────────────────────────────────┐
│ [Header]                                                     │
├────────────────────────────────────┬────────────────────────┤
│                                    │  STICKY BUY BOX        │
│  ┌────────────────────────────┐   │                        │
│  │                            │   │  ₹450 / 100g packet    │
│  │    Product Image           │   │                        │
│  │    (Gallery with zoom)     │   │  Quantity: [─] 1 [+]   │
│  │                            │   │                        │
│  └────────────────────────────┘   │  In Stock: 245 units   │
│                                    │                        │
│  Tomato Hybrid Seed - F1           │  [Add to Cart]        │
│  ⭐ 4.6 (89 reviews)               │  [Add to Wishlist]    │
│                                    │                        │
│  Description:                      │  Delivery: Enter PIN  │
│  High-yield hybrid variety         │  [______] [Check]     │
│  suitable for Kharif season...     │                        │
│                                    │  ┌──────────────────┐ │
│  ┌───────────────────────────┐    │  │ Seller: ABC Seeds│ │
│  │ 🤖 AI: Is this right for  │    │  │ ⭐ 4.8 | Verified │ │
│  │ me? (AI-generated advice) │    │  │ [View Profile]   │ │
│  └───────────────────────────┘    │  └──────────────────┘ │
│                                    │                        │
│  Reviews | Specifications | Q&A    └────────────────────────┘
│                                                              │
│  Related Products [Cards...]                                │
└─────────────────────────────────────────────────────────────┘

Mobile: Sticky buy box at bottom, scrollable content
```

### Cart & Checkout

```
┌─────────────────────────────────────────────────────────────┐
│ [Header]                                                     │
├─────────────────────────────────────────────────────────────┤
│  Your Cart (3 items)                                         │
│                                                               │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ [📷] Tomato Seeds   ₹450 × 2  [─] 2 [+]  = ₹900  [×] │  │
│  │      ABC Seeds | In stock                              │  │
│  ├───────────────────────────────────────────────────────┤  │
│  │ [📷] Vermicompost  ₹1,200 × 1  [─] 1 [+] = ₹1,200 [×]│  │
│  │      XYZ Organic | In stock                            │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Subtotal:              ₹2,100                       │    │
│  │  GST (5%):              ₹105                         │    │
│  │  Delivery:              ₹80                          │    │
│  │  ─────────────────────────────────                  │    │
│  │  Total:                 ₹2,285                       │    │
│  │                                                       │    │
│  │  [Proceed to Checkout]                               │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
│  Checkout Steps: [1 Cart] → [2 Address] → [3 Payment]       │
└─────────────────────────────────────────────────────────────┘
```

### Dashboard (Farmer Example)

```
┌─────────────────────────────────────────────────────────────┐
│ [Header]                          Hello, Ramesh Kumar 🌾    │
├──────────────┬──────────────────────────────────────────────┤
│              │  Dashboard Overview                           │
│  Navigation  │                                               │
│  ─────────   │  ┌────────┐ ┌────────┐ ┌────────┐ ┌──────┐ │
│  • Dashboard │  │Products│ │ Orders │ │Revenue │ │Stock │ │
│  • Products  │  │   12   │ │   47   │ │₹45,280 │ │ Low  │ │
│  • Orders    │  └────────┘ └────────┘ └────────┘ └──────┘ │
│  • Inventory │                                               │
│  • Earnings  │  Recent Orders                               │
│  • Profile   │  ┌────────────────────────────────────────┐ │
│  • Settings  │  │ Order #12847 | ₹1,200 | PENDING        │ │
│  • Logout    │  │ Buyer: Amit Shah | 2 items             │ │
│              │  │ [View Details] [Confirm Order]         │ │
│              │  ├────────────────────────────────────────┤ │
│              │  │ [More orders...]                       │ │
│              │  └────────────────────────────────────────┘ │
│              │                                               │
│              │  Sales Trend (Last 30 Days) [Line Chart]    │
│              │                                               │
│              │  Low Stock Alert: 3 products need restocking │
└──────────────┴──────────────────────────────────────────────┘
```

---

## BORDER RADIUS SCALE

- `rounded-none`: 0px — Deliberate sharp corners (tables, data-heavy)
- `rounded-sm`: 4px — Buttons, inputs, tags
- `rounded-md`: 6px — Cards, panels
- `rounded-lg`: 8px — Modals, drawers
- `rounded-xl`: 12px — Large cards, hero sections
- `rounded-full`: 9999px — Avatars, pills, badges

**Rationale:** Intentional variation. Not "rounded-lg on everything." Cards get `rounded-md`, modals get `rounded-lg`, buttons get `rounded-sm` for a subtle distinction.

---

## ELEVATION (SHADOW SCALE)

- `shadow-sm`: `0 1px 2px rgba(43, 37, 32, 0.05)` — Subtle lift (inputs, tags)
- `shadow-md`: `0 4px 6px rgba(43, 37, 32, 0.08)` — Cards, dropdowns
- `shadow-lg`: `0 10px 15px rgba(43, 37, 32, 0.10)` — Modals, popovers
- `shadow-xl`: `0 20px 25px rgba(43, 37, 32, 0.12)` — Large modals, drawers

**Avoid:** Same shadow on every card. Use `shadow-sm` for most cards, `shadow-md` for interactive elements (hover state), `shadow-lg` for overlays.

---

## SIGNATURE ELEMENT (MEMORABLE MOMENT)

**Choice: Seasonal Crop Calendar Hero**

### Concept
The landing page opens with a **live, location-aware seasonal crop strip** that shows what's in season *right now* in the visitor's state (detected from IP or explicitly selected). Each crop tile shows:
- Crop name
- Average marketplace price (computed from real listing data)
- Visual indicator (emoji or icon)
- Click-through to filtered marketplace

### Why This Choice

1. **Grounded in Agriculture:** Indian farmers plan by season and monsoon cycles. This speaks directly to their mental model.
2. **Useful, Not Decorative:** Immediately actionable—buyers see what's fresh, sellers see demand signals.
3. **Data-Driven:** Built from real database queries, not marketing copy.
4. **Regionally Relevant:** Adapts to Maharashtra, Tamil Nadu, Punjab, etc.
5. **Avoids Generic E-commerce:** No hero image with a tagline, no gradient wash, no stock photo of a smiling farmer.

### Implementation Notes
- Horizontal scrollable strip on mobile
- Grid of 5-6 crops on desktop
- Falls back to "Popular Right Now" if location unavailable
- Updated daily from product and order data
- Separate from AI advisory (this is rule-based, deterministic)

### What Was Rejected
- **Live mandi price strip:** Too data-heavy for a hero, better as a secondary dashboard widget
- **Farm-to-door provenance:** Great for product detail, not for landing page
- **Gradient washes, animated illustrations, hero images:** Generic, not agricultural

---

## COMPONENT GUIDELINES

### Buttons

**Primary (CTA):** `bg-paddy-700 text-white hover:bg-paddy-500 rounded-sm px-4 py-2.5`  
**Secondary:** `bg-soil-100 text-soil-900 hover:bg-soil-200 rounded-sm px-4 py-2.5`  
**Accent (price-related):** `bg-turmeric-500 text-soil-900 hover:bg-turmeric-300 rounded-sm px-4 py-2.5`  
**Ghost:** `text-paddy-700 hover:bg-paddy-100 rounded-sm px-4 py-2.5`

**Touch Target:** Minimum 44×44px (enforced with `min-h-[44px]`)

### Form Inputs

- Border: `border border-soil-300 focus:border-paddy-500`
- Focus ring: `ring-2 ring-paddy-500 ring-opacity-40`
- Padding: `px-3 py-2.5` (comfortable tap target)
- Background: `bg-white` (not transparent)
- Disabled: `bg-soil-50 text-soil-500 cursor-not-allowed`

### Cards

- Background: `bg-white` (on `bg-soil-50` page)
- Border: `border border-soil-200` or `shadow-md` (choose one, not both)
- Padding: `p-4` (mobile) or `p-6` (desktop)
- Radius: `rounded-md`
- Hover state for interactive cards: `hover:shadow-md transition-shadow`

### Typography in Components

- **Card title:** `text-lg font-semibold text-soil-900`
- **Card subtitle:** `text-sm text-soil-700`
- **Price (primary):** `text-2xl font-bold text-turmeric-700 font-mono`
- **Price (secondary/unit):** `text-sm text-soil-700 font-mono`
- **Body text:** `text-base text-soil-900 leading-relaxed`
- **Muted text:** `text-sm text-soil-500`

### Icons

- **Library:** Lucide React (clean, consistent, tree-shakeable)
- **Size:** `w-5 h-5` (default), `w-6 h-6` (emphasized)
- **Color:** Match text color, never pure black

### Badges and Tags

- **Status (success):** `bg-leaf-100 text-leaf-600 px-2.5 py-1 rounded-sm text-xs font-medium`
- **Status (pending):** `bg-sky-100 text-sky-600 px-2.5 py-1 rounded-sm text-xs font-medium`
- **Status (danger):** `bg-clay-100 text-clay-600 px-2.5 py-1 rounded-sm text-xs font-medium`
- **Count badge:** `bg-turmeric-500 text-soil-900 rounded-full px-2 py-0.5 text-xs font-semibold`

---

## MOTION AND INTERACTION

### Principles
- **Motion explains user action:** add-to-cart confirmation, drawer open/close, status change
- **No scattered animations:** avoid fade-in-up on every card, hover lift on every element
- **At most one orchestrated page-load animation:** the seasonal hero tiles can stagger in (100ms delay between each), everything else loads instantly
- **Respect `prefers-reduced-motion`:** all animations optional

### Transitions
- **Fast interactions (hover, focus):** `transition-colors duration-150`
- **UI state changes (open/close):** `transition-all duration-200 ease-in-out`
- **Data loading (skeleton → content):** fade-in `duration-300`

### Optimistic UI
- Cart add: immediately show in cart count, rollback on error
- Wishlist toggle: immediate visual feedback, sync to server
- Notification read: gray out immediately, persist async

### Loading States
- **Skeleton loaders:** Match final layout shape (no layout shift)
- **Color:** `bg-soil-100 animate-pulse`
- **Never:** generic spinners in the middle of the page (use skeletons)

### Error States
- **Inline errors:** red text below input, `text-clay-600 text-sm`
- **Page-level errors:** centered card with icon, message, and retry button
- **Toast notifications:** bottom-right, auto-dismiss in 5s, dismissible

### Empty States
- **Message:** "No products yet. Add your first product to get started."
- **Action:** Primary CTA to resolve ("Add Product")
- **Illustration:** Simple icon, not complex illustration

---

## ACCESSIBILITY NOTES

### Keyboard Navigation
- All interactive elements reachable via Tab
- Logical tab order (left-to-right, top-to-bottom)
- Skip link to main content (first tab stop)
- Focus visible: `focus-visible:ring-2 focus-visible:ring-paddy-500 focus-visible:ring-offset-2`

### Screen Readers
- Semantic HTML (`<header>`, `<nav>`, `<main>`, `<article>`, `<aside>`, `<footer>`)
- Logical heading hierarchy (h1 → h2 → h3, no skipping)
- Form labels always associated (`<label htmlFor="...">`)
- Images with descriptive alt text (product images: include product name and key attribute)
- Icon-only buttons with `aria-label`

### Color and Contrast
- All text meets WCAG 2.2 AA (4.5:1 for body, 3:1 for large text)
- Never rely on color alone (use icons + text for status)
- Focus rings visible on all interactive elements

### Touch Targets
- Minimum 44×44px
- Adequate spacing between interactive elements (at least 8px)

---

## INTERNATIONALIZATION (i18n)

### Languages (Core)
- **English** (default, `en`)
- **Hindi** (`hi`)
- **Tamil** (`ta`)

**Structure ready for:** Telugu, Kannada, Malayalam, Marathi, Bengali, Punjabi

### Regional Formats

**Numbers:**
- Indian grouping: ₹1,25,000 (not ₹125,000)
- Decimals: ₹1,250.50 (period as decimal separator)

**Dates:**
- Short: `10/11/2026` (DD/MM/YYYY)
- Long: `10 November 2026`
- Time: 24-hour preferred, 12-hour with AM/PM optional

**Currency:**
- Symbol: ₹ (U+20B9)
- Placement: ₹1,250 (symbol before amount)

### Text Expansion
- Indic scripts can be 30-40% wider than English
- All layouts tested with Hindi (Devanagari) and Tamil
- No fixed-width containers for text content
- Buttons sized with `px-4 py-2.5` padding (flex to fit)

### Language Switcher
- Persistent in header (flag icon + language name)
- Saves preference per user (if logged in) or localStorage

---

## PERFORMANCE BUDGET

### Targets
- **LCP (Largest Contentful Paint):** < 2.5s
- **CLS (Cumulative Layout Shift):** < 0.1
- **INP (Interaction to Next Paint):** < 200ms

### Strategies
- **Images:** Responsive (`srcset`), WebP/AVIF, lazy loading below fold
- **Fonts:** Variable fonts (Inter Variable single file), `font-display: swap`, subset to Latin + Devanagari + Tamil
- **Code splitting:** Route-level, lazy load modals/drawers
- **API data:** TanStack Query with stale-while-revalidate, optimistic updates
- **Bundle size:** Core bundle < 150KB gzipped

### Low-Bandwidth Considerations
- Graceful degradation on slow 4G
- Skeleton loaders prevent perception of hang
- Critical CSS inlined
- Offline fallback page (PWA)

---

## REVIEW AGAINST GENERIC DEFAULTS

| Aspect | Generic Default | AgriSphere Choice | Why Different |
|--------|----------------|-------------------|---------------|
| **Color** | Blue primary, gray neutral | Paddy green, soil brown, turmeric accent | Agricultural grounding, not tech SaaS |
| **Typography** | Poppins/Montserrat, or serif for headings | Inter Variable (single family) | Avoids overused choices, excellent Indic support |
| **Hero** | Stock photo + tagline + CTA | Seasonal crop calendar with live prices | Useful data, not marketing |
| **Cards** | All with same shadow and radius | Varied shadow (sm for most, md for interactive) | Intentional hierarchy |
| **Motion** | Fade-in on every card | One orchestrated load (hero tiles), rest instant | Focused, not scattered |
| **Price Display** | Sans-serif, color emphasis only | Monospace, turmeric highlight, unit included | Tabular clarity, agricultural context |
| **Empty State** | Centered illustration + prose | Simple icon + message + action CTA | Direct, not decorative |
| **Button Style** | Rounded-full, gradient, or shadow | Rounded-sm, solid fill, no gradient | Honest, no embellishment |

---

## IMPLEMENTATION CHECKLIST

- [ ] Create Tailwind config with theme tokens (colors, spacing, fonts, shadows, radius)
- [ ] Export CSS variables for runtime access (dark mode switching)
- [ ] Install and configure Inter Variable font with Devanagari + Tamil subsets
- [ ] Set up next-intl with en/hi/ta translations structure
- [ ] Build primitive components (Button, Input, Card, Badge, etc.) with Radix UI base
- [ ] Create seasonal hero component (query live crop/price data from backend)
- [ ] Build shared layout shell (header, nav, footer)
- [ ] Implement responsive breakpoints and test at 360px, 768px, 1280px
- [ ] Add focus-visible styles and keyboard navigation support
- [ ] Set up Storybook for component library (stretch goal, after core completion)

---

## OPEN QUESTIONS FOR IMPLEMENTATION

1. **Font Loading Strategy:** Should we inline critical font subsets or rely on `font-display: swap`? → Decision: Swap for now, optimize later if FOUT is noticeable.

2. **Dark Mode Priority:** Core feature or stretch? → Decision: Design tokens support it, but toggle UI is stretch (after core completion).

3. **Seasonal Hero Data Source:** Separate API endpoint or embedded in landing page data? → Decision: Dedicated `/api/v1/marketplace/seasonal` endpoint, cached 24h.

4. **Icon Library:** Lucide vs. Heroicons? → Decision: Lucide (cleaner, better tree-shaking).

---

**End of Design Specification v1.0**

This design system will be implemented as Tailwind theme configuration, CSS variables, and React components. All subsequent UI work must reference this document.
