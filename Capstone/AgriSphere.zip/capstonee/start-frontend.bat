@echo off
echo ========================================
echo AgriSphere Frontend Server
echo ========================================
echo.
echo Starting Next.js frontend on port 5000...
echo.

cd frontend

if not exist node_modules (
    echo Installing dependencies...
    call npm install
)

echo.
echo Frontend starting on http://localhost:5000
echo Press Ctrl+C to stop
echo.

call npm run dev
pause
