@echo off
echo ========================================
echo AgriSphere - Starting Full Stack
echo ========================================
echo.
echo This will start:
echo   - Backend (C++ Crow) on port 6001
echo   - Frontend (Next.js) on port 5000
echo.
echo Close any window to stop that service
echo.
pause

start "AgriSphere Backend" cmd /k "%~dp0start-backend.bat"
timeout /t 3 /nobreak >nul
start "AgriSphere Frontend" cmd /k "%~dp0start-frontend.bat"

echo.
echo ========================================
echo Both services started!
echo ========================================
echo.
echo Backend:  http://localhost:6001
echo Frontend: http://localhost:5000
echo.
echo Opening frontend in browser...
timeout /t 5 /nobreak >nul
start http://localhost:5000/products
echo.
echo Done! Check the opened windows.
pause
