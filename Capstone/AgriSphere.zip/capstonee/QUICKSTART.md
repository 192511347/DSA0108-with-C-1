# AgriSphere - Quick Start Guide

Get the full AgriSphere application running in minutes.

## Prerequisites

- **PostgreSQL** 13+ installed and running
- **Node.js** 18+ and npm installed
- **C++ Compiler** (MSVC 2019+ for Windows)
- **CMake** 3.20+
- **vcpkg** (for C++ dependencies)

## Quick Setup (5 Minutes)

### 1. Database Setup (1 minute)

```bash
# Create database
psql -U postgres
CREATE DATABASE agrisphere;
\q

# Run migrations
psql -U postgres -d agrisphere -f backend/migrations/001_initial_schema.sql
psql -U postgres -d agrisphere -f backend/migrations/002_seed_data.sql
```

### 2. Backend Setup (2 minutes)

```bash
cd backend

# Build (if not already built)
# cmake -B build -S . -DCMAKE_TOOLCHAIN_FILE=[vcpkg_path]/scripts/buildsystems/vcpkg.cmake
# cmake --build build --config Release

# Configure database connection
# Edit backend/config.json if needed (default: localhost:5432)

# Start backend
.\build\Release\AgriSphere.exe
```

**Backend will run on:** http://localhost:6001

### 3. Frontend Setup (2 minutes)

```bash
cd frontend

# Install dependencies (first time only)
npm install

# Start development server
npm run dev
```

**Frontend will run on:** http://localhost:5000

## Verify Everything Works

### Test Backend
```bash
curl http://localhost:6001/api/v1/health
# Should return: {"success":true,"data":{"status":"healthy"}}
```

### Test Frontend
1. Open http://localhost:5000 in your browser
2. Navigate to "Products" - should see 84 products
3. Try logging in (create account first if needed)

## Available Accounts (Seeded Data)

### Test Users
```
Email: farmer@test.com
Password: Test@1234
Role: FARMER

Email: buyer@test.com
Password: Test@1234
Role: BUYER

Email: seller@test.com
Password: Test@1234
Role: SELLER
```

## Project Structure

```
agrisphere/
├── backend/                    # C++ Crow Backend (Port 6001)
│   ├── src/                   # Source code
│   ├── build/                 # Build output
│   ├── migrations/            # Database migrations
│   └── config.json            # Configuration
│
├── frontend/                   # Next.js Frontend (port 5000)
│   ├── src/
│   │   ├── app/              # Next.js pages
│   │   ├── components/        # React components
│   │   ├── contexts/          # React contexts (auth)
│   │   ├── lib/              # API client
│   │   └── types/            # TypeScript types
│   └── docs/                  # Documentation
│
└── docs/                      # Project documentation
```

## Common Commands

### Backend
```bash
# Rebuild
cmake --build build --config Release

# Run
.\build\Release\AgriSphere.exe

# Run tests (if available)
.\build\Release\AgriSphere_tests.exe
```

### Frontend
```bash
# Development
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Type checking
npx tsc --noEmit

# Linting
npm run lint
```

## API Endpoints

### Working Endpoints (8)
- `GET /api/v1/health` - Health check
- `POST /api/v1/auth/register` - User registration
- `POST /api/v1/auth/login` - User login
- `GET /api/v1/products` - List products (with filters)
- `GET /api/v1/products/categories` - List categories
- `GET /api/v1/products/:id` - Get product details
- `GET /api/v1/cart` - Get user's cart
- `POST /api/v1/cart/items` - Add item to cart

### Pending Endpoints (7)
- `GET /api/v1/auth/me` - Get current user
- `POST /api/v1/auth/refresh` - Refresh token
- `POST /api/v1/auth/logout` - Logout
- `PUT /api/v1/auth/profile` - Update profile
- `PUT /api/v1/cart/items/:id` - Update cart item
- `DELETE /api/v1/cart/items/:id` - Remove cart item
- `DELETE /api/v1/cart` - Clear cart

## Features Available

### ✅ Working Features
- User registration and login
- Browse products with filters (category, search, price range)
- View product details
- Add products to cart
- View shopping cart
- Role-based dashboards
- Protected routes
- Responsive design

### ⏸️ Features Pending Backend
- Cart quantity updates
- Remove cart items
- User profile updates
- Order management
- Token refresh
- Equipment marketplace
- Service booking

## Troubleshooting

### Backend won't start
```bash
# Check if port 6001 is already in use
netstat -ano | findstr :6001

# Check PostgreSQL connection
psql -U postgres -d agrisphere -c "SELECT 1"
```

### Frontend won't start
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Check if port 5000 is already in use
netstat -ano | findstr :3000
```

### Can't connect to backend from frontend
1. Check backend is running: http://localhost:6001/api/v1/health
2. Check frontend `.env.local`:
   ```
   NEXT_PUBLIC_API_URL=http://localhost:6001/api/v1
   ```
3. Restart frontend development server

### Database connection errors
1. Verify PostgreSQL is running
2. Check connection string in `backend/config.json`
3. Verify database exists: `psql -U postgres -l`
4. Check migrations ran: `psql -U postgres -d agrisphere -c "\dt"`

## Documentation

- **API Documentation**: `backend/API.md`
- **Frontend Progress**: `frontend/docs/FRONTEND_PROGRESS.md`
- **Test Plan**: `frontend/TEST_PLAN.md`
- **Integration Guide**: `frontend/INTEGRATION_STATUS.md`
- **Completion Report**: `frontend/COMPLETION_REPORT.md`
- **Backend Progress**: `docs/BACKEND_PROGRESS.md`

## Development Workflow

### Adding a New Feature

1. **Backend** (if API needed):
   ```bash
   cd backend/src
   # Add controller, service, repository
   # Update routes in main.cpp
   # Rebuild and test
   ```

2. **Frontend**:
   ```bash
   cd frontend/src
   # Add page in app/
   # Add API call in lib/api.ts
   # Add types in types/index.ts
   # Test in browser
   ```

3. **Testing**:
   - Manual testing with browser
   - Check API with curl/Postman
   - Verify TypeScript compiles
   - Test on different screen sizes

## Deployment Checklist

### Backend
- [ ] Build in Release mode
- [ ] Update config.json for production DB
- [ ] Set environment variables
- [ ] Configure reverse proxy (nginx)
- [ ] Enable HTTPS
- [ ] Set up monitoring

### Frontend
- [ ] Run `npm run build`
- [ ] Update environment variables
- [ ] Configure CDN for static assets
- [ ] Set up analytics
- [ ] Enable error tracking
- [ ] Configure caching headers

## Support

### Getting Help
- Check documentation in `/docs` and `/frontend/docs`
- Review `TEST_PLAN.md` for known issues
- Check git commit history for recent changes
- Review code comments for implementation details

### Common Issues
1. **"Port already in use"** - Kill the process or use different port
2. **"Database connection failed"** - Check PostgreSQL and credentials
3. **"CORS errors"** - Check backend CORS configuration
4. **"404 on API calls"** - Verify backend is running and URL is correct

---

## Next Steps

After getting everything running:

1. **Test the application**
   - Follow `frontend/TEST_PLAN.md`
   - Try all user flows
   - Test on mobile devices

2. **Review the code**
   - Check `frontend/COMPLETION_REPORT.md` for architecture
   - Review component structure
   - Understand auth flow

3. **Implement missing features**
   - Complete backend endpoints (see API.md)
   - Add remaining dashboards
   - Implement orders system

4. **Optimize and deploy**
   - Performance testing
   - Security audit
   - Production deployment

---

**Quick Start Time**: ~5 minutes  
**Full Setup Time**: ~15 minutes  
**Time to First Features**: Immediate

**Status**: ✅ Ready for development and testing  
**Version**: 1.0.0  
**Last Updated**: Phase 2 & 3 Complete
