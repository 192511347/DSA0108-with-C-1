# AgriSphere Backend - Quick Test Guide

## Start the Backend

```powershell
cd C:\Users\Mohan\Downloads\capstonee\backend
.\build\Release\AgriSphere.exe
```

The server will start on **port 6001**.

---

## Test Endpoints

### 1. Health Check
```bash
curl http://localhost:6001/api/v1/health
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "status": "ok",
    "service": "AgriSphere C++ API",
    "database": "connected",
    "timestamp": 1705588457
  }
}
```

---

### 2. Get Products
```bash
curl http://localhost:6001/api/v1/products?pageSize=5
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "products": [
      {
        "id": "uuid",
        "name": "Premium Basmati Rice",
        "category": "GRAINS",
        "pricePerUnit": 8500,
        "unit": "KG",
        "availableQuantity": 500,
        ...
      }
    ],
    "pagination": {
      "page": 1,
      "pageSize": 5,
      "totalItems": 84,
      "totalPages": 17
    }
  }
}
```

---

### 3. Register New User
```bash
curl -X POST http://localhost:6001/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@example.com",
    "password": "SecurePass123!",
    "fullName": "New User",
    "phone": "1234567890",
    "role": "BUYER"
  }'
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "email": "newuser@example.com",
      "fullName": "New User",
      "role": "BUYER",
      ...
    },
    "tokens": {
      "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
    }
  }
}
```

---

### 4. Login
```bash
curl -X POST http://localhost:6001/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "buyer@agrisphere.in",
    "password": "buyer123"
  }'
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "user": {...},
    "tokens": {
      "accessToken": "eyJhbG...",
      "refreshToken": "eyJhbG..."
    }
  }
}
```

**Save the `accessToken` for authenticated requests!**

---

### 5. Get Cart (Authenticated)
```bash
curl -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  http://localhost:6001/api/v1/cart
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "cart": {
      "id": "uuid",
      "userId": "uuid",
      "items": [],
      "totalItems": 0,
      "totalAmount": 0,
      ...
    }
  }
}
```

---

### 6. Add Item to Cart (Authenticated)
```bash
curl -X POST http://localhost:6001/api/v1/cart/items \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "productId": "e1849603-478b-4c16-985e-d025110357bf",
    "quantity": 2
  }'
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "cart": {
      "items": [
        {
          "id": "uuid",
          "productId": "e1849603-478b-4c16-985e-d025110357bf",
          "quantity": 2,
          "product": {
            "name": "Premium Basmati Rice",
            "pricePerUnit": 8500,
            ...
          },
          "subtotal": 17000
        }
      ],
      "totalItems": 2,
      "totalAmount": 17000
    }
  }
}
```

---

## PowerShell Test Script

Use the provided test script:

```powershell
cd C:\Users\Mohan\Downloads\capstonee
.\test-endpoints.ps1
```

This will automatically test all endpoints and show results.

---

## Troubleshooting

### Server Won't Start
- Check if port 6001 is already in use
- Verify PostgreSQL is running
- Check `.env` file has correct database password

### Database Connection Failed
- Ensure PostgreSQL service is running
- Verify credentials in `.env`:
  ```
  DB_HOST=localhost
  DB_PORT=5432
  DB_NAME=agrisphere
  DB_USER=postgres
  DB_PASSWORD=postgres
  ```

### Products Not Showing
- ✅ **FIXED** - Removed non-existent district/state columns from queries
- Verify database has products: `psql -U postgres -d agrisphere -c "SELECT COUNT(*) FROM products;"`

### Login Failing
- Check if user exists in database
- Verify password hash in database
- Check backend logs for error messages

---

## Working Endpoints (7/8)

✅ GET `/api/v1/health`  
✅ POST `/api/v1/auth/register`  
✅ POST `/api/v1/auth/login`  
✅ GET `/api/v1/products`  
✅ GET `/api/v1/products/:id`  
✅ GET `/api/v1/cart` (auth required)  
✅ POST `/api/v1/cart/items` (auth required)  
⚠️ POST `/api/v1/products` (stub - needs implementation)

---

## Database

**Connection:**
- Host: localhost
- Port: 5432
- Database: agrisphere
- User: postgres
- Password: postgres

**Tables:**
- users (11 records)
- products (84 records)
- carts
- cart_items
- orders
- order_items
- reviews
- refresh_tokens

---

## Next Steps

1. Test all endpoints manually
2. Verify authentication flow
3. Test cart operations
4. Check database persistence
5. Ready for frontend integration!

---

**Status:** ✅ All major endpoints working  
**Last Fix:** 2025-01-18 - Removed non-existent columns from ProductRepository
