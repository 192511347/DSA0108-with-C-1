@echo off
title AgriSphere Startup
color 0A

cls
echo ========================================
echo    AGRISPHERE - STARTING SERVERS
echo ========================================
echo.

REM Kill any existing processes on ports
echo Cleaning up ports...
for /f "tokens=5" %%a in ('netstat -aon ^| find ":5000" ^| find "LISTENING"') do taskkill /F /PID %%a >nul 2>&1
for /f "tokens=5" %%a in ('netstat -aon ^| find ":6001" ^| find "LISTENING"') do taskkill /F /PID %%a >nul 2>&1
timeout /t 2 >nul

REM Start C++ Backend (via WSL2 + Docker)
echo Starting C++ Backend (Port 6001)...
start "Backend" cmd /k "wsl -d Ubuntu bash -c 'cd /mnt/c/Users/Mohan/Downloads/capstonee/backend && docker-compose up'"
timeout /t 10 >nul

REM Start Frontend  
echo Starting Frontend (Port 5000)...
start "Frontend" cmd /k "cd frontend && npm run dev"
timeout /t 10 >nul

REM Open Browser
echo Opening browser...
timeout /t 5 >nul
start http://localhost:5000

cls
echo ========================================
echo    AGRISPHERE IS RUNNING
echo ========================================
echo.
echo Frontend: http://localhost:5000
echo Backend:  http://localhost:6001
echo.
echo Login with:
echo   farmer@agrisphere.in   / Farmer@DemoOnly2024
echo   buyer@agrisphere.in    / Buyer@DemoOnly2024
echo   seller@agrisphere.in   / Seller@DemoOnly2024
echo   provider@agrisphere.in / Provider@DemoOnly2024
echo   admin@agrisphere.in    / Admin@DemoOnly2024
echo.
echo Close this window anytime.
echo To stop servers, close the Backend and Frontend windows.
echo.
pause
