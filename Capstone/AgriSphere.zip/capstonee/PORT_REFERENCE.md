# AgriSphere - Port Configuration

## Current Port Configuration

| Service | Port | URL |
|---------|------|-----|
| **Frontend (Next.js)** | 5000 | http://localhost:5000 |
| **Backend (C++ Crow)** | 6001 | http://localhost:6001 |
| **PostgreSQL** | 5432 | localhost:5432 |

## Frontend URLs

- **Landing Page**: http://localhost:5000
- **Products**: http://localhost:5000/products
- **Login**: http://localhost:5000/login
- **Register**: http://localhost:5000/register
- **Cart**: http://localhost:5000/cart
- **Dashboard**: http://localhost:5000/dashboard
- **API Test**: http://localhost:5000/test-api

## Backend API URLs

- **Health Check**: http://localhost:6001/api/v1/health
- **Products**: http://localhost:6001/api/v1/products
- **Categories**: http://localhost:6001/api/v1/products/categories
- **Login**: http://localhost:6001/api/v1/auth/login
- **Register**: http://localhost:6001/api/v1/auth/register
- **Cart**: http://localhost:6001/api/v1/cart

## Starting the Application

### Option 1: Start Everything (Recommended)
```batch
start-all.bat
```

### Option 2: Start Separately
```batch
# Terminal 1 - Backend
start-backend.bat

# Terminal 2 - Frontend  
start-frontend.bat
```

### Option 3: Manual Start
```batch
# Backend
cd backend
.\build\Release\AgriSphere.exe

# Frontend (in new terminal)
cd frontend
npm run dev
```

## Verifying Services

### Check Backend
```powershell
Invoke-RestMethod http://localhost:6001/api/v1/health
```

### Check Frontend
Open browser: http://localhost:5000

### Check Ports
```powershell
Get-NetTCPConnection -State Listen | Where-Object {$_.LocalPort -in @(5000, 6001)}
```

## Troubleshooting

### Port 5000 Already in Use
```powershell
# Find process
Get-Process -Id (Get-NetTCPConnection -LocalPort 5000).OwningProcess

# Kill process
Stop-Process -Id (Get-NetTCPConnection -LocalPort 5000).OwningProcess -Force
```

### Port 6001 Already in Use
```powershell
# Find process
Get-Process -Id (Get-NetTCPConnection -LocalPort 6001).OwningProcess

# Kill process
Stop-Process -Id (Get-NetTCPConnection -LocalPort 6001).OwningProcess -Force
```

## Changing Ports

### Frontend Port
Edit `frontend/package.json`:
```json
"scripts": {
  "dev": "next dev -p 5000",
  "start": "next start -p 5000"
}
```

### Backend Port
Edit `backend/src/main.cpp` - look for port configuration (currently 6001)

## Environment Variables

Frontend environment file: `frontend/.env.local`
```env
NEXT_PUBLIC_API_URL=http://localhost:6001/api/v1
```

## Important Notes

- ✅ Frontend runs on **port 5000** (not 3000)
- ✅ Backend runs on **port 6001**
- ✅ Use batch files for easy startup
- ✅ Both services must be running for full functionality
- ✅ Products page works even if backend is down (shows cached data)

## Quick Reference

```
Frontend:     http://localhost:5000
Backend API:  http://localhost:6001/api/v1
Database:     localhost:5432/agrisphere

Batch Files:
- start-all.bat      (Start everything)
- start-frontend.bat (Frontend only)
- start-backend.bat  (Backend only)
```
