cmake_minimum_required(VERSION 3.15)
project(AgriSphere VERSION 1.0.0 LANGUAGES CXX)

# C++17 standard (Crow compatible)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# Windows-specific settings
if(MSVC)
    add_compile_options(/W4 /EHsc /std:c++17)
    add_definitions(-D_WIN32_WINNT=0x0601 -DNOMINMAX -D_CRT_SECURE_NO_WARNINGS)
endif()

# Find packages
find_package(Crow CONFIG REQUIRED)
find_package(nlohmann_json CONFIG REQUIRED)
find_package(PostgreSQL REQUIRED)
find_package(OpenSSL REQUIRED)
find_package(jwt-cpp CONFIG REQUIRED)

# Source files
set(SOURCES
    src/main.cpp
    src/utils/Logger.cpp
)

# Header files (for IDE support)
set(HEADERS
    include/core/Config.h
    include/core/Database.h
    include/utils/Logger.h
    include/utils/ResponseHelper.h
    include/utils/PasswordUtil.h
    include/utils/JwtUtil.h
    include/models/User.h
    include/models/Product.h
    include/repositories/UserRepository.h
    include/repositories/ProductRepository.h
    include/services/AuthService.h
    include/services/ProductService.h
)

# Executable
add_executable(${PROJECT_NAME} ${SOURCES})

# Link libraries
target_link_libraries(${PROJECT_NAME} PRIVATE
    Crow::Crow
    nlohmann_json::nlohmann_json
    PostgreSQL::PostgreSQL
    OpenSSL::SSL
    OpenSSL::Crypto
    jwt-cpp::jwt-cpp
)

# Windows system libraries
if(WIN32)
    target_link_libraries(${PROJECT_NAME} PRIVATE ws2_32 wsock32)
endif()

# Include directories
target_include_directories(${PROJECT_NAME} PRIVATE
    ${PROJECT_SOURCE_DIR}/include
    ${PROJECT_SOURCE_DIR}/src
    ${PostgreSQL_INCLUDE_DIRS}
)

if(WIN32)
  target_link_libraries(${PROJECT_NAME} PRIVATE winhttp)
endif()
