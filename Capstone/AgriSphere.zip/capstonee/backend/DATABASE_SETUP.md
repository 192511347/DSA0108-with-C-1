# Database Setup Guide

## Current Status

The C++ backend now has **full database integration** but requires your PostgreSQL password.

### ⚠️ Database Connection Error

If you see:
```
password authentication failed for user "postgres"
```

You need to configure your PostgreSQL password in the `.env` file.

---

## Quick Fix

### Step 1: Find Your PostgreSQL Password

#### Option A: Check Installation Notes
When you installed PostgreSQL, you set a password. Check your notes or try common defaults.

#### Option B: Reset PostgreSQL Password

1. Open Command Prompt **as Administrator**
2. Run:
```cmd
psql -U postgres -d postgres
```

3. If it asks for password and you don't know it, use pg_hba.conf method:

**Find pg_hba.conf:**
```powershell
Get-ChildItem -Path "C:\Program Files\PostgreSQL\" -Recurse -Filter "pg_hba.conf"
```

**Edit pg_hba.conf** (as Administrator):
Find this line:
```
host    all             all             127.0.0.1/32            scram-sha-256
```

Change to:
```
host    all             all             127.0.0.1/32            trust
```

**Restart PostgreSQL:**
```powershell
Restart-Service postgresql-x64-18
```

**Reset Password:**
```powershell
psql -U postgres -d postgres
```
```sql
ALTER USER postgres PASSWORD 'your_new_password';
\q
```

**Restore pg_hba.conf** (change `trust` back to `scram-sha-256`) and restart service.

---

### Step 2: Update Backend .env

Edit `backend/.env`:
```env
DB_PASSWORD=your_actual_password
```

---

### Step 3: Restart Backend

```powershell
cd backend\build
.\Release\AgriSphere.exe
```

You should see:
```
✅ Database connected: agrisphere
```

---

## Verify Database Schema

Check if tables exist:
```powershell
$env:PGPASSWORD="your_password"
psql -h localhost -p 5432 -U postgres -d agrisphere -c "\dt"
```

Expected tables:
- users
- products
- carts
- cart_items
- orders
- services
- bookings

---

## Test Database Connection

### Test with Health Endpoint:
```powershell
Invoke-WebRequest -Uri "http://localhost:6001/api/v1/health" -UseBasicParsing | Select-Object -ExpandProperty Content
```

Expected response:
```json
{
  "success": true,
  "data": {
    "status": "ok",
    "service": "AgriSphere C++ API",
    "database": "connected",  ← Should say "connected"
    "timestamp": 1794928726
  }
}
```

---

## Database Features Now Working

✅ **Health Check** - Shows real database status  
✅ **Login** - Queries users table for authentication  
✅ **Products** - Fetches real products from database  
🚧 **Cart** - Still using stubs (pending implementation)  
🚧 **Orders** - Still using stubs (pending implementation)

---

## What Changed

### Before:
```
"database": "not_connected"  ❌
```
All endpoints returned stub data.

### After:
```
"database": "connected"  ✅
```
Login and Products endpoints now use real database queries.

---

## Troubleshooting

### Issue: "Database not connected"
**Solution:** Update `.env` with correct password and restart

### Issue: "Database 'agrisphere' does not exist"
**Solution:** Create database:
```sql
CREATE DATABASE agrisphere;
```

### Issue: "Table does not exist"
**Solution:** Run database migrations (seed script needed)

### Issue: Port 5432 not accessible
**Solution:** Check PostgreSQL is running:
```powershell
Get-Service postgresql-x64-18
```

---

## Next Steps

1. **Set PostgreSQL password** in `.env`
2. **Restart backend**
3. **Verify connection** with health endpoint
4. **Seed database** with demo data (script pending)
5. **Test login** with real user credentials

---

## Security Notes

- ⚠️ Never commit `.env` file (already in `.gitignore`)
- ✅ Use `.env.example` for documentation
- 🔒 Use strong passwords in production
- 🔐 Password hashing (Argon2id) will be added next

---

**Once database is connected, the backend will use real data instead of stubs!**
