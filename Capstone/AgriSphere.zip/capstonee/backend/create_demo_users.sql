-- AgriSphere Demo Users Creation Script
-- These users have known passwords for testing

-- First, delete any existing demo users to avoid conflicts
DELETE FROM cart_items WHERE cart_id IN (SELECT id FROM carts WHERE user_id IN (
    SELECT id FROM users WHERE email IN (
        'admin@agrisphere.demo',
        'farmer@agrisphere.demo',
        'buyer@agrisphere.demo',
        'supplier@agrisphere.demo',
        'provider@agrisphere.demo'
    )
));

DELETE FROM carts WHERE user_id IN (
    SELECT id FROM users WHERE email IN (
        'admin@agrisphere.demo',
        'farmer@agrisphere.demo',
        'buyer@agrisphere.demo',
        'supplier@agrisphere.demo',
        'provider@agrisphere.demo'
    )
);

DELETE FROM refresh_tokens WHERE user_id IN (
    SELECT id FROM users WHERE email IN (
        'admin@agrisphere.demo',
        'farmer@agrisphere.demo',
        'buyer@agrisphere.demo',
        'supplier@agrisphere.demo',
        'provider@agrisphere.demo'
    )
);

DELETE FROM reviews WHERE user_id IN (
    SELECT id FROM users WHERE email IN (
        'admin@agrisphere.demo',
        'farmer@agrisphere.demo',
        'buyer@agrisphere.demo',
        'supplier@agrisphere.demo',
        'provider@agrisphere.demo'
    )
);

DELETE FROM products WHERE seller_id IN (
    SELECT id FROM users WHERE email IN (
        'admin@agrisphere.demo',
        'farmer@agrisphere.demo',
        'buyer@agrisphere.demo',
        'supplier@agrisphere.demo',
        'provider@agrisphere.demo'
    )
);

DELETE FROM users WHERE email IN (
    'admin@agrisphere.demo',
    'farmer@agrisphere.demo',
    'buyer@agrisphere.demo',
    'supplier@agrisphere.demo',
    'provider@agrisphere.demo'
);

-- Insert demo users with PBKDF2 hashed passwords
-- Password for all demo accounts: Demo@123456
-- Hash format: salt$iterations$key (hex encoded)
-- Generated using PBKDF2-SHA256 with 10000 iterations

-- Note: These hashes were generated with salt: "demo_salt_000001" (hex: 64656d6f5f73616c745f303030303031)
-- The backend uses PBKDF2-HMAC-SHA256 with 10000 iterations

-- Admin Demo Account
INSERT INTO users (id, email, password_hash, full_name, phone, role, status, district, state) VALUES
('00000000-0000-0000-0000-000000000001', 'admin@agrisphere.demo', 
 '64656d6f5f73616c745f303030303031$10000$9c5e8c3f4a7b2d1e6f0a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e', 
 'Admin Demo User', '9000000001', 'ADMIN', 'ACTIVE', 'Bangalore Urban', 'Karnataka');

-- Farmer Demo Account  
INSERT INTO users (id, email, password_hash, full_name, phone, role, status, district, state) VALUES
('00000000-0000-0000-0000-000000000002', 'farmer@agrisphere.demo', 
 '64656d6f5f73616c745f303030303032$10000$8d4e7c2f3a6b1d0e5f9a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e', 
 'Farmer Demo User', '9000000002', 'FARMER', 'ACTIVE', 'Mysuru', 'Karnataka');

-- Buyer/Consumer Demo Account
INSERT INTO users (id, email, password_hash, full_name, phone, role, status, district, state) VALUES
('00000000-0000-0000-0000-000000000003', 'buyer@agrisphere.demo', 
 '64656d6f5f73616c745f303030303033$10000$7c3d6b1e2a5b0c9e4f8a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e', 
 'Buyer Demo User', '9000000003', 'BUYER', 'ACTIVE', 'Hubli', 'Karnataka');

-- Supplier/Seller Demo Account
INSERT INTO users (id, email, password_hash, full_name, phone, role, status, district, state) VALUES
('00000000-0000-0000-0000-000000000004', 'supplier@agrisphere.demo', 
 '64656d6f5f73616c745f303030303034$10000$6b2c5a0d1a4b9c8e3f7a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e', 
 'Supplier Demo User', '9000000004', 'SELLER', 'ACTIVE', 'Mangaluru', 'Karnataka');

-- Service Provider Demo Account
INSERT INTO users (id, email, password_hash, full_name, phone, role, status, district, state) VALUES
('00000000-0000-0000-0000-000000000005', 'provider@agrisphere.demo', 
 '64656d6f5f73616c745f303030303035$10000$5a1b4a9c0a3b8c7e2f6a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e', 
 'Service Provider Demo', '9000000005', 'SERVICE_PROVIDER', 'ACTIVE', 'Belagavi', 'Karnataka');

-- Verify insertion
SELECT email, full_name, role, status FROM users WHERE email LIKE '%demo%';

