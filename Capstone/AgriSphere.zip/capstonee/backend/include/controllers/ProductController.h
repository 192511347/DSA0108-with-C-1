/**
 * ProductController.h
 * Handles product-related routes (listing, CRUD operations)
 */

#ifndef AGRISPHERE_PRODUCTCONTROLLER_H
#define AGRISPHERE_PRODUCTCONTROLLER_H

#include <crow.h>
#include <nlohmann/json.hpp>
#include <memory>
#include <algorithm>
#include <string>

#include "services/ProductService.h"
#include "services/AuthService.h"
#include "utils/ResponseHelper.h"
#include "utils/Logger.h"

namespace agrisphere {
namespace controllers {

using json = nlohmann::json;

/**
 * Product controller
 * Registers product routes with Crow application
 */
class ProductController {
private:
    std::shared_ptr<services::ProductService> productService;
    std::shared_ptr<services::AuthService> authService;
    std::shared_ptr<utils::ResponseHelper> responseHelper;

public:
    /**
     * Constructor
     * @param productService Product service
     * @param responseHelper Response helper utility
     */
    ProductController(
        std::shared_ptr<services::ProductService> productService,
        std::shared_ptr<services::AuthService> authService,
        std::shared_ptr<utils::ResponseHelper> responseHelper
    ) : productService(productService), authService(authService), responseHelper(responseHelper) {}

    /**
     * Register all product routes with Crow app
     * @param app Crow application instance
     */
    void registerRoutes(crow::SimpleApp& app) {
        getProductsRoute(app);
        getCategoriesRoute(app);
        getMyProductsRoute(app);
        getProductByIdRoute(app);
        createProductRoute(app);
    }

private:
    /**
     * GET /api/v1/products
     * Get paginated list of products with optional filtering
     */
    void getProductsRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/products")
        ([this](const crow::request& req) {
            utils::Logger::apiRequest("GET", "/api/v1/products");
            
            try {
                // Parse query parameters
                char* pageParam = req.url_params.get("page");
                char* pageSizeParam = req.url_params.get("pageSize");
                char* categoryParam = req.url_params.get("category");

                int page = pageParam ? std::stoi(pageParam) : 1;
                int pageSize = pageSizeParam ? std::stoi(pageSizeParam) : 20;
                page = std::max(1, page);
                pageSize = std::max(1, std::min(100, pageSize));
                std::string category = categoryParam ? categoryParam : "";

                // Get products using service
                auto result = productService->getProducts(page, pageSize, category);

                // Convert products to JSON
                json products = json::array();
                for (const auto& product : result.products) {
                    products.push_back(product.toJson());
                }

                json responseData = {
                    {"products", products},
                    {"pagination", {
                        {"page", result.page},
                        {"pageSize", result.pageSize},
                        {"totalItems", result.totalItems},
                        {"totalPages", result.totalPages}
                    }}
                };
                
                utils::Logger::info("Products fetched: " + std::to_string(result.products.size()) + " items");
                return responseHelper->success(responseData);

            } catch (const std::exception& e) {
                utils::Logger::error("Products fetch error: " + std::string(e.what()));
                return responseHelper->serverError(e.what());
            }
        });
    }

    /**
     * GET /api/v1/products/:id
     * Get a single product by ID
     */
    void getProductByIdRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/products/<string>")
        ([this](const std::string& id) {
            utils::Logger::apiRequest("GET", "/api/v1/products/" + id);
            
            try {
                // Get product using service
                auto productOpt = productService->getProductById(id);
                
                if (!productOpt) {
                    return responseHelper->notFound("Product not found");
                }
                
                json productData = {
                    {"product", productOpt->toJson()}
                };
                
                return responseHelper->success(productData);
                
            } catch (const std::exception& e) {
                utils::Logger::error("Product fetch error: " + std::string(e.what()));
                return responseHelper->serverError(e.what());
            }
        });
    }

    /**
     * POST /api/v1/products
     * Create a new product listing
     */
    void createProductRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/products").methods("POST"_method)
        ([this](const crow::request& req) {
            utils::Logger::apiRequest("POST", "/api/v1/products");
            
            try {
                auto body = json::parse(req.body);
                
                std::string header = req.get_header_value("Authorization");
                if (header.rfind("Bearer ", 0) != 0)
                    return responseHelper->unauthorized("Authentication required");
                auto user = authService->validateToken(header.substr(7));
                if (!user) return responseHelper->unauthorized("Invalid or expired token");
                std::string role = models::User::roleToString(user->role);
                if (role != "FARMER" && role != "SELLER" && role != "ADMIN")
                    return responseHelper->forbidden("Farmer or seller account required");
                if (!body.is_object() || !body.contains("name") || !body.contains("pricePerUnit") ||
                    !body.contains("availableQuantity") || !body.contains("unit") || !body.contains("category"))
                    return responseHelper->badRequest("Missing required product fields");
                auto product = models::Product::fromJson(body);
                if (product.name.empty() || product.unit.empty() || product.pricePerUnit <= 0 || product.availableQuantity < 0)
                    return responseHelper->badRequest("Invalid product fields");
                auto productId = productService->createProduct(product, user->id);
                if (!productId) return responseHelper->serverError("Product creation failed");
                return responseHelper->created(json{{"product", {{"id", *productId}}}});

            } catch (const json::parse_error& e) {
                utils::Logger::error("JSON parse error: " + std::string(e.what()));
                return responseHelper->badRequest("Invalid JSON format");
            } catch (const std::exception& e) {
                utils::Logger::error("Product creation error: " + std::string(e.what()));
                return responseHelper->serverError(e.what());
            }
        });
    }
    void getCategoriesRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/products/categories")
        ([this]() {
            return responseHelper->success(json{{"categories", json::array({json{{"name","GRAINS"}},json{{"name","VEGETABLES"}},json{{"name","FRUITS"}},json{{"name","DAIRY"}},json{{"name","SPICES"}},json{{"name","OTHER"}}})}});
        });
    }

    void getMyProductsRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/products/my/listings")
        ([this](const crow::request& req) {
            std::string header = req.get_header_value("Authorization");
            if (header.rfind("Bearer ", 0) != 0) return responseHelper->unauthorized();
            auto user = authService->validateToken(header.substr(7));
            if (!user) return responseHelper->unauthorized();
            json products = json::array();
            for (const auto& product : productService->getSellerProducts(user->id))
                products.push_back(product.toJson());
            return responseHelper->success(json{{"products", products}});
        });
    }

};

} // namespace controllers
} // namespace agrisphere

#endif // AGRISPHERE_PRODUCTCONTROLLER_H
