#pragma once
// Add-on routes using one PostgreSQL connection per request. No shared PGconn on Crow threads.
#include <crow.h>
#include <nlohmann/json.hpp>
#include <libpq-fe.h>
#include <memory>
#include <string>
#include <vector>
#include <stdexcept>
#include <map>
#include <cstdlib>
#include <algorithm>
#include <winhttp.h>
#include "middleware/AuthMiddleware.h"
#include "utils/ResponseHelper.h"
#pragma comment(lib, "winhttp.lib")

namespace agrisphere { namespace controllers {
using json = nlohmann::json;
struct ExtraDb {
 PGconn* p;
 explicit ExtraDb(const std::string& cs) : p(PQconnectdb(cs.c_str())) {
  if (!p || PQstatus(p)!=CONNECTION_OK) { std::string e=p?PQerrorMessage(p):"connection failed"; if(p)PQfinish(p); throw std::runtime_error(e); }
 }
 ~ExtraDb(){PQfinish(p);} ExtraDb(const ExtraDb&)=delete;
 using Result=std::unique_ptr<PGresult,decltype(&PQclear)>;
 Result query(const std::string& sql,const std::vector<std::string>& ps={}) {
  std::vector<const char*> args;for(auto& s:ps)args.push_back(s.c_str());
  Result r(PQexecParams(p,sql.c_str(),static_cast<int>(args.size()),nullptr,args.empty()?nullptr:args.data(),nullptr,nullptr,0),&PQclear);
  if(!r || (PQresultStatus(r.get())!=PGRES_TUPLES_OK && PQresultStatus(r.get())!=PGRES_COMMAND_OK))throw std::runtime_error(PQerrorMessage(p));
  return r;
 }
 static std::string val(PGresult* r,int row,int col){return PQgetisnull(r,row,col)?"":PQgetvalue(r,row,col);}
};
inline json resultRows(PGresult* r) {
 json arr=json::array();for(int i=0;i<PQntuples(r);++i){json x=json::object();for(int j=0;j<PQnfields(r);++j){x[PQfname(r,j)]=ExtraDb::val(r,i,j);}arr.push_back(x);}return arr;
}
inline std::string bodyString(const json& j,const char* key,size_t limit=512){
 if(!j.contains(key)||!j[key].is_string())return "";
 std::string s=j[key].get<std::string>();if(s.size()>limit)throw std::runtime_error(std::string(key)+" too long");return s;
}
inline std::string urlEncode(const std::string& in){
 const char* hex="0123456789ABCDEF";std::string r;for(unsigned char c:in){if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.')r+=char(c);else{r+='%';r+=hex[c>>4];r+=hex[c&15];}}return r;
}
// Windows WinHTTP, TLS certificate validation enabled by default, short timeouts.
inline std::string httpsRequest(const std::wstring& host,const std::wstring& path,const std::string& post="",const std::wstring& extraHeader=L"") {
 HINTERNET session=WinHttpOpen(L"AgriSphere/1.0",WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0);
 if(!session)throw std::runtime_error("HTTP initialization failed");
 HINTERNET conn=nullptr,req=nullptr;
 try {
  WinHttpSetTimeouts(session,5000,5000,7000,12000);
  conn=WinHttpConnect(session,host.c_str(),INTERNET_DEFAULT_HTTPS_PORT,0);if(!conn)throw std::runtime_error("HTTP connection failed");
  req=WinHttpOpenRequest(conn,post.empty()?L"GET":L"POST",path.c_str(),nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,WINHTTP_FLAG_SECURE);
  if(!req)throw std::runtime_error("HTTP request failed");
  std::wstring headers=extraHeader+(post.empty()?L"":L"Content-Type: application/json\r\n");
  if(!WinHttpSendRequest(req,headers.empty()?WINHTTP_NO_ADDITIONAL_HEADERS:headers.c_str(),headers.empty()?0:static_cast<DWORD>(-1),post.empty()?WINHTTP_NO_REQUEST_DATA:const_cast<char*>(post.data()),static_cast<DWORD>(post.size()),static_cast<DWORD>(post.size()),0))throw std::runtime_error("Unable to reach external API");
  if(!WinHttpReceiveResponse(req,nullptr))throw std::runtime_error("External API did not respond");
  DWORD status=0,len=sizeof(status);WinHttpQueryHeaders(req,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,WINHTTP_HEADER_NAME_BY_INDEX,&status,&len,WINHTTP_NO_HEADER_INDEX);
  std::string response;char buf[4096];DWORD read=0;
  while(WinHttpReadData(req,buf,sizeof(buf),&read)&&read){response.append(buf,read);if(response.size()>300000)throw std::runtime_error("API response too large");}
  if(status<200||status>=300)throw std::runtime_error("External API returned HTTP "+std::to_string(status));
  WinHttpCloseHandle(req);WinHttpCloseHandle(conn);WinHttpCloseHandle(session);return response;
 }catch(...){if(req)WinHttpCloseHandle(req);if(conn)WinHttpCloseHandle(conn);WinHttpCloseHandle(session);throw;}
}
inline void registerMarketplaceExtras(crow::SimpleApp& app,const std::string& connectionString,
 std::shared_ptr<middleware::AuthMiddleware> auth,std::shared_ptr<utils::ResponseHelper> response) {
 auto who=[auth](const crow::request& req){return auth->validateToken(auth->extractToken(req));};
 auto fail=[response](const std::exception& e){return response->error("OPERATION_FAILED",e.what(),400);};
 // Product view analytics. No personally identifying browsing history is retained for anonymous users.
 CROW_ROUTE(app,"/api/v1/products/<string>/view").methods("POST"_method)
 ([connectionString,response,who,fail](const crow::request& req,std::string productId){
  try{ExtraDb d(connectionString);auto ctx=who(req);d.query("INSERT INTO product_views(product_id,viewer_id) VALUES ($1::uuid,NULLIF($2,'')::uuid)", {productId,ctx.isAuthenticated?ctx.userId:""});return response->success({{"recorded",true}});}
  catch(const std::exception& e){return fail(e);}
 });
 CROW_ROUTE(app,"/api/v1/farm/profile").methods("GET"_method)
 ([connectionString,response,who,fail](const crow::request& req){auto ctx=who(req);if(!ctx.isAuthenticated)return response->unauthorized();try{ExtraDb d(connectionString);auto r=d.query("SELECT land_acres,soil_type,irrigation,current_crops,COALESCE(sowing_date::text,'') AS sowing_date,farm_location FROM farm_profiles WHERE user_id=$1::uuid",{ctx.userId});return response->success({{"profile",PQntuples(r.get())?resultRows(r.get())[0]:json::object()}});}catch(const std::exception& e){return fail(e);}});
 CROW_ROUTE(app,"/api/v1/farm/profile").methods("PUT"_method)
 ([connectionString,response,who,fail](const crow::request& req){auto ctx=who(req);if(!ctx.isAuthenticated)return response->unauthorized();try{auto j=json::parse(req.body);ExtraDb d(connectionString);std::string land=j.contains("landAcres")&&!j["landAcres"].is_null()?std::to_string(j["landAcres"].get<double>()):"";if(!land.empty()&&std::stod(land)<0)return response->badRequest("Land area must be positive");d.query("INSERT INTO farm_profiles(user_id,land_acres,soil_type,irrigation,current_crops,sowing_date,farm_location) VALUES ($1::uuid,NULLIF($2,'')::numeric,$3,$4,$5,NULLIF($6,'')::date,$7) ON CONFLICT (user_id) DO UPDATE SET land_acres=EXCLUDED.land_acres,soil_type=EXCLUDED.soil_type,irrigation=EXCLUDED.irrigation,current_crops=EXCLUDED.current_crops,sowing_date=EXCLUDED.sowing_date,farm_location=EXCLUDED.farm_location,updated_at=now()",{ctx.userId,land,bodyString(j,"soilType"),bodyString(j,"irrigation"),bodyString(j,"currentCrops"),bodyString(j,"sowingDate",20),bodyString(j,"farmLocation")});return response->success({{"saved",true}});}catch(const std::exception&e){return fail(e);}});
 CROW_ROUTE(app,"/api/v1/services/requests").methods("POST"_method)
 ([connectionString,response,who,fail](const crow::request& req){auto ctx=who(req);if(!ctx.isAuthenticated)return response->unauthorized();try{auto j=json::parse(req.body);auto service=bodyString(j,"serviceName"),name=bodyString(j,"name"),phone=bodyString(j,"phone"),location=bodyString(j,"location");if(service.empty()||name.empty()||phone.empty()||location.empty())return response->badRequest("Service, name, phone and location required");ExtraDb d(connectionString);auto r=d.query("INSERT INTO service_requests(requester_id,service_name,contact_name,phone,email,location,preferred_date,notes) VALUES($1::uuid,$2,$3,$4,$5,$6,NULLIF($7,'')::date,$8) RETURNING id::text",{ctx.userId,service,name,phone,bodyString(j,"email"),location,bodyString(j,"date",20),bodyString(j,"message",2000)});return response->created({{"id",ExtraDb::val(r.get(),0,0)},{"status","REQUESTED"}});}catch(const std::exception&e){return fail(e);}});
 CROW_ROUTE(app,"/api/v1/services/requests").methods("GET"_method)
 ([connectionString,response,who,fail](const crow::request& req){auto ctx=who(req);if(!ctx.isAuthenticated)return response->unauthorized();try{ExtraDb d(connectionString);auto r=d.query("SELECT id::text, service_name AS \"serviceName\",contact_name AS name,phone,email,location,COALESCE(preferred_date::text,'') AS date,notes AS message,status,created_at::text AS \"createdAt\" FROM service_requests WHERE requester_id=$1::uuid OR provider_id=$1::uuid ORDER BY created_at DESC LIMIT 100",{ctx.userId});return response->success({{"requests",resultRows(r.get())}});}catch(const std::exception&e){return fail(e);}});
 CROW_ROUTE(app,"/api/v1/services/opportunities")
 ([connectionString,response,who,fail](const crow::request& req){auto ctx=who(req);if(!ctx.isAuthenticated||ctx.role!=models::UserRole::SERVICE_PROVIDER)return response->forbidden();try{ExtraDb d(connectionString);auto r=d.query("SELECT id::text,service_name AS \"serviceName\",location,COALESCE(preferred_date::text,'') AS date,created_at::text AS \"createdAt\" FROM service_requests WHERE provider_id IS NULL AND status='REQUESTED' ORDER BY created_at DESC LIMIT 50");return response->success({{"opportunities",resultRows(r.get())}});}catch(const std::exception&e){return fail(e);}});
 CROW_ROUTE(app,"/api/v1/services/requests/<string>/accept").methods("POST"_method)
 ([connectionString,response,who,fail](const crow::request& req,std::string id){auto ctx=who(req);if(!ctx.isAuthenticated||ctx.role!=models::UserRole::SERVICE_PROVIDER)return response->forbidden();try{ExtraDb d(connectionString);auto r=d.query("UPDATE service_requests SET provider_id=$1::uuid,status='ACCEPTED' WHERE id=$2::uuid AND provider_id IS NULL AND status='REQUESTED' RETURNING id::text",{ctx.userId,id});if(!PQntuples(r.get()))return response->notFound("Opportunity unavailable");return response->success({{"accepted",true}});}catch(const std::exception&e){return fail(e);}});
 // Seller dashboard aggregates and sales are based only on existing orders and real recorded view events.
 CROW_ROUTE(app,"/api/v1/dashboard/metrics")
 ([connectionString,response,who,fail](const crow::request& req){auto ctx=who(req);if(!ctx.isAuthenticated)return response->unauthorized();try{ExtraDb d(connectionString);
 auto r=d.query("SELECT COALESCE((SELECT COUNT(*) FROM products WHERE seller_id=$1::uuid),0)::text AS products,COALESCE((SELECT COUNT(*) FROM product_views v JOIN products p ON p.id=v.product_id WHERE p.seller_id=$1::uuid),0)::text AS views,COALESCE((SELECT COUNT(*) FROM orders WHERE seller_id=$1::uuid AND payment_status='PAID'),0)::text AS sales,COALESCE((SELECT SUM(total_amount) FROM orders WHERE seller_id=$1::uuid AND payment_status='PAID'),0)::text AS revenue,COALESCE((SELECT COUNT(*) FROM orders WHERE buyer_id=$1::uuid),0)::text AS purchases",{ctx.userId});
 json metrics={{"products",std::stoll(ExtraDb::val(r.get(),0,0))},{"views",std::stoll(ExtraDb::val(r.get(),0,1))},{"sales",std::stoll(ExtraDb::val(r.get(),0,2))},{"revenue",std::stoll(ExtraDb::val(r.get(),0,3))},{"purchases",std::stoll(ExtraDb::val(r.get(),0,4))}};
 auto chart=d.query("SELECT to_char(days.day,'DD Mon') AS day, COALESCE(v.views,0)::text AS views, COALESCE(o.sales,0)::text AS sales FROM generate_series(current_date-6,current_date,interval '1 day') days(day) LEFT JOIN (SELECT date(v.viewed_at) AS d,count(*) AS views FROM product_views v JOIN products p ON p.id=v.product_id WHERE p.seller_id=$1::uuid GROUP BY date(v.viewed_at)) v ON v.d=days.day::date LEFT JOIN (SELECT date(created_at) d,count(*) sales FROM orders WHERE seller_id=$1::uuid AND payment_status='PAID' GROUP BY date(created_at)) o ON o.d=days.day::date ORDER BY days.day",{ctx.userId});return response->success({{"metrics",metrics},{"chart",resultRows(chart.get())}});
 }catch(const std::exception&e){return fail(e);}});
 // MOCK checkout: atomic inventory decrement and creation of PAID demo orders, no external charge.
 CROW_ROUTE(app,"/api/v1/orders/checkout").methods("POST"_method)
 ([connectionString,response,who,fail](const crow::request& req){auto ctx=who(req);if(!ctx.isAuthenticated)return response->unauthorized();try{
 auto j=json::parse(req.body);auto address=bodyString(j,"shippingAddress",1000);if(address.empty())return response->badRequest("Shipping address is required");ExtraDb d(connectionString);d.query("BEGIN");
 try {
 auto items=d.query("SELECT p.id::text,p.seller_id::text,p.name,p.price_per_unit::text,p.unit,ci.quantity::text,p.available_quantity::text FROM cart_items ci JOIN carts c ON c.id=ci.cart_id JOIN products p ON p.id=ci.product_id WHERE c.user_id=$1::uuid ORDER BY p.id FOR UPDATE OF p",{ctx.userId});
 if(PQntuples(items.get())==0){d.query("ROLLBACK");return response->badRequest("Cart is empty");}
 struct Line{std::string id,seller,name,unit;long long price;int qty;};std::map<std::string,std::vector<Line>> groups;std::map<std::string,long long> totals;
 for(int i=0;i<PQntuples(items.get());++i){Line x{ExtraDb::val(items.get(),i,0),ExtraDb::val(items.get(),i,1),ExtraDb::val(items.get(),i,2),ExtraDb::val(items.get(),i,4),std::stoll(ExtraDb::val(items.get(),i,3)),std::stoi(ExtraDb::val(items.get(),i,5))};int stock=std::stoi(ExtraDb::val(items.get(),i,6));if(x.qty<=0||x.qty>stock)throw std::runtime_error("Insufficient inventory for "+x.name);if(x.seller==ctx.userId)throw std::runtime_error("Cannot purchase your own products");groups[x.seller].push_back(x);totals[x.seller]+=x.price*x.qty;}
 json orders=json::array();for(const auto& g:groups){auto o=d.query("INSERT INTO orders(buyer_id,seller_id,status,total_amount,payment_status,payment_method,shipping_address,confirmed_at) VALUES($1::uuid,$2::uuid,'CONFIRMED',$3::bigint,'PAID','MOCK', $4,now()) RETURNING id::text,created_at::text",{ctx.userId,g.first,std::to_string(totals[g.first]),address});std::string oid=ExtraDb::val(o.get(),0,0);
 for(const auto& x:g.second){d.query("INSERT INTO order_items(order_id,product_id,product_name,price_per_unit,unit,quantity,subtotal) VALUES($1::uuid,$2::uuid,$3,$4::bigint,$5,$6::int,$7::bigint)",{oid,x.id,x.name,std::to_string(x.price),x.unit,std::to_string(x.qty),std::to_string(x.price*x.qty)});d.query("UPDATE products SET available_quantity=available_quantity-$2::int,updated_at=now() WHERE id=$1::uuid",{x.id,std::to_string(x.qty)});}
 orders.push_back({{"id",oid},{"total",totals[g.first]},{"status","CONFIRMED"}});
 }
 d.query("DELETE FROM cart_items WHERE cart_id IN(SELECT id FROM carts WHERE user_id=$1::uuid)",{ctx.userId});d.query("COMMIT");return response->created({{"orders",orders},{"payment",{{"method","MOCK"},{"status","SIMULATED"},{"charged",false}}}});
 }catch(...){try{d.query("ROLLBACK");}catch(...){}throw;}
 }catch(const std::exception&e){return fail(e);}});
 CROW_ROUTE(app,"/api/v1/orders")
 ([connectionString,response,who,fail](const crow::request& req){auto ctx=who(req);if(!ctx.isAuthenticated)return response->unauthorized();try{ExtraDb d(connectionString);auto r=d.query("SELECT id::text, status,payment_status AS \"paymentStatus\",payment_method AS \"paymentMethod\",total_amount::text AS total,created_at::text AS \"createdAt\",shipping_address AS \"shippingAddress\",buyer_id::text AS \"buyerId\",seller_id::text AS \"sellerId\" FROM orders WHERE buyer_id=$1::uuid OR seller_id=$1::uuid ORDER BY created_at DESC LIMIT 100",{ctx.userId});json orders=resultRows(r.get());for(auto& o:orders){o["orderNumber"]=o["id"].get<std::string>().substr(0,8);auto i=d.query("SELECT id::text,product_name AS \"productName\",price_per_unit::text AS price,quantity::text FROM order_items WHERE order_id=$1::uuid",{o["id"].get<std::string>()});o["items"]=resultRows(i.get());}return response->success({{"orders",orders}});}catch(const std::exception&e){return fail(e);}});
 CROW_ROUTE(app,"/api/v1/orders/<string>/journey")
 ([connectionString,response,who,fail](const crow::request& req,std::string id){auto ctx=who(req);if(!ctx.isAuthenticated)return response->unauthorized();try{ExtraDb d(connectionString);
 auto r=d.query("SELECT o.id::text,o.status,o.payment_status,o.created_at::text,COALESCE(o.confirmed_at::text,''),COALESCE(o.shipped_at::text,''),COALESCE(o.delivered_at::text,''),COALESCE(f.current_crops,''),COALESCE(f.sowing_date::text,''),COALESCE(f.farm_location,''),COALESCE(string_agg(oi.product_name,', '),'') FROM orders o LEFT JOIN farm_profiles f ON f.user_id=o.seller_id LEFT JOIN order_items oi ON oi.order_id=o.id WHERE o.id=$1::uuid AND (o.buyer_id=$2::uuid OR o.seller_id=$2::uuid) GROUP BY o.id,f.current_crops,f.sowing_date,f.farm_location",{id,ctx.userId});
 if(!PQntuples(r.get()))return response->notFound("Order not found or not yours");
 auto get=[&](int i){return ExtraDb::val(r.get(),0,i);};
 return response->success({{"orderId",get(0)},{"status",get(1)},{"paymentStatus",get(2)},{"orderedAt",get(3)},{"confirmedAt",get(4)},{"shippedAt",get(5)},{"deliveredAt",get(6)},{"farmCrops",get(7)},{"sowingDate",get(8)},{"farmLocation",get(9)},{"products",get(10)},{"message","Only recorded events are displayed; unknown stages have no actual tracking date."}});
 }catch(const std::exception&e){return fail(e);}});

}
}}
