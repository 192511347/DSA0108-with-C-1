/**
 * CartController.h
 * Handles shopping cart routes (view cart, add/update/remove items)
 */

#ifndef AGRISPHERE_CARTCONTROLLER_H
#define AGRISPHERE_CARTCONTROLLER_H

#include <crow.h>
#include <nlohmann/json.hpp>
#include <memory>
#include <string>

#include "services/CartService.h"
#include "middleware/AuthMiddleware.h"
#include "utils/ResponseHelper.h"
#include "utils/Logger.h"

namespace agrisphere {
namespace controllers {

using json = nlohmann::json;

/**
 * Cart controller
 * Registers cart routes with Crow application
 */
class CartController {
private:
    std::shared_ptr<services::CartService> cartService;
    std::shared_ptr<middleware::AuthMiddleware> authMiddleware;
    std::shared_ptr<utils::ResponseHelper> responseHelper;

public:
    /**
     * Constructor
     * @param cartService Cart service
     * @param authMiddleware Authentication middleware
     * @param responseHelper Response helper utility
     */
    CartController(
        std::shared_ptr<services::CartService> cartService,
        std::shared_ptr<middleware::AuthMiddleware> authMiddleware,
        std::shared_ptr<utils::ResponseHelper> responseHelper
    ) : cartService(cartService), authMiddleware(authMiddleware), responseHelper(responseHelper) {}

    /**
     * Register all cart routes with Crow app
     * @param app Crow application instance
     */
    void registerRoutes(crow::SimpleApp& app) {
        getCartRoute(app);
        addCartItemRoute(app);
        updateCartItemRoute(app);
        removeCartItemRoute(app);
        clearCartRoute(app);
    }

private:
    /**
     * GET /api/v1/cart
     * Get current user's shopping cart (requires authentication)
     */
    void getCartRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/cart")
        ([this](const crow::request& req) {
            utils::Logger::apiRequest("GET", "/api/v1/cart");
            
            // Extract and validate JWT
            std::string token = authMiddleware->extractToken(req);
            auto authContext = authMiddleware->validateToken(token);
            
            if (!authContext.isAuthenticated) {
                return responseHelper->unauthorized("Authentication required");
            }
            
            // Get user's cart
            auto result = cartService->getUserCart(authContext.userId);
            
            if (!result.success) {
                return responseHelper->serverError(result.errorMessage);
            }
            
            json cartData = {
                {"cart", result.cart->toJson()}
            };
            
            return responseHelper->success(cartData);
        });
    }

    /**
     * POST /api/v1/cart/items
     * Add an item to the shopping cart (requires authentication)
     */
    void addCartItemRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/cart/items").methods("POST"_method)
        ([this](const crow::request& req) {
            utils::Logger::apiRequest("POST", "/api/v1/cart/items");
            
            try {
                // Authenticate user
                std::string token = authMiddleware->extractToken(req);
                auto authContext = authMiddleware->validateToken(token);
                
                if (!authContext.isAuthenticated) {
                    return responseHelper->unauthorized("Authentication required");
                }
                
                auto body = json::parse(req.body);
                
                // Validate input
                if (!body.contains("productId") || !body.contains("quantity")) {
                    return responseHelper->badRequest("Missing productId or quantity");
                }
                
                std::string productId = body["productId"];
                int quantity = body["quantity"];
                
                // Add item to cart
                auto result = cartService->addItem(authContext.userId, productId, quantity);
                
                if (!result.success) {
                    if (result.errorCode == "PRODUCT_NOT_FOUND") {
                        return responseHelper->notFound(result.errorMessage);
                    } else if (result.errorCode == "INSUFFICIENT_STOCK" || 
                               result.errorCode == "INVALID_QUANTITY" ||
                               result.errorCode == "PRODUCT_UNAVAILABLE") {
                        return responseHelper->badRequest(result.errorMessage);
                    }
                    return responseHelper->serverError(result.errorMessage);
                }
                
                json cartData = {
                    {"cart", result.cart->toJson()}
                };
                
                return responseHelper->success(cartData);
                
            } catch (const json::parse_error& e) {
                utils::Logger::error("JSON parse error: " + std::string(e.what()));
                return responseHelper->badRequest("Invalid JSON format");
            } catch (const std::exception& e) {
                utils::Logger::error("Cart item add error: " + std::string(e.what()));
                return responseHelper->serverError(e.what());
            }
        });
    }
    // Verify ownership via authenticated user's cart, never accept arbitrary item IDs.
    bool ownsItem(const std::string& userId, const std::string& itemId,
                  models::CartItem* found = nullptr) {
        auto result = cartService->getUserCart(userId);
        if (!result.success || !result.cart) return false;
        for (const auto& item : result.cart->items) {
            if (item.id == itemId) {
                if (found) *found = item;
                return true;
            }
        }
        return false;
    }

    void updateCartItemRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/cart/items/<string>").methods("PUT"_method)
        ([this](const crow::request& req, std::string itemId) {
            auto context = authMiddleware->validateToken(authMiddleware->extractToken(req));
            if (!context.isAuthenticated) return responseHelper->unauthorized();
            models::CartItem item;
            if (!ownsItem(context.userId, itemId, &item)) return responseHelper->notFound("Cart item not found");
            try {
                auto body = json::parse(req.body);
                if (!body.contains("quantity") || !body["quantity"].is_number_integer())
                    return responseHelper->badRequest("Quantity must be an integer");
                int qty = body["quantity"].get<int>();
                if (qty <= 0 || qty > item.availableQuantity)
                    return responseHelper->badRequest("Quantity exceeds stock or is invalid");
                auto result = cartService->updateItemQuantity(context.userId, itemId, qty);
                if (!result.success) return responseHelper->badRequest(result.errorMessage);
                return responseHelper->success(json{{"cart", result.cart->toJson()}});
            } catch (const std::exception&) { return responseHelper->badRequest("Invalid request"); }
        });
    }

    void removeCartItemRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/cart/items/<string>").methods("DELETE"_method)
        ([this](const crow::request& req, std::string itemId) {
            auto context = authMiddleware->validateToken(authMiddleware->extractToken(req));
            if (!context.isAuthenticated) return responseHelper->unauthorized();
            if (!ownsItem(context.userId, itemId)) return responseHelper->notFound("Cart item not found");
            auto result = cartService->removeItem(context.userId, itemId);
            if (!result.success) return responseHelper->badRequest(result.errorMessage);
            return responseHelper->success(json{{"cart", result.cart->toJson()}});
        });
    }

    void clearCartRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/cart").methods("DELETE"_method)
        ([this](const crow::request& req) {
            auto context = authMiddleware->validateToken(authMiddleware->extractToken(req));
            if (!context.isAuthenticated) return responseHelper->unauthorized();
            auto result = cartService->clearCart(context.userId);
            if (!result.success) return responseHelper->badRequest(result.errorMessage);
            return responseHelper->success(json{{"cart", result.cart->toJson()}});
        });
    }

};

} // namespace controllers
} // namespace agrisphere

#endif // AGRISPHERE_CARTCONTROLLER_H
