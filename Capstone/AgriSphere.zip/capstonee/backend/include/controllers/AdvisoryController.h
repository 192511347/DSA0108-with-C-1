#pragma once
#include <crow.h>
#include <nlohmann/json.hpp>
#include <memory>
#include <string>
#include <algorithm>
#include "advisory/AdvisoryService.h"
#include "middleware/AuthMiddleware.h"
#include "utils/ResponseHelper.h"
namespace agrisphere { namespace controllers {
inline void registerAdvisoryRoutes(crow::SimpleApp& app, const std::string& connectionString,
        std::shared_ptr<middleware::AuthMiddleware> auth,
        std::shared_ptr<utils::ResponseHelper> response) {
    using json=nlohmann::json;
    CROW_ROUTE(app,"/api/v1/advisory").methods("POST"_method)
    ([connectionString,auth,response](const crow::request& request) {
        auto user=auth->validateToken(auth->extractToken(request));
        if(!user.isAuthenticated)return response->unauthorized();
        try {
            json body=json::parse(request.body);
            if(!body.is_object() || !body.contains("question") || !body["question"].is_string())return response->badRequest("Enter an advisory question");
            std::string question=body["question"].get<std::string>();
            if(question.empty()||question.size()>1200)return response->badRequest("Question length must be 1-1200 characters");
            std::string location="",language="en";
            if(body.contains("location")){
                if(!body["location"].is_string())return response->badRequest("Invalid location");
                location=body["location"].get<std::string>();
            }
            if(location.size()>100)return response->badRequest("Location too long");
            if(body.contains("language")){
                if(!body["language"].is_string())return response->badRequest("Invalid language");
                language=body["language"].get<std::string>();
            }
            if(language!="en"&&language!="ta"&&language!="hi")return response->badRequest("Supported languages are en, ta, hi");
            const std::string role=user.role==models::UserRole::FARMER?"FARMER":
                user.role==models::UserRole::SERVICE_PROVIDER?"SERVICE_PROVIDER":"BUYER";
            advisory::AdvisoryService service;
            return response->success(service.ask(connectionString,user.userId,role,{question,location,language}));
        }catch(const json::exception&) {return response->badRequest("Invalid request or AI response format");}
        catch(const std::exception& e) {return response->error("ADVISORY_UNAVAILABLE",e.what(),503);}
    });
    CROW_ROUTE(app,"/api/v1/advisory/history").methods("GET"_method)
    ([connectionString,auth,response](const crow::request& request) {
        auto user=auth->validateToken(auth->extractToken(request));
        if(!user.isAuthenticated)return response->unauthorized();
        try {
            advisory::AdvisoryRepository repo(connectionString);
            return response->success({{"history",repo.history(user.userId)}});
        }catch(const std::exception&){return response->error("HISTORY_UNAVAILABLE","Could not load advisory history",503);}
    });
}
}}
