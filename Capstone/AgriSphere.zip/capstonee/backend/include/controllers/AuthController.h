/**
 * AuthController.h
 * Handles authentication routes (register, login)
 */

#ifndef AGRISPHERE_AUTHCONTROLLER_H
#define AGRISPHERE_AUTHCONTROLLER_H

#include <crow.h>
#include <nlohmann/json.hpp>
#include <memory>
#include <string>

#include "services/AuthService.h"
#include "utils/ResponseHelper.h"
#include "utils/Logger.h"

namespace agrisphere {
namespace controllers {

using json = nlohmann::json;

/**
 * Authentication controller
 * Registers auth routes with Crow application
 */
class AuthController {
private:
    std::shared_ptr<services::AuthService> authService;
    std::shared_ptr<utils::ResponseHelper> responseHelper;

public:
    /**
     * Constructor
     * @param authService Authentication service
     * @param responseHelper Response helper utility
     */
    AuthController(
        std::shared_ptr<services::AuthService> authService,
        std::shared_ptr<utils::ResponseHelper> responseHelper
    ) : authService(authService), responseHelper(responseHelper) {}

    /**
     * Register all auth routes with Crow app
     * @param app Crow application instance
     */
    void registerRoutes(crow::SimpleApp& app) {
        registerUserRoute(app);
        loginRoute(app);
        meRoute(app);
        refreshRoute(app);
    }

private:
    /**
     * POST /api/v1/auth/register
     * Register a new user account
     */
    void registerUserRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/auth/register").methods("POST"_method)
        ([this](const crow::request& req) {
            utils::Logger::apiRequest("POST", "/api/v1/auth/register");
            
            try {
                auto body = json::parse(req.body);
                
                // Validate required fields
                if (!body.contains("email") || !body.contains("password") || 
                    !body.contains("fullName") || !body.contains("phone") || 
                    !body.contains("role")) {
                    utils::Logger::warning("Registration failed: Missing required fields");
                    return responseHelper->badRequest("Missing required fields: email, password, fullName, phone, role");
                }

                std::string email = body["email"];
                std::string password = body["password"];
                std::string fullName = body["fullName"];
                std::string phone = body["phone"];
                std::string role = body["role"];
                std::string district = body.value("district", "");
                std::string state = body.value("state", "");

                // Register user using AuthService
                auto result = authService->registerUser(email, password, fullName, phone, role, district, state);

                if (!result.success) {
                    if (result.errorCode == "WEAK_PASSWORD" || result.errorCode == "EMAIL_EXISTS") {
                        return responseHelper->badRequest(result.errorMessage);
                    }
                    return responseHelper->serverError(result.errorMessage);
                }

                // Build response
                json userData = {
                    {"user", result.user->toJson()},
                    {"tokens", {
                        {"accessToken", result.accessToken},
                        {"refreshToken", result.refreshToken}
                    }}
                };
                
                utils::Logger::info("User registered: " + email);
                return responseHelper->created(userData);
                
            } catch (const json::parse_error& e) {
                utils::Logger::error("JSON parse error: " + std::string(e.what()));
                return responseHelper->badRequest("Invalid JSON format");
            } catch (const std::exception& e) {
                utils::Logger::error("Registration error: " + std::string(e.what()));
                return responseHelper->serverError(e.what());
            }
        });
    }

    /**
     * POST /api/v1/auth/login
     * Authenticate user and return JWT tokens
     */
    void loginRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/auth/login").methods("POST"_method)
        ([this](const crow::request& req) {
            utils::Logger::apiRequest("POST", "/api/v1/auth/login");
            
            try {
                auto body = json::parse(req.body);
                
                if (!body.contains("email") || !body.contains("password")) {
                    utils::Logger::warning("Login failed: Missing credentials");
                    return responseHelper->badRequest("Email and password required");
                }

                std::string email = body["email"];
                std::string password = body["password"];

                // Authenticate using AuthService
                auto result = authService->login(email, password);

                if (!result.success) {
                    if (result.errorCode == "INVALID_CREDENTIALS" || result.errorCode == "ACCOUNT_INACTIVE") {
                        return responseHelper->unauthorized(result.errorMessage);
                    }
                    return responseHelper->serverError(result.errorMessage);
                }

                // Build response
                json userData = {
                    {"user", result.user->toJson()},
                    {"tokens", {
                        {"accessToken", result.accessToken},
                        {"refreshToken", result.refreshToken}
                    }}
                };
                
                utils::Logger::info("User logged in: " + email);
                return responseHelper->success(userData);
                
            } catch (const json::parse_error& e) {
                utils::Logger::error("JSON parse error: " + std::string(e.what()));
                return responseHelper->badRequest("Invalid JSON format");
            } catch (const std::exception& e) {
                utils::Logger::error("Login error: " + std::string(e.what()));
                return responseHelper->serverError(e.what());
            }
        });
    }
    void meRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/auth/me")
        ([this](const crow::request& req) {
            std::string header = req.get_header_value("Authorization");
            if (header.rfind("Bearer ", 0) != 0)
                return responseHelper->unauthorized("Bearer token required");
            auto user = authService->validateToken(header.substr(7));
            if (!user) return responseHelper->unauthorized("Invalid or expired token");
            return responseHelper->success(user->toJson());
        });
    }

    void refreshRoute(crow::SimpleApp& app) {
        CROW_ROUTE(app, "/api/v1/auth/refresh").methods("POST"_method)
        ([this](const crow::request& req) {
            try {
                auto body = json::parse(req.body);
                if (!body.contains("refreshToken") || !body["refreshToken"].is_string())
                    return responseHelper->badRequest("refreshToken required");
                auto result = authService->refreshAccessToken(body["refreshToken"]);
                if (!result.success) return responseHelper->unauthorized(result.errorMessage);
                return responseHelper->success(json{
                    {"accessToken", result.accessToken},
                    {"tokens", {{"accessToken", result.accessToken}, {"refreshToken", result.refreshToken}}}
                });
            } catch (const std::exception&) {
                return responseHelper->badRequest("Invalid refresh request");
            }
        });
    }

};

} // namespace controllers
} // namespace agrisphere

#endif // AGRISPHERE_AUTHCONTROLLER_H
