/**
 * Password Hashing Utility
 * Uses bcrypt-style hashing with OpenSSL
 */

#pragma once

#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <string>
#include <sstream>
#include <iomanip>
#include <cstring>

namespace agrisphere {
namespace utils {

class PasswordUtil {
private:
    static const int SALT_LENGTH = 16;
    static const int ITERATIONS = 10000;
    static const int KEY_LENGTH = 32;

    // Convert bytes to hex string
    static std::string toHex(const unsigned char* data, size_t length) {
        std::ostringstream oss;
        for (size_t i = 0; i < length; i++) {
            oss << std::hex << std::setw(2) << std::setfill('0') << (int)data[i];
        }
        return oss.str();
    }

    // Convert hex string to bytes
    static std::vector<unsigned char> fromHex(const std::string& hex) {
        std::vector<unsigned char> bytes;
        for (size_t i = 0; i < hex.length(); i += 2) {
            std::string byteString = hex.substr(i, 2);
            unsigned char byte = (unsigned char)strtol(byteString.c_str(), nullptr, 16);
            bytes.push_back(byte);
        }
        return bytes;
    }

public:
    /**
     * Hash a password using PBKDF2-SHA256
     * Returns: salt$iterations$hash (hex encoded)
     */
    static std::string hashPassword(const std::string& password) {
        // Generate random salt
        unsigned char salt[SALT_LENGTH];
        if (RAND_bytes(salt, SALT_LENGTH) != 1) {
            throw std::runtime_error("Failed to generate random salt");
        }

        // Derive key using PBKDF2
        unsigned char key[KEY_LENGTH];
        if (PKCS5_PBKDF2_HMAC(
            password.c_str(), password.length(),
            salt, SALT_LENGTH,
            ITERATIONS,
            EVP_sha256(),
            KEY_LENGTH, key) != 1) {
            throw std::runtime_error("Failed to hash password");
        }

        // Format: salt$iterations$hash
        std::string saltHex = toHex(salt, SALT_LENGTH);
        std::string keyHex = toHex(key, KEY_LENGTH);
        
        return saltHex + "$" + std::to_string(ITERATIONS) + "$" + keyHex;
    }

    /**
     * Verify a password against a hash
     * hash format: salt$iterations$hash
     */
    static bool verifyPassword(const std::string& password, const std::string& hash) {
        try {
            // Parse hash components
            size_t firstDollar = hash.find('$');
            size_t secondDollar = hash.find('$', firstDollar + 1);
            
            if (firstDollar == std::string::npos || secondDollar == std::string::npos) {
                return false;
            }

            std::string saltHex = hash.substr(0, firstDollar);
            std::string iterStr = hash.substr(firstDollar + 1, secondDollar - firstDollar - 1);
            std::string keyHex = hash.substr(secondDollar + 1);

            int iterations = std::stoi(iterStr);
            std::vector<unsigned char> salt = fromHex(saltHex);
            std::vector<unsigned char> expectedKey = fromHex(keyHex);

            // Derive key with same parameters
            unsigned char derivedKey[KEY_LENGTH];
            if (PKCS5_PBKDF2_HMAC(
                password.c_str(), password.length(),
                salt.data(), salt.size(),
                iterations,
                EVP_sha256(),
                KEY_LENGTH, derivedKey) != 1) {
                return false;
            }

            // Compare keys (constant time comparison)
            return (CRYPTO_memcmp(derivedKey, expectedKey.data(), KEY_LENGTH) == 0);

        } catch (...) {
            return false;
        }
    }

    /**
     * Validate password strength
     * Returns error message or empty string if valid
     */
    static std::string validatePasswordStrength(const std::string& password) {
        if (password.length() < 8) {
            return "Password must be at least 8 characters long";
        }

        bool hasUpper = false;
        bool hasLower = false;
        bool hasDigit = false;

        for (char c : password) {
            if (isupper(c)) hasUpper = true;
            if (islower(c)) hasLower = true;
            if (isdigit(c)) hasDigit = true;
        }

        if (!hasUpper || !hasLower || !hasDigit) {
            return "Password must contain uppercase, lowercase, and digits";
        }

        return ""; // Valid
    }
};

} // namespace utils
} // namespace agrisphere
