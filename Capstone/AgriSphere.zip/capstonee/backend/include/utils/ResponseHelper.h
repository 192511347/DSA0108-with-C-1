/**
 * HTTP Response Helper
 * Standardizes JSON responses with CORS
 */

#pragma once

#include <crow.h>
#include <nlohmann/json.hpp>
#include <string>

using json = nlohmann::json;

namespace agrisphere {
namespace utils {

class ResponseHelper {
private:
    std::string corsOrigin;

public:
    ResponseHelper(const std::string& origin) : corsOrigin(origin) {}

    crow::response createResponse(int statusCode, const json& data) const {
        crow::response res(statusCode);
        res.add_header("Content-Type", "application/json");
        res.add_header("Access-Control-Allow-Origin", corsOrigin);
        res.add_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        res.add_header("Access-Control-Allow-Headers", "Content-Type, Authorization");
        res.write(data.dump());
        return res;
    }

    // Success responses
    crow::response success(const json& data, int statusCode = 200) const {
        json response = {
            {"success", true},
            {"data", data}
        };
        return createResponse(statusCode, response);
    }

    crow::response created(const json& data) const {
        return success(data, 201);
    }

    // Error responses
    crow::response error(const std::string& code, const std::string& message, int statusCode = 400) const {
        json response = {
            {"success", false},
            {"error", {
                {"code", code},
                {"message", message}
            }}
        };
        return createResponse(statusCode, response);
    }

    crow::response badRequest(const std::string& message) const {
        return error("INVALID_REQUEST", message, 400);
    }

    crow::response unauthorized(const std::string& message = "Unauthorized") const {
        return error("UNAUTHORIZED", message, 401);
    }

    crow::response forbidden(const std::string& message = "Forbidden") const {
        return error("FORBIDDEN", message, 403);
    }

    crow::response notFound(const std::string& message = "Resource not found") const {
        return error("NOT_FOUND", message, 404);
    }

    crow::response serverError(const std::string& message = "Internal server error") const {
        return error("SERVER_ERROR", message, 500);
    }

    crow::response validationError(const std::string& message, const json& fields = json::object()) const {
        json response = {
            {"success", false},
            {"error", {
                {"code", "VALIDATION_ERROR"},
                {"message", message},
                {"fields", fields}
            }}
        };
        return createResponse(400, response);
    }
};

} // namespace utils
} // namespace agrisphere
