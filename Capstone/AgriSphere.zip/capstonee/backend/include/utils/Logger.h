/**
 * Simple Logger Utility
 * Provides structured logging with levels
 */

#pragma once

#include <iostream>
#include <string>
#include <ctime>
#include <iomanip>
#include <sstream>

namespace agrisphere {
namespace utils {

// Log levels
enum LogLevel {
    LOG_DEBUG = 0,
    LOG_INFO = 1,
    LOG_WARNING = 2,
    LOG_ERROR = 3
};

class Logger {
private:
    static LogLevel minLevel;

    static std::string getCurrentTimestamp() {
        auto now = std::time(nullptr);
        auto tm = *std::localtime(&now);
        std::ostringstream oss;
        oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
        return oss.str();
    }

    static std::string levelToString(LogLevel level) {
        switch (level) {
            case LOG_DEBUG:   return "DEBUG";
            case LOG_INFO:    return "INFO";
            case LOG_WARNING: return "WARNING";
            case LOG_ERROR:   return "ERROR";
            default: return "UNKNOWN";
        }
    }

    static void log(LogLevel level, const std::string& message) {
        if (level < minLevel) return;

        std::cout << "[" << getCurrentTimestamp() << "] "
                  << "[" << levelToString(level) << "] "
                  << message << std::endl;
    }

public:
    static void setMinLevel(LogLevel level) {
        minLevel = level;
    }

    static void debug(const std::string& message) {
        log(LOG_DEBUG, message);
    }

    static void info(const std::string& message) {
        log(LOG_INFO, message);
    }

    static void warning(const std::string& message) {
        log(LOG_WARNING, message);
    }

    static void error(const std::string& message) {
        log(LOG_ERROR, message);
    }

    // Convenience methods with context
    static void apiRequest(const std::string& method, const std::string& path) {
        info("API Request: " + method + " " + path);
    }

    static void apiResponse(const std::string& path, int statusCode) {
        info("API Response: " + path + " -> " + std::to_string(statusCode));
    }

    static void dbQuery(const std::string& query) {
        debug("DB Query: " + query);
    }

    static void dbError(const std::string& error) {
        Logger::error("DB Error: " + error);
    }
};

} // namespace utils
} // namespace agrisphere
