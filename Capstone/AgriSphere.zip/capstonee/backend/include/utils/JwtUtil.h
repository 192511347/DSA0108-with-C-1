/**
 * JWT Token Utility
 * Simplified implementation - generates simple signed tokens
 * TODO: Replace with full jwt-cpp implementation once API compatibility resolved
 */

#pragma once

#include <openssl/hmac.h>
#include <string>
#include <chrono>
#include <sstream>
#include <iomanip>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

namespace agrisphere {
namespace utils {

class JwtUtil {
private:
    std::string secret;
    int expirationMinutes;

    // Base64 URL encode
    static std::string base64UrlEncode(const std::string& input) {
        static const char* base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
        std::string ret;
        int val = 0;
        int valb = -6;
        for (unsigned char c : input) {
            val = (val << 8) + c;
            valb += 8;
            while (valb >= 0) {
                ret.push_back(base64_chars[(val >> valb) & 0x3F]);
                valb -= 6;
            }
        }
        if (valb > -6) ret.push_back(base64_chars[((val << 8) >> (valb + 8)) & 0x3F]);
        return ret;
    }

    // HMAC SHA256 signing
    std::string sign(const std::string& data) {
        unsigned char hash[EVP_MAX_MD_SIZE];
        unsigned int hashLen;
        
        HMAC(EVP_sha256(), secret.c_str(), secret.length(),
             (unsigned char*)data.c_str(), data.length(), hash, &hashLen);
        
        return std::string((char*)hash, hashLen);
    }

public:
    JwtUtil(const std::string& jwtSecret, int expMinutes = 60) 
        : secret(jwtSecret), expirationMinutes(expMinutes) {}

    /**
     * Generate access token
     */
    std::string generateAccessToken(const std::string& userId, const std::string& email, const std::string& role) {
        // Create header
        json header = {
            {"alg", "HS256"},
            {"typ", "JWT"}
        };

        // Create payload
        auto now = std::chrono::system_clock::now();
        auto exp = now + std::chrono::minutes(expirationMinutes);
        auto iat = std::chrono::system_clock::to_time_t(now);
        auto expTime = std::chrono::system_clock::to_time_t(exp);

        json payload = {
            {"iss", "agrisphere"},
            {"iat", iat},
            {"exp", expTime},
            {"userId", userId},
            {"email", email},
            {"role", role}
        };

        // Encode
        std::string headerEncoded = base64UrlEncode(header.dump());
        std::string payloadEncoded = base64UrlEncode(payload.dump());
        std::string message = headerEncoded + "." + payloadEncoded;
        
        // Sign
        std::string signature = sign(message);
        std::string signatureEncoded = base64UrlEncode(signature);
        
        return message + "." + signatureEncoded;
    }

    /**
     * Generate refresh token (longer expiration)
     */
    std::string generateRefreshToken(const std::string& userId) {
        json header = {
            {"alg", "HS256"},
            {"typ", "JWT"}
        };

        auto now = std::chrono::system_clock::now();
        auto exp = now + std::chrono::hours(24 * 7); // 7 days
        auto iat = std::chrono::system_clock::to_time_t(now);
        auto expTime = std::chrono::system_clock::to_time_t(exp);

        json payload = {
            {"iss", "agrisphere"},
            {"iat", iat},
            {"exp", expTime},
            {"userId", userId},
            {"type", "refresh"}
        };

        std::string headerEncoded = base64UrlEncode(header.dump());
        std::string payloadEncoded = base64UrlEncode(payload.dump());
        std::string message = headerEncoded + "." + payloadEncoded;
        
        std::string signature = sign(message);
        std::string signatureEncoded = base64UrlEncode(signature);
        
        return message + "." + signatureEncoded;
    }

    /**
     * Token verification result
     */
    struct VerifyResult {
        bool success = false;
        std::string errorMessage;
        std::string userId;
        std::string email;
        std::string role;
    };

    /**
     * Verify and decode JWT token
     * @param token JWT token string
     * @return VerifyResult with decoded claims
     */
    VerifyResult verifyToken(const std::string& token) {
        VerifyResult result;

        try {
            // Split token into parts
            size_t firstDot = token.find('.');
            size_t secondDot = token.find('.', firstDot + 1);
            
            if (firstDot == std::string::npos || secondDot == std::string::npos) {
                result.errorMessage = "Invalid token format";
                return result;
            }

            std::string headerEncoded = token.substr(0, firstDot);
            std::string payloadEncoded = token.substr(firstDot + 1, secondDot - firstDot - 1);
            std::string signatureEncoded = token.substr(secondDot + 1);

            // Verify signature
            std::string message = headerEncoded + "." + payloadEncoded;
            std::string expectedSignature = sign(message);
            std::string expectedSigEncoded = base64UrlEncode(expectedSignature);

            if (signatureEncoded != expectedSigEncoded) {
                result.errorMessage = "Invalid signature";
                return result;
            }

            // Decode payload
            std::string payloadJson = base64UrlDecode(payloadEncoded);
            json payload = json::parse(payloadJson);

            // Check expiration
            if (payload.contains("exp")) {
                long exp = payload["exp"];
                auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
                if (now > exp) {
                    result.errorMessage = "Token expired";
                    return result;
                }
            }

            // Extract claims
            if (payload.contains("userId")) {
                result.userId = payload["userId"];
            }
            if (payload.contains("email")) {
                result.email = payload["email"];
            }
            if (payload.contains("role")) {
                result.role = payload["role"];
            }

            result.success = true;
            return result;

        } catch (const std::exception& e) {
            result.errorMessage = "Token verification failed: " + std::string(e.what());
            return result;
        }
    }

    /**
     * Extract user ID from token (for backward compatibility)
     */
    std::string getUserIdFromToken(const std::string& token) {
        auto result = verifyToken(token);
        return result.success ? result.userId : "";
    }

    /**
     * Validate token (simplified)
     */
    bool isTokenValid(const std::string& token) {
        return verifyToken(token).success;
    }

    // Base64 URL decode
    static std::string base64UrlDecode(const std::string& input) {
        std::string base64 = input;
        std::replace(base64.begin(), base64.end(), '-', '+');
        std::replace(base64.begin(), base64.end(), '_', '/');
        
        // Add padding
        while (base64.length() % 4 != 0) {
            base64 += '=';
        }

        // Simple base64 decode
        static const std::string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        std::string decoded;
        std::vector<int> vec(base64.size());
        
        for (size_t i = 0; i < base64.size(); i++) {
            if (base64[i] == '=') break;
            vec[i] = base64_chars.find(base64[i]);
        }

        for (size_t i = 0; i < base64.size(); i += 4) {
            if (base64[i] == '=' || base64[i+1] == '=') break;
            
            int n = (vec[i] << 18) + (vec[i+1] << 12);
            decoded.push_back((n >> 16) & 0xFF);
            
            if (i+2 < base64.size() && base64[i+2] != '=') {
                n += (vec[i+2] << 6);
                decoded.push_back((n >> 8) & 0xFF);
            }
            
            if (i+3 < base64.size() && base64[i+3] != '=') {
                n += vec[i+3];
                decoded.push_back(n & 0xFF);
            }
        }

        return decoded;
    }
};

} // namespace utils
} // namespace agrisphere
