/**
 * Authentication Service
 * Handles user registration, login, and token management
 */

#pragma once

#include "repositories/UserRepository.h"
#include "utils/PasswordUtil.h"
#include "utils/JwtUtil.h"
#include "utils/Logger.h"
#include "models/User.h"
#include <memory>
#include <optional>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

namespace agrisphere {
namespace services {

struct AuthResult {
    bool success;
    std::string errorCode;
    std::string errorMessage;
    std::optional<models::User> user;
    std::string accessToken;
    std::string refreshToken;
};

class AuthService {
private:
    std::shared_ptr<repositories::UserRepository> userRepo;
    std::shared_ptr<utils::JwtUtil> jwtUtil;

public:
    AuthService(std::shared_ptr<repositories::UserRepository> repository,
                std::shared_ptr<utils::JwtUtil> jwt)
        : userRepo(repository), jwtUtil(jwt) {}

    /**
     * Register a new user
     */
    AuthResult registerUser(const std::string& email, const std::string& password,
                           const std::string& fullName, const std::string& phone,
                           const std::string& role, const std::string& district = "",
                           const std::string& state = "") {
        AuthResult result;
        result.success = false;

        try {
            // Validate password strength
            std::string passwordError = utils::PasswordUtil::validatePasswordStrength(password);
            if (!passwordError.empty()) {
                result.errorCode = "WEAK_PASSWORD";
                result.errorMessage = passwordError;
                utils::Logger::warning("Registration failed: Weak password");
                return result;
            }

            // Check if email already exists
            if (userRepo->emailExists(email)) {
                result.errorCode = "EMAIL_EXISTS";
                result.errorMessage = "Email already registered";
                utils::Logger::warning("Registration failed: Email exists - " + email);
                return result;
            }

            // Hash password
            std::string passwordHash = utils::PasswordUtil::hashPassword(password);

            // Create user model
            models::User newUser;
            newUser.email = email;
            newUser.passwordHash = passwordHash;
            newUser.fullName = fullName;
            newUser.phone = phone;
            newUser.role = models::User::stringToRole(role);
            newUser.status = models::UserStatus::ACTIVE;
            newUser.district = district;
            newUser.state = state;

            // Save to database
            std::string userId = userRepo->create(newUser);
            newUser.id = userId;

            // Generate tokens
            std::string accessToken = jwtUtil->generateAccessToken(userId, email, role);
            std::string refreshToken = jwtUtil->generateRefreshToken(userId);

            result.success = true;
            result.user = newUser;
            result.accessToken = accessToken;
            result.refreshToken = refreshToken;

            utils::Logger::info("User registered successfully: " + email);
            return result;

        } catch (const std::exception& e) {
            result.errorCode = "SERVER_ERROR";
            result.errorMessage = e.what();
            utils::Logger::error("Registration error: " + std::string(e.what()));
            return result;
        }
    }

    /**
     * Authenticate user login
     */
    AuthResult login(const std::string& email, const std::string& password) {
        AuthResult result;
        result.success = false;

        try {
            // Find user by email
            auto userOpt = userRepo->findByEmail(email);
            if (!userOpt.has_value()) {
                result.errorCode = "INVALID_CREDENTIALS";
                result.errorMessage = "Invalid email or password";
                utils::Logger::warning("Login failed: User not found - " + email);
                return result;
            }

            models::User user = userOpt.value();

            // Check user status
            if (user.status != models::UserStatus::ACTIVE) {
                result.errorCode = "ACCOUNT_INACTIVE";
                result.errorMessage = "Account is inactive or suspended";
                utils::Logger::warning("Login failed: Account inactive - " + email);
                return result;
            }

            // Verify password
            bool passwordValid = utils::PasswordUtil::verifyPassword(password, user.passwordHash);
            if (!passwordValid) {
                result.errorCode = "INVALID_CREDENTIALS";
                result.errorMessage = "Invalid email or password";
                utils::Logger::warning("Login failed: Invalid password - " + email);
                return result;
            }

            // Generate tokens
            std::string roleStr = models::User::roleToString(user.role);
            std::string accessToken = jwtUtil->generateAccessToken(user.id, user.email, roleStr);
            std::string refreshToken = jwtUtil->generateRefreshToken(user.id);

            result.success = true;
            result.user = user;
            result.accessToken = accessToken;
            result.refreshToken = refreshToken;

            utils::Logger::info("User logged in successfully: " + email);
            return result;

        } catch (const std::exception& e) {
            result.errorCode = "SERVER_ERROR";
            result.errorMessage = e.what();
            utils::Logger::error("Login error: " + std::string(e.what()));
            return result;
        }
    }

    /**
     * Refresh access token
     */
    AuthResult refreshAccessToken(const std::string& refreshToken) {
        AuthResult result;
        result.success = false;

        try {
            // Verify refresh token
            if (!jwtUtil->isTokenValid(refreshToken)) {
                result.errorCode = "INVALID_TOKEN";
                result.errorMessage = "Invalid or expired refresh token";
                return result;
            }

            // Extract user ID
            std::string userId = jwtUtil->getUserIdFromToken(refreshToken);
            if (userId.empty()) {
                result.errorCode = "INVALID_TOKEN";
                result.errorMessage = "Token does not contain user ID";
                return result;
            }

            // Find user
            auto userOpt = userRepo->findById(userId);
            if (!userOpt.has_value()) {
                result.errorCode = "USER_NOT_FOUND";
                result.errorMessage = "User not found";
                return result;
            }

            models::User user = userOpt.value();

            // Check user status
            if (user.status != models::UserStatus::ACTIVE) {
                result.errorCode = "ACCOUNT_INACTIVE";
                result.errorMessage = "Account is inactive";
                return result;
            }

            // Generate new access token
            std::string roleStr = models::User::roleToString(user.role);
            std::string newAccessToken = jwtUtil->generateAccessToken(user.id, user.email, roleStr);

            result.success = true;
            result.user = user;
            result.accessToken = newAccessToken;
            result.refreshToken = refreshToken; // Keep same refresh token

            utils::Logger::info("Access token refreshed for user: " + user.email);
            return result;

        } catch (const std::exception& e) {
            result.errorCode = "SERVER_ERROR";
            result.errorMessage = e.what();
            utils::Logger::error("Token refresh error: " + std::string(e.what()));
            return result;
        }
    }

    /**
     * Validate access token and get user
     */
    std::optional<models::User> validateToken(const std::string& accessToken) {
        try {
            if (!jwtUtil->isTokenValid(accessToken)) {
                return std::nullopt;
            }

            std::string userId = jwtUtil->getUserIdFromToken(accessToken);
            if (userId.empty()) {
                return std::nullopt;
            }

            return userRepo->findById(userId);

        } catch (...) {
            return std::nullopt;
        }
    }
};

} // namespace services
} // namespace agrisphere
