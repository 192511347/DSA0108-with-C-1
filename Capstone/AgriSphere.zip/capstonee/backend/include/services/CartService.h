/**
 * CartService.h
 * Business logic for shopping cart operations
 */

#ifndef AGRISPHERE_CARTSERVICE_H
#define AGRISPHERE_CARTSERVICE_H

#include <memory>
#include <string>
#include <optional>

#include "repositories/CartRepository.h"
#include "repositories/ProductRepository.h"
#include "models/Cart.h"
#include "utils/Logger.h"

namespace agrisphere {
namespace services {

/**
 * Result structure for cart operations
 */
struct CartResult {
    bool success = false;
    std::string errorCode;
    std::string errorMessage;
    std::optional<models::Cart> cart;
};

/**
 * Cart service for business logic
 */
class CartService {
private:
    std::shared_ptr<repositories::CartRepository> cartRepo;
    std::shared_ptr<repositories::ProductRepository> productRepo;

public:
    /**
     * Constructor
     * @param cartRepo Cart repository
     * @param productRepo Product repository (for validation)
     */
    CartService(
        std::shared_ptr<repositories::CartRepository> cartRepo,
        std::shared_ptr<repositories::ProductRepository> productRepo
    ) : cartRepo(cartRepo), productRepo(productRepo) {}

    /**
     * Get user's cart (creates if doesn't exist)
     * @param userId User UUID
     * @return CartResult with cart data
     */
    CartResult getUserCart(const std::string& userId) {
        CartResult result;

        try {
            auto cart = cartRepo->findOrCreateByUserId(userId);
            
            if (!cart) {
                result.errorCode = "CART_ERROR";
                result.errorMessage = "Failed to retrieve cart";
                return result;
            }

            result.success = true;
            result.cart = cart;
            return result;

        } catch (const std::exception& e) {
            utils::Logger::error("Get cart error: " + std::string(e.what()));
            result.errorCode = "INTERNAL_ERROR";
            result.errorMessage = "Failed to get cart";
            return result;
        }
    }

    /**
     * Add item to cart
     * @param userId User UUID
     * @param productId Product UUID
     * @param quantity Quantity to add
     * @return CartResult with updated cart
     */
    CartResult addItem(const std::string& userId, const std::string& productId, int quantity) {
        CartResult result;

        // Validate quantity
        if (quantity <= 0) {
            result.errorCode = "INVALID_QUANTITY";
            result.errorMessage = "Quantity must be greater than zero";
            return result;
        }

        try {
            // Check if product exists and is available
            auto product = productRepo->findById(productId);
            if (!product) {
                result.errorCode = "PRODUCT_NOT_FOUND";
                result.errorMessage = "Product not found";
                return result;
            }

            // Check stock availability
            if (product->availableQuantity < quantity) {
                result.errorCode = "INSUFFICIENT_STOCK";
                result.errorMessage = "Insufficient stock available";
                return result;
            }

            // Check product status
            if (product->status != models::ProductStatus::ACTIVE) {
                result.errorCode = "PRODUCT_UNAVAILABLE";
                result.errorMessage = "Product is not available for purchase";
                return result;
            }

            // Get or create cart
            auto cart = cartRepo->findOrCreateByUserId(userId);
            if (!cart) {
                result.errorCode = "CART_ERROR";
                result.errorMessage = "Failed to access cart";
                return result;
            }

            // Add item to cart
            bool added = cartRepo->addOrUpdateItem(cart->id, productId, quantity);
            if (!added) {
                result.errorCode = "ADD_FAILED";
                result.errorMessage = "Failed to add item to cart";
                return result;
            }

            // Reload cart with updated items
            cart = cartRepo->findOrCreateByUserId(userId);
            
            result.success = true;
            result.cart = cart;
            utils::Logger::info("Added " + std::to_string(quantity) + " of product " + productId + " to cart");
            return result;

        } catch (const std::exception& e) {
            utils::Logger::error("Add to cart error: " + std::string(e.what()));
            result.errorCode = "INTERNAL_ERROR";
            result.errorMessage = "Failed to add item to cart";
            return result;
        }
    }

    /**
     * Update cart item quantity
     * @param userId User UUID (for ownership verification)
     * @param itemId Cart item UUID
     * @param quantity New quantity
     * @return CartResult with updated cart
     */
    CartResult updateItemQuantity(const std::string& userId, const std::string& itemId, int quantity) {
        CartResult result;

        if (quantity <= 0) {
            result.errorCode = "INVALID_QUANTITY";
            result.errorMessage = "Quantity must be greater than zero";
            return result;
        }

        try {
            // Update quantity
            bool updated = cartRepo->updateItemQuantity(itemId, quantity);
            if (!updated) {
                result.errorCode = "UPDATE_FAILED";
                result.errorMessage = "Failed to update item quantity";
                return result;
            }

            // Reload cart
            auto cart = cartRepo->findOrCreateByUserId(userId);
            
            result.success = true;
            result.cart = cart;
            return result;

        } catch (const std::exception& e) {
            utils::Logger::error("Update cart item error: " + std::string(e.what()));
            result.errorCode = "INTERNAL_ERROR";
            result.errorMessage = "Failed to update item";
            return result;
        }
    }

    /**
     * Remove item from cart
     * @param userId User UUID
     * @param itemId Cart item UUID
     * @return CartResult with updated cart
     */
    CartResult removeItem(const std::string& userId, const std::string& itemId) {
        CartResult result;

        try {
            bool removed = cartRepo->removeItem(itemId);
            if (!removed) {
                result.errorCode = "REMOVE_FAILED";
                result.errorMessage = "Failed to remove item";
                return result;
            }

            // Reload cart
            auto cart = cartRepo->findOrCreateByUserId(userId);
            
            result.success = true;
            result.cart = cart;
            utils::Logger::info("Removed item " + itemId + " from cart");
            return result;

        } catch (const std::exception& e) {
            utils::Logger::error("Remove cart item error: " + std::string(e.what()));
            result.errorCode = "INTERNAL_ERROR";
            result.errorMessage = "Failed to remove item";
            return result;
        }
    }

    /**
     * Clear all items from cart
     * @param userId User UUID
     * @return CartResult with empty cart
     */
    CartResult clearCart(const std::string& userId) {
        CartResult result;

        try {
            auto cart = cartRepo->findOrCreateByUserId(userId);
            if (!cart) {
                result.errorCode = "CART_ERROR";
                result.errorMessage = "Cart not found";
                return result;
            }

            bool cleared = cartRepo->clearCart(cart->id);
            if (!cleared) {
                result.errorCode = "CLEAR_FAILED";
                result.errorMessage = "Failed to clear cart";
                return result;
            }

            // Reload empty cart
            cart = cartRepo->findOrCreateByUserId(userId);
            
            result.success = true;
            result.cart = cart;
            utils::Logger::info("Cleared cart for user " + userId);
            return result;

        } catch (const std::exception& e) {
            utils::Logger::error("Clear cart error: " + std::string(e.what()));
            result.errorCode = "INTERNAL_ERROR";
            result.errorMessage = "Failed to clear cart";
            return result;
        }
    }
};

} // namespace services
} // namespace agrisphere

#endif // AGRISPHERE_CARTSERVICE_H
