/**
 * Product Service
 * Business logic for product operations
 */

#pragma once

#include "repositories/ProductRepository.h"
#include "utils/Logger.h"
#include "models/Product.h"
#include <memory>
#include <vector>
#include <optional>

namespace agrisphere {
namespace services {

struct ProductListResult {
    std::vector<models::Product> products;
    int totalItems;
    int page;
    int pageSize;
    int totalPages;
};

class ProductService {
private:
    std::shared_ptr<repositories::ProductRepository> productRepo;

public:
    explicit ProductService(std::shared_ptr<repositories::ProductRepository> repository)
        : productRepo(repository) {}

    /**
     * Get products with pagination
     */
    ProductListResult getProducts(int page = 1, int pageSize = 20, const std::string& category = "") {
        ProductListResult result;
        result.page = page;
        result.pageSize = pageSize;

        try {
            int offset = (page - 1) * pageSize;

            if (!category.empty()) {
                result.products = productRepo->findByCategory(category, pageSize);
                result.totalItems = result.products.size(); // Simplified, should count category total
            } else {
                result.products = productRepo->findAll(pageSize, offset);
                result.totalItems = productRepo->countAll();
            }

            result.totalPages = (result.totalItems + pageSize - 1) / pageSize;

            utils::Logger::info("Fetched " + std::to_string(result.products.size()) + " products");
            return result;

        } catch (const std::exception& e) {
            utils::Logger::error("Error fetching products: " + std::string(e.what()));
            result.totalItems = 0;
            result.totalPages = 0;
            return result;
        }
    }

    /**
     * Get single product by ID
     */
    std::optional<models::Product> getProductById(const std::string& id) {
        try {
            auto product = productRepo->findById(id);
            if (product.has_value()) {
                utils::Logger::info("Product found: " + id);
            } else {
                utils::Logger::warning("Product not found: " + id);
            }
            return product;

        } catch (const std::exception& e) {
            utils::Logger::error("Error fetching product: " + std::string(e.what()));
            return std::nullopt;
        }
    }

    /**
     * Create new product
     */
    std::optional<std::string> createProduct(const models::Product& product, const std::string& sellerId) {
        try {
            // Validate product data
            if (product.name.empty()) {
                utils::Logger::warning("Product creation failed: Name is empty");
                return std::nullopt;
            }

            if (product.pricePerUnit <= 0) {
                utils::Logger::warning("Product creation failed: Invalid price");
                return std::nullopt;
            }

            if (product.availableQuantity < 0) {
                utils::Logger::warning("Product creation failed: Invalid quantity");
                return std::nullopt;
            }

            // Set seller ID
            models::Product newProduct = product;
            newProduct.sellerId = sellerId;

            // Create in database
            std::string productId = productRepo->create(newProduct);
            utils::Logger::info("Product created: " + productId);
            return productId;

        } catch (const std::exception& e) {
            utils::Logger::error("Error creating product: " + std::string(e.what()));
            return std::nullopt;
        }
    }

    /**
     * Update existing product
     */
    bool updateProduct(const models::Product& product, const std::string& sellerId) {
        try {
            // Verify ownership
            auto existingProduct = productRepo->findById(product.id);
            if (!existingProduct.has_value()) {
                utils::Logger::warning("Product update failed: Product not found");
                return false;
            }

            if (existingProduct->sellerId != sellerId) {
                utils::Logger::warning("Product update failed: Not authorized");
                return false;
            }

            // Update in database
            bool success = productRepo->update(product);
            if (success) {
                utils::Logger::info("Product updated: " + product.id);
            }
            return success;

        } catch (const std::exception& e) {
            utils::Logger::error("Error updating product: " + std::string(e.what()));
            return false;
        }
    }

    /**
     * Get products by seller
     */
    std::vector<models::Product> getSellerProducts(const std::string& sellerId) {
        try {
            auto products = productRepo->findBySellerId(sellerId);
            utils::Logger::info("Fetched " + std::to_string(products.size()) + " products for seller: " + sellerId);
            return products;

        } catch (const std::exception& e) {
            utils::Logger::error("Error fetching seller products: " + std::string(e.what()));
            return std::vector<models::Product>();
        }
    }

    /**
     * Check product availability
     */
    bool isProductAvailable(const std::string& productId, int quantity) {
        try {
            auto product = productRepo->findById(productId);
            if (!product.has_value()) {
                return false;
            }

            return product->status == models::ProductStatus::ACTIVE &&
                   product->availableQuantity >= quantity;

        } catch (...) {
            return false;
        }
    }

    /**
     * Reduce product stock (for order processing)
     */
    bool reduceStock(const std::string& productId, int quantity) {
        try {
            auto productOpt = productRepo->findById(productId);
            if (!productOpt.has_value()) {
                return false;
            }

            models::Product product = productOpt.value();
            
            if (product.availableQuantity < quantity) {
                utils::Logger::warning("Insufficient stock for product: " + productId);
                return false;
            }

            product.availableQuantity -= quantity;
            
            // Mark as sold out if quantity reaches zero
            if (product.availableQuantity == 0) {
                product.status = models::ProductStatus::SOLD_OUT;
            }

            return productRepo->update(product);

        } catch (const std::exception& e) {
            utils::Logger::error("Error reducing stock: " + std::string(e.what()));
            return false;
        }
    }
};

} // namespace services
} // namespace agrisphere
