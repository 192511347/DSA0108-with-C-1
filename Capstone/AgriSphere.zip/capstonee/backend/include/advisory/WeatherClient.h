#pragma once
#include "advisory/HttpClient.h"
#include <nlohmann/json.hpp>
#include <string>
namespace agrisphere { namespace advisory {
using json=nlohmann::json;
struct WeatherResult {json data=nullptr; std::string note="Live weather unavailable";};
class WeatherClient {
public:
    WeatherResult fetch(const std::string& location) const {
        WeatherResult r;
        if(location.empty()){r.note="Location missing. Add your district or farm location.";return r;}
        try {
            std::string geo="/v1/search?name="+utf8UrlEncode(location)+"&count=5&language=en&countryCode=IN";
            auto g=json::parse(requestHttps(L"geocoding-api.open-meteo.com",std::wstring(geo.begin(),geo.end())));
            if(!g.contains("results") || !g["results"].is_array() || g["results"].empty()){
                r.note="No matching location found in India";return r;
            }
            auto loc=g["results"][0];
            auto lat=std::to_string(loc.at("latitude").get<double>());
            auto lon=std::to_string(loc.at("longitude").get<double>());
            std::string endpoint="/v1/forecast?latitude="+lat+"&longitude="+lon+
                "&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m"+
                "&daily=precipitation_sum,temperature_2m_max,temperature_2m_min&forecast_days=5&timezone=auto";
            json w=json::parse(requestHttps(L"api.open-meteo.com",std::wstring(endpoint.begin(),endpoint.end())));
            r.data={{"location",loc.value("name",location)},{"region",loc.value("admin1",std::string(""))},
                    {"latitude",loc.at("latitude")},{"longitude",loc.at("longitude")},
                    {"current",w.value("current",json::object())},{"daily",w.value("daily",json::object())},
                    {"timezone",w.value("timezone",std::string(""))},{"provider","Open-Meteo"}};
            r.note="Live forecast from Open-Meteo; forecasts can change";
        } catch(...) {r.note="Weather service unavailable. No weather conditions assumed.";}
        return r;
    }
};
}}
