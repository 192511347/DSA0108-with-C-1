#pragma once
#include <libpq-fe.h>
#include <nlohmann/json.hpp>
#include <memory>
#include <string>
#include <vector>
#include <stdexcept>

namespace agrisphere { namespace advisory {
using json = nlohmann::json;
class AdvisoryRepository {
    PGconn* db_ = nullptr;
public:
    using Result = std::unique_ptr<PGresult, decltype(&PQclear)>;
    explicit AdvisoryRepository(const std::string& cs) {
        db_ = PQconnectdb(cs.c_str());
        if (!db_ || PQstatus(db_) != CONNECTION_OK) {
            std::string msg = db_ ? PQerrorMessage(db_) : "Could not initialize PostgreSQL";
            if (db_) PQfinish(db_);
            throw std::runtime_error(msg);
        }
    }
    ~AdvisoryRepository() { if (db_) PQfinish(db_); }
    AdvisoryRepository(const AdvisoryRepository&) = delete;
    Result query(const std::string& sql, const std::vector<std::string>& params = {}) {
        std::vector<const char*> values;
        for (const auto& p : params) values.push_back(p.c_str());
        Result result(PQexecParams(db_, sql.c_str(), static_cast<int>(values.size()), nullptr,
            values.empty() ? nullptr : values.data(), nullptr, nullptr, 0), &PQclear);
        if (!result || (PQresultStatus(result.get()) != PGRES_TUPLES_OK && PQresultStatus(result.get()) != PGRES_COMMAND_OK))
            throw std::runtime_error(PQerrorMessage(db_));
        return result;
    }
    static std::string field(PGresult* r, int row, int column) {
        return PQgetisnull(r,row,column) ? "" : PQgetvalue(r,row,column);
    }
    static json rows(PGresult* r) {
        json a=json::array();
        for (int i=0; i<PQntuples(r); ++i) {
            json item=json::object();
            for (int j=0; j<PQnfields(r); ++j) item[PQfname(r,j)] = field(r,i,j);
            a.push_back(item);
        }
        return a;
    }
    json context(const std::string& id, const std::string& role) {
        auto u=query("SELECT COALESCE(district,''), COALESCE(state,'') FROM users WHERE id=$1::uuid",{id});
        if (!PQntuples(u.get())) throw std::runtime_error("Account not found");
        json context={{"district",field(u.get(),0,0)},{"state",field(u.get(),0,1)},{"role",role}};
        if (role=="FARMER") {
            auto f=query("SELECT land_acres::text,soil_type,irrigation,current_crops,COALESCE(sowing_date::text,''),farm_location FROM farm_profiles WHERE user_id=$1::uuid",{id});
            if (PQntuples(f.get())) context["farm"]={{"landAcres",field(f.get(),0,0)},{"soilType",field(f.get(),0,1)},
                {"irrigation",field(f.get(),0,2)},{"currentCrops",field(f.get(),0,3)},
                {"sowingDate",field(f.get(),0,4)},{"farmLocation",field(f.get(),0,5)}};
        } else if (role=="SERVICE_PROVIDER") {
            auto s=query("SELECT id::text,service_name AS \"serviceName\",location,COALESCE(preferred_date::text,'') AS date FROM service_requests WHERE status='REQUESTED' AND provider_id IS NULL ORDER BY created_at DESC LIMIT 10");
            context["availableOpportunities"]=rows(s.get());
        } else {
            auto b=query("SELECT o.id::text AS \"orderId\",o.status,oi.product_name AS product FROM orders o JOIN order_items oi ON oi.order_id=o.id WHERE o.buyer_id=$1::uuid ORDER BY o.created_at DESC LIMIT 10",{id});
            context["myOrders"]=rows(b.get());
        }
        return context;
    }
    void save(const std::string& userId, const std::string& role, const std::string& question,
              const std::string& location, const std::string& language, const json& answer, const json& weather) {
        query("INSERT INTO advisory_history(user_id,role,question,location,language,answer,weather) VALUES($1::uuid,$2,$3,$4,$5,$6::jsonb,$7::jsonb)",
            {userId,role,question,location,language,answer.dump(),weather.dump()});
    }
    json history(const std::string& userId) {
        auto r=query("SELECT id::text,role,question,location,language,answer::text,weather::text,created_at::text AS \"createdAt\" FROM advisory_history WHERE user_id=$1::uuid ORDER BY created_at DESC LIMIT 25",{userId});
        json list=rows(r.get());
        for (auto& entry : list) {
            try {entry["answer"]=json::parse(entry["answer"].get<std::string>());} catch(...) {entry["answer"]=json::object();}
            try {entry["weather"]=json::parse(entry["weather"].get<std::string>());} catch(...) {entry["weather"]=nullptr;}
        }
        return list;
    }
};
}}
