#pragma once
#include <windows.h>
#include <winhttp.h>
#include <string>
#include <stdexcept>
#include <vector>
#pragma comment(lib,"winhttp.lib")

namespace agrisphere { namespace advisory {
class HttpError : public std::runtime_error {
public:
    int status;
    HttpError(int code, const std::string& msg) : std::runtime_error(msg), status(code) {}
};
inline std::string utf8UrlEncode(const std::string& s) {
    const char* h="0123456789ABCDEF";std::string r;
    for (unsigned char c:s) {
        if ((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.')r+=static_cast<char>(c);
        else {r+='%';r+=h[c>>4];r+=h[c&15];}
    } return r;
}
inline std::string requestHttps(const std::wstring& host, const std::wstring& path,
                                const std::string& payload="", const std::wstring& extraHeaders=L"") {
    HINTERNET session=WinHttpOpen(L"AgriSphere-Advisory/4.0",WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                                   WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0);
    if(!session) throw std::runtime_error("Unable to initialize HTTPS request");
    HINTERNET connection=nullptr, request=nullptr;
    try {
        WinHttpSetTimeouts(session,5000,5000,7000,18000);
        connection=WinHttpConnect(session,host.c_str(),INTERNET_DEFAULT_HTTPS_PORT,0);
        if(!connection) throw std::runtime_error("Unable to connect to external service");
        request=WinHttpOpenRequest(connection,payload.empty()?L"GET":L"POST",path.c_str(),nullptr,
                                   WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,WINHTTP_FLAG_SECURE);
        if(!request) throw std::runtime_error("Unable to prepare HTTPS request");
        std::wstring headers=extraHeaders+(payload.empty()?L"":L"Content-Type: application/json\r\n");
        if(!WinHttpSendRequest(request,headers.empty()?WINHTTP_NO_ADDITIONAL_HEADERS:headers.c_str(),
                headers.empty()?0:static_cast<DWORD>(-1),
                payload.empty()?WINHTTP_NO_REQUEST_DATA:const_cast<char*>(payload.data()),
                static_cast<DWORD>(payload.size()),static_cast<DWORD>(payload.size()),0))
            throw std::runtime_error("Unable to send HTTPS request");
        if(!WinHttpReceiveResponse(request,nullptr)) throw std::runtime_error("External service did not respond");
        DWORD status=0,len=sizeof(status);
        if(!WinHttpQueryHeaders(request,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,
                WINHTTP_HEADER_NAME_BY_INDEX,&status,&len,WINHTTP_NO_HEADER_INDEX))
            throw std::runtime_error("Unable to read external response status");
        std::string data;char buf[4096];DWORD count=0;
        while(WinHttpReadData(request,buf,sizeof(buf),&count) && count) {
            data.append(buf,count);
            if(data.size()>350000) throw std::runtime_error("External response too large");
        }
        WinHttpCloseHandle(request); request=nullptr;
        WinHttpCloseHandle(connection); connection=nullptr;
        WinHttpCloseHandle(session); session=nullptr;
        // Never display response bodies; provider error payload could contain request identifiers or sensitive context.
        if(status<200||status>=300) throw HttpError(static_cast<int>(status),"External API HTTP "+std::to_string(status));
        return data;
    } catch(...) {
        if(request) WinHttpCloseHandle(request);
        if(connection) WinHttpCloseHandle(connection);
        if(session) WinHttpCloseHandle(session);
        throw;
    }
}
}}
