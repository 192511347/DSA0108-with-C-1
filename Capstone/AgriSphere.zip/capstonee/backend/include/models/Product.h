/**
 * Product Model
 * Represents a product listing in the marketplace
 */

#pragma once

#include <string>
#include <vector>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

namespace agrisphere {
namespace models {

enum class ProductCategory {
    GRAINS,
    VEGETABLES,
    FRUITS,
    DAIRY,
    SPICES,
    OTHER
};

enum class ProductStatus {
    ACTIVE,
    SOLD_OUT,
    INACTIVE
};

class Product {
public:
    std::string id;
    std::string name;
    std::string description;
    ProductCategory category;
    int pricePerUnit;  // in paise (1 rupee = 100 paise)
    std::string unit;   // KG, LITRE, PIECE, etc.
    int availableQuantity;
    std::string sellerId;
    ProductStatus status;
    std::vector<std::string> images;
    std::string district;
    std::string state;
    std::string createdAt;
    std::string updatedAt;

    Product() 
        : category(ProductCategory::OTHER), 
          status(ProductStatus::ACTIVE),
          pricePerUnit(0),
          availableQuantity(0) {}

    // Convert category enum to string
    static std::string categoryToString(ProductCategory category) {
        switch (category) {
            case ProductCategory::GRAINS:     return "GRAINS";
            case ProductCategory::VEGETABLES: return "VEGETABLES";
            case ProductCategory::FRUITS:     return "FRUITS";
            case ProductCategory::DAIRY:      return "DAIRY";
            case ProductCategory::SPICES:     return "SPICES";
            case ProductCategory::OTHER:      return "OTHER";
            default: return "OTHER";
        }
    }

    // Convert string to category enum
    static ProductCategory stringToCategory(const std::string& categoryStr) {
        if (categoryStr == "GRAINS") return ProductCategory::GRAINS;
        if (categoryStr == "VEGETABLES") return ProductCategory::VEGETABLES;
        if (categoryStr == "FRUITS") return ProductCategory::FRUITS;
        if (categoryStr == "DAIRY") return ProductCategory::DAIRY;
        if (categoryStr == "SPICES") return ProductCategory::SPICES;
        return ProductCategory::OTHER;
    }

    // Convert status enum to string
    static std::string statusToString(ProductStatus status) {
        switch (status) {
            case ProductStatus::ACTIVE:   return "ACTIVE";
            case ProductStatus::SOLD_OUT: return "SOLD_OUT";
            case ProductStatus::INACTIVE: return "INACTIVE";
            default: return "ACTIVE";
        }
    }

    // Convert string to status enum
    static ProductStatus stringToStatus(const std::string& statusStr) {
        if (statusStr == "ACTIVE") return ProductStatus::ACTIVE;
        if (statusStr == "SOLD_OUT") return ProductStatus::SOLD_OUT;
        if (statusStr == "INACTIVE") return ProductStatus::INACTIVE;
        return ProductStatus::ACTIVE;
    }

    // Serialize to JSON
    json toJson() const {
        return {
            {"id", id},
            {"name", name},
            {"description", description},
            {"category", categoryToString(category)},
            {"pricePerUnit", pricePerUnit},
            {"unit", unit},
            {"availableQuantity", availableQuantity},
            {"sellerId", sellerId},
            {"status", statusToString(status)},
            {"images", images},
            {"district", district},
            {"state", state}
        };
    }

    // Deserialize from JSON
    static Product fromJson(const json& j) {
        Product product;
        product.id = j.value("id", "");
        product.name = j.value("name", "");
        product.description = j.value("description", "");
        product.category = stringToCategory(j.value("category", "OTHER"));
        product.pricePerUnit = j.value("pricePerUnit", 0);
        product.unit = j.value("unit", "");
        product.availableQuantity = j.value("availableQuantity", 0);
        product.sellerId = j.value("sellerId", "");
        product.status = stringToStatus(j.value("status", "ACTIVE"));
        
        if (j.contains("images") && j["images"].is_array()) {
            for (const auto& img : j["images"]) {
                product.images.push_back(img.get<std::string>());
            }
        }
        
        product.district = j.value("district", "");
        product.state = j.value("state", "");
        return product;
    }
};

} // namespace models
} // namespace agrisphere
