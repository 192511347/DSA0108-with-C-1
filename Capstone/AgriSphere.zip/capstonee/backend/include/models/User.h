/**
 * User Model
 * Represents a user entity in the system
 */

#pragma once

#include <string>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

namespace agrisphere {
namespace models {

enum class UserRole {
    FARMER,
    BUYER,
    SELLER,
    SERVICE_PROVIDER,
    ADMIN
};

enum class UserStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
};

class User {
public:
    std::string id;
    std::string email;
    std::string passwordHash;
    std::string fullName;
    std::string phone;
    UserRole role;
    UserStatus status;
    std::string district;
    std::string state;
    std::string createdAt;
    std::string updatedAt;

    User() : role(UserRole::BUYER), status(UserStatus::ACTIVE) {}

    // Convert role enum to string
    static std::string roleToString(UserRole role) {
        switch (role) {
            case UserRole::FARMER:           return "FARMER";
            case UserRole::BUYER:            return "BUYER";
            case UserRole::SELLER:           return "SELLER";
            case UserRole::SERVICE_PROVIDER: return "SERVICE_PROVIDER";
            case UserRole::ADMIN:            return "ADMIN";
            default: return "BUYER";
        }
    }

    // Convert string to role enum
    static UserRole stringToRole(const std::string& roleStr) {
        if (roleStr == "FARMER") return UserRole::FARMER;
        if (roleStr == "BUYER") return UserRole::BUYER;
        if (roleStr == "SELLER") return UserRole::SELLER;
        if (roleStr == "SERVICE_PROVIDER") return UserRole::SERVICE_PROVIDER;
        if (roleStr == "ADMIN") return UserRole::ADMIN;
        return UserRole::BUYER;
    }

    // Convert status enum to string
    static std::string statusToString(UserStatus status) {
        switch (status) {
            case UserStatus::ACTIVE:    return "ACTIVE";
            case UserStatus::INACTIVE:  return "INACTIVE";
            case UserStatus::SUSPENDED: return "SUSPENDED";
            default: return "ACTIVE";
        }
    }

    // Convert string to status enum
    static UserStatus stringToStatus(const std::string& statusStr) {
        if (statusStr == "ACTIVE") return UserStatus::ACTIVE;
        if (statusStr == "INACTIVE") return UserStatus::INACTIVE;
        if (statusStr == "SUSPENDED") return UserStatus::SUSPENDED;
        return UserStatus::ACTIVE;
    }

    // Serialize to JSON (safe - no password)
    json toJson() const {
        return {
            {"id", id},
            {"email", email},
            {"fullName", fullName},
            {"phone", phone},
            {"role", roleToString(role)},
            {"status", statusToString(status)},
            {"district", district},
            {"state", state}
        };
    }

    // Deserialize from JSON
    static User fromJson(const json& j) {
        User user;
        user.id = j.value("id", "");
        user.email = j.value("email", "");
        user.fullName = j.value("fullName", "");
        user.phone = j.value("phone", "");
        user.role = stringToRole(j.value("role", "BUYER"));
        user.status = stringToStatus(j.value("status", "ACTIVE"));
        user.district = j.value("district", "");
        user.state = j.value("state", "");
        return user;
    }
};

} // namespace models
} // namespace agrisphere
