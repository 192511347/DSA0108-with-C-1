/**
 * Cart.h
 * Shopping cart and cart item models
 */

#ifndef AGRISPHERE_CART_H
#define AGRISPHERE_CART_H

#include <string>
#include <vector>
#include <nlohmann/json.hpp>

namespace agrisphere {
namespace models {

using json = nlohmann::json;

/**
 * Cart item - product in user's cart
 */
struct CartItem {
    std::string id;
    std::string cartId;
    std::string productId;
    int quantity;
    std::string createdAt;
    std::string updatedAt;
    
    // Optional joined product data
    std::string productName;
    long pricePerUnit = 0;
    std::string unit;
    int availableQuantity = 0;

    /**
     * Convert to JSON
     */
    json toJson() const {
        json j = {
            {"id", id},
            {"cartId", cartId},
            {"productId", productId},
            {"quantity", quantity},
            {"createdAt", createdAt},
            {"updatedAt", updatedAt}
        };

        // Include product details if available
        if (!productName.empty()) {
            j["product"] = {
                {"name", productName},
                {"pricePerUnit", pricePerUnit},
                {"unit", unit},
                {"availableQuantity", availableQuantity}
            };
            j["subtotal"] = pricePerUnit * quantity;
        }

        return j;
    }
};

/**
 * Shopping cart with items
 */
struct Cart {
    std::string id;
    std::string userId;
    std::string createdAt;
    std::string updatedAt;
    std::vector<CartItem> items;

    /**
     * Calculate total items count
     */
    int getTotalItems() const {
        int total = 0;
        for (const auto& item : items) {
            total += item.quantity;
        }
        return total;
    }

    /**
     * Calculate total amount
     */
    long getTotalAmount() const {
        long total = 0;
        for (const auto& item : items) {
            total += item.pricePerUnit * item.quantity;
        }
        return total;
    }

    /**
     * Convert to JSON
     */
    json toJson() const {
        json itemsJson = json::array();
        for (const auto& item : items) {
            itemsJson.push_back(item.toJson());
        }

        return {
            {"id", id},
            {"userId", userId},
            {"items", itemsJson},
            {"totalItems", getTotalItems()},
            {"totalAmount", getTotalAmount()},
            {"createdAt", createdAt},
            {"updatedAt", updatedAt}
        };
    }
};

} // namespace models
} // namespace agrisphere

#endif // AGRISPHERE_CART_H
