/**
 * AuthMiddleware.h
 * JWT authentication middleware for Crow routes
 */

#ifndef AGRISPHERE_AUTHMIDDLEWARE_H
#define AGRISPHERE_AUTHMIDDLEWARE_H

#include <crow.h>
#include <nlohmann/json.hpp>
#include <string>
#include <memory>

#include "utils/JwtUtil.h"
#include "utils/Logger.h"
#include "utils/ResponseHelper.h"
#include "models/User.h"

namespace agrisphere {
namespace middleware {

using json = nlohmann::json;

/**
 * Authentication context attached to requests
 * Contains user information extracted from JWT
 */
struct AuthContext {
    bool isAuthenticated = false;
    std::string userId;
    std::string email;
    models::UserRole role = models::UserRole::BUYER;
    std::string token;
};

/**
 * Authentication middleware
 * Validates JWT tokens and attaches user context to requests
 */
class AuthMiddleware {
private:
    std::shared_ptr<utils::JwtUtil> jwtUtil;
    std::shared_ptr<utils::ResponseHelper> responseHelper;

public:
    /**
     * Constructor
     * @param jwtUtil JWT utility for token validation
     * @param responseHelper Response helper for error responses
     */
    AuthMiddleware(
        std::shared_ptr<utils::JwtUtil> jwtUtil,
        std::shared_ptr<utils::ResponseHelper> responseHelper
    ) : jwtUtil(jwtUtil), responseHelper(responseHelper) {}

    /**
     * Extract token from Authorization header
     * Expected format: "Bearer <token>"
     * @param req Crow request
     * @return Token string or empty if not found
     */
    std::string extractToken(const crow::request& req) const {
        auto authHeader = req.get_header_value("Authorization");
        
        if (authHeader.empty()) {
            return "";
        }

        // Check for "Bearer " prefix
        const std::string prefix = "Bearer ";
        if (authHeader.length() <= prefix.length() || authHeader.substr(0, prefix.size()) != prefix) {
            return "";
        }

        return authHeader.substr(prefix.size());
    }

    /**
     * Validate JWT and create auth context
     * @param token JWT token
     * @return AuthContext with user information
     */
    AuthContext validateToken(const std::string& token) const {
        AuthContext context;
        context.token = token;

        if (token.empty()) {
            return context;
        }

        try {
            auto payload = jwtUtil->verifyToken(token);
            
            if (!payload.success) {
                utils::Logger::warning("Token validation failed: " + payload.errorMessage);
                return context;
            }

            // Extract user information from claims
            context.isAuthenticated = true;
            context.userId = payload.userId;
            context.email = payload.email;
            
            // Parse role string to enum
            if (payload.role == "FARMER") {
                context.role = models::UserRole::FARMER;
            } else if (payload.role == "BUYER") {
                context.role = models::UserRole::BUYER;
            } else if (payload.role == "SELLER") {
                context.role = models::UserRole::SELLER;
            } else if (payload.role == "SERVICE_PROVIDER") {
                context.role = models::UserRole::SERVICE_PROVIDER;
            } else if (payload.role == "ADMIN") {
                context.role = models::UserRole::ADMIN;
            } else {
                context.role = models::UserRole::BUYER; // default
            }

            utils::Logger::info("Token validated for user: " + context.email);
            
        } catch (const std::exception& e) {
            utils::Logger::error("Token validation exception: " + std::string(e.what()));
            context.isAuthenticated = false;
        }

        return context;
    }

    /**
     * Check if user has required role
     * @param context Auth context from token validation
     * @param requiredRole Required role
     * @return true if user has required role or higher
     */
    bool hasRole(const AuthContext& context, models::UserRole requiredRole) const {
        if (!context.isAuthenticated) {
            return false;
        }

        // ADMIN has access to everything
        if (context.role == models::UserRole::ADMIN) {
            return true;
        }

        // Exact role match
        return context.role == requiredRole;
    }
};

} // namespace middleware
} // namespace agrisphere

#endif // AGRISPHERE_AUTHMIDDLEWARE_H
