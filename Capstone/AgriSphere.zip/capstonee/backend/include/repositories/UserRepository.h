/**
 * User Repository
 * Handles all database operations for users
 */

#pragma once

#include "core/Database.h"
#include "models/User.h"
#include <optional>
#include <memory>
#include <vector>

namespace agrisphere {
namespace repositories {

class UserRepository {
private:
    std::shared_ptr<core::Database> db;

public:
    explicit UserRepository(std::shared_ptr<core::Database> database) 
        : db(database) {}

    // Find user by email
    std::optional<models::User> findByEmail(const std::string& email) {
        if (!db->isConnected()) {
            return std::nullopt;
        }

        try {
            const char* params[1] = { email.c_str() };
            PGresult* res = db->executeParams(
                "SELECT id, email, full_name, password_hash, phone, role, status, district, state, created_at, updated_at "
                "FROM users WHERE email = $1 LIMIT 1",
                1, params
            );

            if (PQntuples(res) == 0) {
                PQclear(res);
                return std::nullopt;
            }

            models::User user;
            user.id = PQgetvalue(res, 0, 0);
            user.email = PQgetvalue(res, 0, 1);
            user.fullName = PQgetvalue(res, 0, 2);
            user.passwordHash = PQgetvalue(res, 0, 3);
            user.phone = PQgetvalue(res, 0, 4);
            user.role = models::User::stringToRole(PQgetvalue(res, 0, 5));
            user.status = models::User::stringToStatus(PQgetvalue(res, 0, 6));
            user.district = PQgetvalue(res, 0, 7);
            user.state = PQgetvalue(res, 0, 8);
            user.createdAt = PQgetvalue(res, 0, 9);
            user.updatedAt = PQgetvalue(res, 0, 10);

            PQclear(res);
            return user;

        } catch (const std::exception& e) {
            throw std::runtime_error("Failed to find user by email: " + std::string(e.what()));
        }
    }

    // Find user by ID
    std::optional<models::User> findById(const std::string& id) {
        if (!db->isConnected()) {
            return std::nullopt;
        }

        try {
            const char* params[1] = { id.c_str() };
            PGresult* res = db->executeParams(
                "SELECT id, email, full_name, password_hash, phone, role, status, district, state, created_at, updated_at "
                "FROM users WHERE id = $1 LIMIT 1",
                1, params
            );

            if (PQntuples(res) == 0) {
                PQclear(res);
                return std::nullopt;
            }

            models::User user;
            user.id = PQgetvalue(res, 0, 0);
            user.email = PQgetvalue(res, 0, 1);
            user.fullName = PQgetvalue(res, 0, 2);
            user.passwordHash = PQgetvalue(res, 0, 3);
            user.phone = PQgetvalue(res, 0, 4);
            user.role = models::User::stringToRole(PQgetvalue(res, 0, 5));
            user.status = models::User::stringToStatus(PQgetvalue(res, 0, 6));
            user.district = PQgetvalue(res, 0, 7);
            user.state = PQgetvalue(res, 0, 8);
            user.createdAt = PQgetvalue(res, 0, 9);
            user.updatedAt = PQgetvalue(res, 0, 10);

            PQclear(res);
            return user;

        } catch (const std::exception& e) {
            throw std::runtime_error("Failed to find user by ID: " + std::string(e.what()));
        }
    }

    // Create new user
    std::string create(const models::User& user) {
        if (!db->isConnected()) {
            throw std::runtime_error("Database not connected");
        }

        try {
            // Store strings to ensure they live through the query
            std::string roleStr = models::User::roleToString(user.role);
            
            const char* params[7] = {
                user.email.c_str(),
                user.passwordHash.c_str(),
                user.fullName.c_str(),
                user.phone.c_str(),
                roleStr.c_str(),
                user.district.c_str(),
                user.state.c_str()
            };

            PGresult* res = db->executeParams(
                "INSERT INTO users (email, password_hash, full_name, phone, role, district, state, status) "
                "VALUES ($1, $2, $3, $4, $5, $6, $7, 'ACTIVE') "
                "RETURNING id",
                7, params
            );

            std::string newId = PQgetvalue(res, 0, 0);
            PQclear(res);
            return newId;

        } catch (const std::exception& e) {
            throw std::runtime_error("Failed to create user: " + std::string(e.what()));
        }
    }

    // Update user
    bool update(const models::User& user) {
        if (!db->isConnected()) {
            return false;
        }

        try {
            // Store strings to ensure they live through the query
            std::string roleStr = models::User::roleToString(user.role);
            std::string statusStr = models::User::statusToString(user.status);
            
            const char* params[7] = {
                user.fullName.c_str(),
                user.phone.c_str(),
                roleStr.c_str(),
                statusStr.c_str(),
                user.district.c_str(),
                user.state.c_str(),
                user.id.c_str()
            };

            PGresult* res = db->executeParams(
                "UPDATE users SET full_name = $1, phone = $2, role = $3, status = $4, "
                "district = $5, state = $6, updated_at = NOW() WHERE id = $7",
                7, params
            );

            bool success = (PQcmdTuples(res)[0] != '0');
            PQclear(res);
            return success;

        } catch (const std::exception& e) {
            throw std::runtime_error("Failed to update user: " + std::string(e.what()));
        }
    }

    // Check if email exists
    bool emailExists(const std::string& email) {
        if (!db->isConnected()) {
            return false;
        }

        try {
            const char* params[1] = { email.c_str() };
            PGresult* res = db->executeParams(
                "SELECT COUNT(*) FROM users WHERE email = $1",
                1, params
            );

            bool exists = (std::stoi(PQgetvalue(res, 0, 0)) > 0);
            PQclear(res);
            return exists;

        } catch (const std::exception&) {
            return false;
        }
    }
};

} // namespace repositories
} // namespace agrisphere
