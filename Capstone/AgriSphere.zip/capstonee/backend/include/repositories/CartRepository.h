/**
 * CartRepository.h
 * Data access layer for shopping carts
 */

#ifndef AGRISPHERE_CARTREPOSITORY_H
#define AGRISPHERE_CARTREPOSITORY_H

#include <memory>
#include <string>
#include <vector>
#include <optional>

#include "core/Database.h"
#include "models/Cart.h"
#include "utils/Logger.h"

namespace agrisphere {
namespace repositories {

/**
 * Cart repository for database operations
 */
class CartRepository {
private:
    std::shared_ptr<core::Database> db;

public:
    /**
     * Constructor
     * @param db Database connection
     */
    explicit CartRepository(std::shared_ptr<core::Database> db) : db(db) {}

    /**
     * Find or create cart for user
     * @param userId User UUID
     * @return Optional cart (empty if error)
     */
    std::optional<models::Cart> findOrCreateByUserId(const std::string& userId) {
        if (!db->isConnected()) {
            utils::Logger::error("Database not connected");
            return std::nullopt;
        }

        try {
            // First, try to find existing cart
            const char* findParams[1] = { userId.c_str() };
            
            PGresult* result = db->executeParams(
                "SELECT id, user_id, created_at, updated_at FROM carts WHERE user_id = $1",
                1, findParams
            );

            if (PQntuples(result) > 0) {
                // Cart exists
                models::Cart cart;
                cart.id = PQgetvalue(result, 0, 0);
                cart.userId = PQgetvalue(result, 0, 1);
                cart.createdAt = PQgetvalue(result, 0, 2);
                cart.updatedAt = PQgetvalue(result, 0, 3);
                
                PQclear(result);
                
                // Load cart items
                cart.items = getCartItems(cart.id);
                
                return cart;
            }

            PQclear(result);

            // Cart doesn't exist, create it
            result = db->executeParams(
                "INSERT INTO carts (user_id) VALUES ($1) "
                "RETURNING id, user_id, created_at, updated_at",
                1, findParams
            );

            if (PQntuples(result) > 0) {
                models::Cart cart;
                cart.id = PQgetvalue(result, 0, 0);
                cart.userId = PQgetvalue(result, 0, 1);
                cart.createdAt = PQgetvalue(result, 0, 2);
                cart.updatedAt = PQgetvalue(result, 0, 3);
                // New cart has no items
                
                PQclear(result);
                return cart;
            }

            PQclear(result);
            return std::nullopt;

        } catch (const std::exception& e) {
            utils::Logger::error("Cart findOrCreate error: " + std::string(e.what()));
            return std::nullopt;
        }
    }

    /**
     * Get cart items with product details
     * @param cartId Cart UUID
     * @return Vector of cart items
     */
    std::vector<models::CartItem> getCartItems(const std::string& cartId) {
        std::vector<models::CartItem> items;

        if (!db->isConnected()) {
            return items;
        }

        try {
            const char* params[1] = { cartId.c_str() };
            
            PGresult* result = db->executeParams(
                "SELECT ci.id, ci.cart_id, ci.product_id, ci.quantity, "
                "ci.created_at, ci.updated_at, "
                "p.name, p.price_per_unit, p.unit, p.available_quantity "
                "FROM cart_items ci "
                "JOIN products p ON p.id = ci.product_id "
                "WHERE ci.cart_id = $1 "
                "ORDER BY ci.created_at DESC",
                1, params
            );

            int rowCount = PQntuples(result);
            for (int i = 0; i < rowCount; i++) {
                models::CartItem item;
                item.id = PQgetvalue(result, i, 0);
                item.cartId = PQgetvalue(result, i, 1);
                item.productId = PQgetvalue(result, i, 2);
                item.quantity = std::stoi(PQgetvalue(result, i, 3));
                item.createdAt = PQgetvalue(result, i, 4);
                item.updatedAt = PQgetvalue(result, i, 5);
                
                // Product details
                item.productName = PQgetvalue(result, i, 6);
                item.pricePerUnit = std::stol(PQgetvalue(result, i, 7));
                item.unit = PQgetvalue(result, i, 8);
                item.availableQuantity = std::stoi(PQgetvalue(result, i, 9));

                items.push_back(item);
            }

            PQclear(result);

        } catch (const std::exception& e) {
            utils::Logger::error("Get cart items error: " + std::string(e.what()));
        }

        return items;
    }

    /**
     * Add item to cart or update quantity if exists
     * @param cartId Cart UUID
     * @param productId Product UUID
     * @param quantity Quantity to add
     * @return true if successful
     */
    bool addOrUpdateItem(const std::string& cartId, const std::string& productId, int quantity) {
        if (!db->isConnected()) {
            return false;
        }

        try {
            // Use INSERT ... ON CONFLICT to handle duplicates
            const char* params[3] = {
                cartId.c_str(),
                productId.c_str(),
                std::to_string(quantity).c_str()
            };
            
            PGresult* result = db->executeParams(
                "INSERT INTO cart_items (cart_id, product_id, quantity) "
                "VALUES ($1, $2, $3) "
                "ON CONFLICT (cart_id, product_id) "
                "DO UPDATE SET "
                "  quantity = cart_items.quantity + EXCLUDED.quantity, "
                "  updated_at = NOW()",
                3, params
            );
            
            PQclear(result);
            
            // Update cart's updated_at
            const char* updateParams[1] = { cartId.c_str() };
            result = db->executeParams(
                "UPDATE carts SET updated_at = NOW() WHERE id = $1",
                1, updateParams
            );
            
            PQclear(result);
            return true;

        } catch (const std::exception& e) {
            utils::Logger::error("Add cart item error: " + std::string(e.what()));
            return false;
        }
    }

    /**
     * Update cart item quantity
     * @param itemId Cart item UUID
     * @param quantity New quantity
     * @return true if successful
     */
    bool updateItemQuantity(const std::string& itemId, int quantity) {
        if (!db->isConnected()) {
            return false;
        }

        try {
            const char* params[2] = {
                itemId.c_str(),
                std::to_string(quantity).c_str()
            };
            
            PGresult* result = db->executeParams(
                "UPDATE cart_items SET quantity = $2, updated_at = NOW() WHERE id = $1",
                2, params
            );
            
            PQclear(result);
            return true;

        } catch (const std::exception& e) {
            utils::Logger::error("Update cart item error: " + std::string(e.what()));
            return false;
        }
    }

    /**
     * Remove item from cart
     * @param itemId Cart item UUID
     * @return true if successful
     */
    bool removeItem(const std::string& itemId) {
        if (!db->isConnected()) {
            return false;
        }

        try {
            const char* params[1] = { itemId.c_str() };
            PGresult* result = db->executeParams(
                "DELETE FROM cart_items WHERE id = $1",
                1, params
            );
            PQclear(result);
            return true;

        } catch (const std::exception& e) {
            utils::Logger::error("Remove cart item error: " + std::string(e.what()));
            return false;
        }
    }

    /**
     * Clear all items from cart
     * @param cartId Cart UUID
     * @return true if successful
     */
    bool clearCart(const std::string& cartId) {
        if (!db->isConnected()) {
            return false;
        }

        try {
            const char* params[1] = { cartId.c_str() };
            PGresult* result = db->executeParams(
                "DELETE FROM cart_items WHERE cart_id = $1",
                1, params
            );
            PQclear(result);
            return true;

        } catch (const std::exception& e) {
            utils::Logger::error("Clear cart error: " + std::string(e.what()));
            return false;
        }
    }
};

} // namespace repositories
} // namespace agrisphere

#endif // AGRISPHERE_CARTREPOSITORY_H
