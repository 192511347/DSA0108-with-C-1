/**
 * Product Repository
 * Handles all database operations for products
 */

#pragma once

#include "core/Database.h"
#include "models/Product.h"
#include <optional>
#include <memory>
#include <vector>

namespace agrisphere {
namespace repositories {

class ProductRepository {
private:
    std::shared_ptr<core::Database> db;

public:
    explicit ProductRepository(std::shared_ptr<core::Database> database) 
        : db(database) {}

    // Find all products with pagination
    std::vector<models::Product> findAll(int limit = 20, int offset = 0) {
        std::vector<models::Product> products;

        if (!db->isConnected()) {
            return products;
        }

        try {
            std::string query = 
                "SELECT id, name, description, category, price_per_unit, unit, "
                "available_quantity, seller_id, status, created_at, updated_at, images::text "
                "FROM products WHERE status = 'ACTIVE' "
                "ORDER BY created_at DESC "
                "LIMIT " + std::to_string(limit) + " OFFSET " + std::to_string(offset);

            PGresult* res = db->executeQuery(query);
            int rowCount = PQntuples(res);

            for (int i = 0; i < rowCount; i++) {
                models::Product product;
                product.id = PQgetvalue(res, i, 0);
                product.name = PQgetvalue(res, i, 1);
                product.description = PQgetvalue(res, i, 2);
                product.category = models::Product::stringToCategory(PQgetvalue(res, i, 3));
                product.pricePerUnit = std::stoi(PQgetvalue(res, i, 4));
                product.unit = PQgetvalue(res, i, 5);
                product.availableQuantity = std::stoi(PQgetvalue(res, i, 6));
                product.sellerId = PQgetvalue(res, i, 7);
                product.status = models::Product::stringToStatus(PQgetvalue(res, i, 8));
                product.createdAt = PQgetvalue(res, i, 9);
                product.updatedAt = PQgetvalue(res, i, 10);
                if (!PQgetisnull(res, i, 11)) {
                    product.images = nlohmann::json::parse(PQgetvalue(res, i, 11)).get<std::vector<std::string>>();
                }

                products.push_back(product);
            }

            PQclear(res);
            return products;

        } catch (const std::exception& e) {
            throw std::runtime_error("Failed to fetch products: " + std::string(e.what()));
        }
    }

    // Find products by category
    std::vector<models::Product> findByCategory(const std::string& category, int limit = 20) {
        std::vector<models::Product> products;

        if (!db->isConnected()) {
            return products;
        }

        try {
            const char* params[1] = { category.c_str() };
            std::string query = 
                "SELECT id, name, description, category, price_per_unit, unit, "
                "available_quantity, seller_id, status, created_at, updated_at, images::text "
                "FROM products WHERE status = 'ACTIVE' AND category = $1 "
                "ORDER BY created_at DESC "
                "LIMIT " + std::to_string(limit);

            PGresult* res = db->executeParams(query, 1, params);
            int rowCount = PQntuples(res);

            for (int i = 0; i < rowCount; i++) {
                models::Product product;
                product.id = PQgetvalue(res, i, 0);
                product.name = PQgetvalue(res, i, 1);
                product.description = PQgetvalue(res, i, 2);
                product.category = models::Product::stringToCategory(PQgetvalue(res, i, 3));
                product.pricePerUnit = std::stoi(PQgetvalue(res, i, 4));
                product.unit = PQgetvalue(res, i, 5);
                product.availableQuantity = std::stoi(PQgetvalue(res, i, 6));
                product.sellerId = PQgetvalue(res, i, 7);
                product.status = models::Product::stringToStatus(PQgetvalue(res, i, 8));
                product.createdAt = PQgetvalue(res, i, 9);
                product.updatedAt = PQgetvalue(res, i, 10);
                if (!PQgetisnull(res, i, 11)) {
                    product.images = nlohmann::json::parse(PQgetvalue(res, i, 11)).get<std::vector<std::string>>();
                }

                products.push_back(product);
            }

            PQclear(res);
            return products;

        } catch (const std::exception& e) {
            throw std::runtime_error("Failed to fetch products by category: " + std::string(e.what()));
        }
    }

    // Find product by ID
    std::optional<models::Product> findById(const std::string& id) {
        if (!db->isConnected()) {
            return std::nullopt;
        }

        try {
            const char* params[1] = { id.c_str() };
            PGresult* res = db->executeParams(
                "SELECT id, name, description, category, price_per_unit, unit, "
                "available_quantity, seller_id, status, created_at, updated_at, images::text "
                "FROM products WHERE id = $1 LIMIT 1",
                1, params
            );

            if (PQntuples(res) == 0) {
                PQclear(res);
                return std::nullopt;
            }

            models::Product product;
            product.id = PQgetvalue(res, 0, 0);
            product.name = PQgetvalue(res, 0, 1);
            product.description = PQgetvalue(res, 0, 2);
            product.category = models::Product::stringToCategory(PQgetvalue(res, 0, 3));
            product.pricePerUnit = std::stoi(PQgetvalue(res, 0, 4));
            product.unit = PQgetvalue(res, 0, 5);
            product.availableQuantity = std::stoi(PQgetvalue(res, 0, 6));
            product.sellerId = PQgetvalue(res, 0, 7);
            product.status = models::Product::stringToStatus(PQgetvalue(res, 0, 8));
            product.createdAt = PQgetvalue(res, 0, 9);
            product.updatedAt = PQgetvalue(res, 0, 10);
            if (!PQgetisnull(res, 0, 11)) {
                product.images = nlohmann::json::parse(PQgetvalue(res, 0, 11)).get<std::vector<std::string>>();
            }

            PQclear(res);
            return product;

        } catch (const std::exception& e) {
            throw std::runtime_error("Failed to find product by ID: " + std::string(e.what()));
        }
    }

    // Create new product (district and state removed - not in DB schema)
    std::string create(const models::Product& product) {
        if (!db->isConnected()) {
            throw std::runtime_error("Database not connected");
        }

        try {
            std::string category = models::Product::categoryToString(product.category);
            std::string price = std::to_string(product.pricePerUnit);
            std::string quantity = std::to_string(product.availableQuantity);
            nlohmann::json imageJson = product.images;
            std::string images = imageJson.dump();
            const char* params[8] = {
                product.name.c_str(), product.description.c_str(), category.c_str(),
                price.c_str(), product.unit.c_str(), quantity.c_str(),
                product.sellerId.c_str(), images.c_str()
            };
            PGresult* res = db->executeParams(
                "INSERT INTO products (name, description, category, price_per_unit, unit, "
                "available_quantity, seller_id, images, status) "
                "VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, 'ACTIVE') "
                "RETURNING id", 8, params
            );

            std::string newId = PQgetvalue(res, 0, 0);
            PQclear(res);
            return newId;

        } catch (const std::exception& e) {
            throw std::runtime_error("Failed to create product: " + std::string(e.what()));
        }
    }

    // Update product
    bool update(const models::Product& product) {
        if (!db->isConnected()) {
            return false;
        }

        try {
            std::string price = std::to_string(product.pricePerUnit);
            std::string quantity = std::to_string(product.availableQuantity);
            std::string status = models::Product::statusToString(product.status);
            const char* params[6] = {
                product.name.c_str(), product.description.c_str(), price.c_str(),
                quantity.c_str(), status.c_str(), product.id.c_str()
            };

            PGresult* res = db->executeParams(
                "UPDATE products SET name = $1, description = $2, price_per_unit = $3, "
                "available_quantity = $4, status = $5, updated_at = NOW() WHERE id = $6",
                6, params
            );

            bool success = (PQcmdTuples(res)[0] != '0');
            PQclear(res);
            return success;

        } catch (const std::exception& e) {
            throw std::runtime_error("Failed to update product: " + std::string(e.what()));
        }
    }

    // Count total products (for pagination)
    int countAll() {
        if (!db->isConnected()) {
            return 0;
        }

        try {
            PGresult* res = db->executeQuery(
                "SELECT COUNT(*) FROM products WHERE status = 'ACTIVE'"
            );

            int count = std::stoi(PQgetvalue(res, 0, 0));
            PQclear(res);
            return count;

        } catch (const std::exception&) {
            return 0;
        }
    }

    // Find products by seller
    std::vector<models::Product> findBySellerId(const std::string& sellerId) {
        std::vector<models::Product> products;

        if (!db->isConnected()) {
            return products;
        }

        try {
            const char* params[1] = { sellerId.c_str() };
            PGresult* res = db->executeParams(
                "SELECT id, name, description, category, price_per_unit, unit, "
                "available_quantity, seller_id, status, created_at, updated_at, images::text "
                "FROM products WHERE seller_id = $1 "
                "ORDER BY created_at DESC",
                1, params
            );

            int rowCount = PQntuples(res);

            for (int i = 0; i < rowCount; i++) {
                models::Product product;
                product.id = PQgetvalue(res, i, 0);
                product.name = PQgetvalue(res, i, 1);
                product.description = PQgetvalue(res, i, 2);
                product.category = models::Product::stringToCategory(PQgetvalue(res, i, 3));
                product.pricePerUnit = std::stoi(PQgetvalue(res, i, 4));
                product.unit = PQgetvalue(res, i, 5);
                product.availableQuantity = std::stoi(PQgetvalue(res, i, 6));
                product.sellerId = PQgetvalue(res, i, 7);
                product.status = models::Product::stringToStatus(PQgetvalue(res, i, 8));
                product.createdAt = PQgetvalue(res, i, 9);
                product.updatedAt = PQgetvalue(res, i, 10);
                if (!PQgetisnull(res, i, 11)) {
                    product.images = nlohmann::json::parse(PQgetvalue(res, i, 11)).get<std::vector<std::string>>();
                }

                products.push_back(product);
            }

            PQclear(res);
            return products;

        } catch (const std::exception& e) {
            throw std::runtime_error("Failed to fetch products by seller: " + std::string(e.what()));
        }
    }
};

} // namespace repositories
} // namespace agrisphere
