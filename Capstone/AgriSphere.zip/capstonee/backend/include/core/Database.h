/**
 * Database Connection Manager
 * PostgreSQL connection using libpq with enhanced error handling
 */

#pragma once

#include <libpq-fe.h>
#include <string>
#include <memory>
#include <stdexcept>
#include <iostream>
#include <vector>
#include <mutex>

namespace agrisphere {
namespace core {

class Database {
private:
    PGconn* conn;
    std::string connStr;
    bool connected;
    mutable std::recursive_mutex connectionMutex;

public:
    Database(const std::string& connectionString) 
        : conn(nullptr), connStr(connectionString), connected(false) {
    }

    ~Database() {
        disconnect();
    }

    // Prevent copying
    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;

    bool connect() {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        if (connected && conn != nullptr) {
            return true; // Already connected
        }

        conn = PQconnectdb(connStr.c_str());
        
        if (PQstatus(conn) != CONNECTION_OK) {
            std::cerr << "Database connection failed: " << PQerrorMessage(conn) << std::endl;
            PQfinish(conn);
            conn = nullptr;
            connected = false;
            return false;
        }

        connected = true;
        std::cout << "✅ Database connected: " << PQdb(conn) 
                  << " (server version " << PQserverVersion(conn) << ")" << std::endl;
        return true;
    }

    void disconnect() {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        if (conn != nullptr) {
            PQfinish(conn);
            conn = nullptr;
            connected = false;
            std::cout << "Database disconnected" << std::endl;
        }
    }

    bool isConnected() const {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        return connected && conn != nullptr && PQstatus(conn) == CONNECTION_OK;
    }

    PGresult* executeQuery(const std::string& query) {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        if (!isConnected()) {
            throw std::runtime_error("Database not connected");
        }

        PGresult* res = PQexec(conn, query.c_str());
        
        if (PQresultStatus(res) != PGRES_TUPLES_OK && 
            PQresultStatus(res) != PGRES_COMMAND_OK) {
            std::string error = PQerrorMessage(conn);
            PQclear(res);
            throw std::runtime_error("Query failed: " + error);
        }

        return res;
    }

    PGresult* executeParams(const std::string& query, 
                            int nParams, 
                            const char* const* paramValues) {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        if (!isConnected()) {
            throw std::runtime_error("Database not connected");
        }

        PGresult* res = PQexecParams(conn, query.c_str(), nParams, nullptr,
                                     paramValues, nullptr, nullptr, 0);
        
        if (PQresultStatus(res) != PGRES_TUPLES_OK && 
            PQresultStatus(res) != PGRES_COMMAND_OK) {
            std::string error = PQerrorMessage(conn);
            PQclear(res);
            throw std::runtime_error("Query failed: " + error);
        }

        return res;
    }

    // Safer executeParams with std::vector
    PGresult* executeParams(const std::string& query, 
                            const std::vector<std::string>& params) {
        std::vector<const char*> paramValues;
        for (const auto& param : params) {
            paramValues.push_back(param.c_str());
        }
        return executeParams(query, static_cast<int>(paramValues.size()), paramValues.data());
    }

    std::string escapeString(const std::string& input) {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        if (!isConnected()) {
            return input;
        }

        char* escaped = new char[input.length() * 2 + 1];
        PQescapeStringConn(conn, escaped, input.c_str(), input.length(), nullptr);
        std::string result(escaped);
        delete[] escaped;
        return result;
    }

    std::string getError() const {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        if (conn != nullptr) {
            return PQerrorMessage(conn);
        }
        return "Connection not initialized";
    }

    // Transaction support
    bool beginTransaction() {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        if (!isConnected()) {
            return false;
        }
        try {
            PGresult* res = PQexec(conn, "BEGIN");
            bool success = (PQresultStatus(res) == PGRES_COMMAND_OK);
            PQclear(res);
            return success;
        } catch (...) {
            return false;
        }
    }

    bool commitTransaction() {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        if (!isConnected()) {
            return false;
        }
        try {
            PGresult* res = PQexec(conn, "COMMIT");
            bool success = (PQresultStatus(res) == PGRES_COMMAND_OK);
            PQclear(res);
            return success;
        } catch (...) {
            return false;
        }
    }

    bool rollbackTransaction() {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        if (!isConnected()) {
            return false;
        }
        try {
            PGresult* res = PQexec(conn, "ROLLBACK");
            bool success = (PQresultStatus(res) == PGRES_COMMAND_OK);
            PQclear(res);
            return success;
        } catch (...) {
            return false;
        }
    }

    // Test connection with a simple query
    bool testConnection() {
        std::lock_guard<std::recursive_mutex> lock(connectionMutex);
        if (!isConnected()) {
            return false;
        }
        try {
            PGresult* res = PQexec(conn, "SELECT 1");
            bool success = (PQresultStatus(res) == PGRES_TUPLES_OK);
            PQclear(res);
            return success;
        } catch (...) {
            return false;
        }
    }
};

} // namespace core
} // namespace agrisphere
