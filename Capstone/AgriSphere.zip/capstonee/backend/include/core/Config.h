/**
 * Configuration Management
 * Handles environment variables and application configuration
 */

#pragma once

#include <string>
#include <cstdlib>
#include <stdexcept>

namespace agrisphere {
namespace core {

class Config {
private:
    // Server configuration
    int serverPort;
    std::string corsOrigin;
    
    // Database configuration
    std::string dbHost;
    std::string dbPort;
    std::string dbName;
    std::string dbUser;
    std::string dbPassword;
    
    // JWT configuration
    std::string jwtSecret;
    int jwtExpirationMinutes;
    
    // Helper to get environment variable with default
    static std::string getEnv(const char* key, const std::string& defaultVal = "") {
        const char* val = std::getenv(key);
        return val ? std::string(val) : defaultVal;
    }
    
    // Helper to get environment variable as integer
    static int getEnvInt(const char* key, int defaultVal) {
        const char* val = std::getenv(key);
        if (!val) return defaultVal;
        try {
            return std::stoi(val);
        } catch (...) {
            return defaultVal;
        }
    }

public:
    Config() {
        // Load server configuration
        serverPort = getEnvInt("SERVER_PORT", 6001);
        corsOrigin = getEnv("CORS_ORIGIN", "http://localhost:5000");
        
        // Load database configuration
        dbHost = getEnv("DB_HOST", "localhost");
        dbPort = getEnv("DB_PORT", "5432");
        dbName = getEnv("DB_NAME", "agrisphere");
        dbUser = getEnv("DB_USER", "postgres");
        dbPassword = getEnv("DB_PASSWORD", "");
        
        // Load JWT configuration
        jwtSecret = getEnv("JWT_SECRET", "");
        jwtExpirationMinutes = getEnvInt("JWT_EXPIRATION_MINUTES", 60);
        
        // Validation
        if (jwtSecret.empty()) {
            jwtSecret = "INSECURE_DEFAULT_SECRET_CHANGE_IN_PRODUCTION";
        }
    }
    
    // Server getters
    int getServerPort() const { return serverPort; }
    std::string getCorsOrigin() const { return corsOrigin; }
    
    // Database getters
    std::string getDbHost() const { return dbHost; }
    std::string getDbPort() const { return dbPort; }
    std::string getDbName() const { return dbName; }
    std::string getDbUser() const { return dbUser; }
    std::string getDbPassword() const { return dbPassword; }
    
    // JWT getters
    std::string getJwtSecret() const { return jwtSecret; }
    int getJwtExpirationMinutes() const { return jwtExpirationMinutes; }
    
    // Connection string builder
    std::string getDatabaseConnectionString() const {
        return "host=" + dbHost + 
               " port=" + dbPort + 
               " dbname=" + dbName + 
               " user=" + dbUser + 
               " password=" + dbPassword +
               " connect_timeout=10";
    }
    
    // Validation
    bool isDatabaseConfigured() const {
        return !dbPassword.empty();
    }
    
    bool isJwtConfigured() const {
        return jwtSecret != "INSECURE_DEFAULT_SECRET_CHANGE_IN_PRODUCTION";
    }
    
    // Display configuration (safe - no secrets)
    void printConfiguration() const {
        std::cout << "========================================\n";
        std::cout << "AgriSphere C++ Backend v1.0.0\n";
        std::cout << "Crow HTTP Server (Windows Native)\n";
        std::cout << "========================================\n";
        std::cout << "Server Port: " << serverPort << "\n";
        std::cout << "CORS Origin: " << corsOrigin << "\n";
        std::cout << "Database: " << dbHost << ":" << dbPort << "/" << dbName << "\n";
        std::cout << "Database User: " << dbUser << "\n";
        std::cout << "Database Password: " << (dbPassword.empty() ? "NOT SET" : "***") << "\n";
        std::cout << "JWT Secret: " << (isJwtConfigured() ? "CONFIGURED" : "USING DEFAULT") << "\n";
        std::cout << "========================================\n";
    }
};

} // namespace core
} // namespace agrisphere
