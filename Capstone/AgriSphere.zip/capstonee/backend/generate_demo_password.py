#!/usr/bin/env python3
"""
Generate PBKDF2-SHA256 password hashes compatible with AgriSphere C++ backend
Password format: salt$iterations$hash (all hex encoded)
"""

import hashlib
import secrets
import sys

SALT_LENGTH = 16  # bytes
ITERATIONS = 10000
KEY_LENGTH = 32  # bytes

def hash_password(password: str) -> str:
    """Generate password hash in the format used by backend"""
    # Generate random salt
    salt = secrets.token_bytes(SALT_LENGTH)
    
    # Derive key using PBKDF2-HMAC-SHA256
    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, ITERATIONS, KEY_LENGTH)
    
    # Format: salt$iterations$hash (all hex encoded)
    salt_hex = salt.hex()
    key_hex = key.hex()
    
    return f"{salt_hex}${ITERATIONS}${key_hex}"

def verify_password(password: str, hash_str: str) -> bool:
    """Verify password against hash"""
    try:
        parts = hash_str.split('$')
        if len(parts) != 3:
            return False
        
        salt_hex, iterations_str, expected_key_hex = parts
        iterations = int(iterations_str)
        
        salt = bytes.fromhex(salt_hex)
        expected_key = bytes.fromhex(expected_key_hex)
        
        # Derive key with same parameters
        derived_key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations, KEY_LENGTH)
        
        # Constant-time comparison
        return secrets.compare_digest(derived_key, expected_key)
    except:
        return False

def main():
    print("AgriSphere Password Hash Generator")
    print("=" * 50)
    
    # Demo password
    demo_password = "Demo@123456"
    
    print(f"\nGenerating hashes for password: {demo_password}")
    print("\nDemo User Password Hashes:")
    print("-" * 50)
    
    roles = ["ADMIN", "FARMER", "BUYER", "SELLER", "SERVICE_PROVIDER"]
    emails = [
        "admin@agrisphere.demo",
        "farmer@agrisphere.demo", 
        "buyer@agrisphere.demo",
        "supplier@agrisphere.demo",
        "provider@agrisphere.demo"
    ]
    
    hashes = {}
    for role, email in zip(roles, emails):
        hash_value = hash_password(demo_password)
        hashes[email] = hash_value
        
        # Verify it works
        if verify_password(demo_password, hash_value):
            print(f"✓ {email:30s} {role:20s}")
            print(f"  Hash: {hash_value}")
        else:
            print(f"✗ {email:30s} VERIFICATION FAILED")
    
    # Generate SQL insert statements
    print("\n" + "=" * 50)
    print("SQL INSERT Statements:")
    print("=" * 50)
    
    user_data = [
        ("00000000-0000-0000-0000-000000000001", "admin@agrisphere.demo", hashes["admin@agrisphere.demo"], 
         "Admin Demo User", "9000000001", "ADMIN", "Bangalore Urban", "Karnataka"),
        ("00000000-0000-0000-0000-000000000002", "farmer@agrisphere.demo", hashes["farmer@agrisphere.demo"],
         "Farmer Demo User", "9000000002", "FARMER", "Mysuru", "Karnataka"),
        ("00000000-0000-0000-0000-000000000003", "buyer@agrisphere.demo", hashes["buyer@agrisphere.demo"],
         "Buyer Demo User", "9000000003", "BUYER", "Hubli", "Karnataka"),
        ("00000000-0000-0000-0000-000000000004", "supplier@agrisphere.demo", hashes["supplier@agrisphere.demo"],
         "Supplier Demo User", "9000000004", "SELLER", "Mangaluru", "Karnataka"),
        ("00000000-0000-0000-0000-000000000005", "provider@agrisphere.demo", hashes["provider@agrisphere.demo"],
         "Service Provider Demo", "9000000005", "SERVICE_PROVIDER", "Belagavi", "Karnataka"),
    ]
    
    print("\n-- Delete existing demo users first")
    print("DELETE FROM users WHERE email IN (")
    for i, (_, email, _, _, _, _, _, _) in enumerate(user_data):
        comma = "," if i < len(user_data) - 1 else ""
        print(f"    '{email}'{comma}")
    print(");")
    
    print("\n-- Insert demo users")
    for user in user_data:
        uid, email, pwd_hash, name, phone, role, district, state = user
        print(f"""
INSERT INTO users (id, email, password_hash, full_name, phone, role, status, district, state) VALUES
('{uid}', '{email}', '{pwd_hash}', '{name}', '{phone}', '{role}', 'ACTIVE', '{district}', '{state}');""")
    
    print("\n" + "=" * 50)
    print(f"Demo Password: {demo_password}")
    print("All accounts use the same password for testing")
    print("=" * 50)

if __name__ == "__main__":
    main()
