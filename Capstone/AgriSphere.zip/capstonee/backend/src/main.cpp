/**
 * AgriSphere Windows-Native C++ Backend
 * Refactored with modular architecture
 */

#include <crow.h>
#include <nlohmann/json.hpp>
#include <iostream>
#include <memory>

// Core infrastructure
#include "core/Config.h"
#include "core/Database.h"

// Utilities
#include "utils/Logger.h"
#include "utils/ResponseHelper.h"
#include "utils/PasswordUtil.h"
#include "utils/JwtUtil.h"

// Models
#include "models/User.h"
#include "models/Product.h"
#include "models/Cart.h"

// Repositories
#include "repositories/UserRepository.h"
#include "repositories/ProductRepository.h"
#include "repositories/CartRepository.h"

// Services
#include "services/AuthService.h"
#include "services/ProductService.h"
#include "services/CartService.h"

// Controllers
#include "controllers/AuthController.h"
#include "controllers/ProductController.h"
#include "controllers/CartController.h"
#include "controllers/MarketplaceExtras.h"
#include "controllers/AdvisoryController.h"

// Middleware
#include "middleware/AuthMiddleware.h"

using json = nlohmann::json;
using namespace agrisphere;

int main() {
    // Load configuration
    auto config = std::make_shared<core::Config>();
    config->printConfiguration();

    // Set logging level
    utils::Logger::setMinLevel(utils::LOG_INFO);
    utils::Logger::info("Starting AgriSphere backend...");

    // Initialize database
    auto db = std::make_shared<core::Database>(config->getDatabaseConnectionString());
    bool dbConnected = db->connect();
    
    if (!dbConnected) {
        utils::Logger::warning("Database connection failed. Using fallback responses.");
        utils::Logger::error("Database error: " + db->getError());
        return 1;
    } else {
        utils::Logger::info("Database connection established successfully");
        
        // Test connection
        if (db->testConnection()) {
            utils::Logger::info("Database test query successful");
        }
    }

    // Initialize response helper
    auto responseHelper = std::make_shared<utils::ResponseHelper>(config->getCorsOrigin());

    // Initialize JWT utility
    auto jwtUtil = std::make_shared<utils::JwtUtil>(config->getJwtSecret(), config->getJwtExpirationMinutes());

    // Initialize repositories
    auto userRepo = std::make_shared<repositories::UserRepository>(db);
    auto productRepo = std::make_shared<repositories::ProductRepository>(db);
    auto cartRepo = std::make_shared<repositories::CartRepository>(db);

    // Initialize services
    auto authService = std::make_shared<services::AuthService>(userRepo, jwtUtil);
    auto productService = std::make_shared<services::ProductService>(productRepo);
    auto cartService = std::make_shared<services::CartService>(cartRepo, productRepo);

    // Initialize middleware
    auto authMiddleware = std::make_shared<middleware::AuthMiddleware>(jwtUtil, responseHelper);

    // Initialize controllers
    auto authController = std::make_shared<controllers::AuthController>(authService, responseHelper);
    auto productController = std::make_shared<controllers::ProductController>(productService, authService, responseHelper);
    auto cartController = std::make_shared<controllers::CartController>(cartService, authMiddleware, responseHelper);

    // Create Crow application
    crow::SimpleApp app;

    // ============================================================================
    // REGISTER CONTROLLER ROUTES
    // ============================================================================
    
    // Health endpoint (inline - simple system check)
    CROW_ROUTE(app, "/api/v1/health")
    ([db, responseHelper]() {
        utils::Logger::apiRequest("GET", "/api/v1/health");
        
        std::string dbStatus = db->isConnected() ? "connected" : "not_connected";
        
        json data = {
            {"status", "ok"},
            {"service", "AgriSphere C++ API"},
            {"database", dbStatus},
            {"timestamp", std::time(nullptr)}
        };
        
        auto response = responseHelper->success(data);
        utils::Logger::apiResponse("/api/v1/health", 200);
        return response;
    });

    // Register controller routes
    authController->registerRoutes(app);
    productController->registerRoutes(app);
    cartController->registerRoutes(app);
    controllers::registerMarketplaceExtras(app, config->getDatabaseConnectionString(), authMiddleware, responseHelper);
    controllers::registerAdvisoryRoutes(app, config->getDatabaseConnectionString(), authMiddleware, responseHelper);
    
    utils::Logger::info("All routes registered successfully");

    // ============================================================================
    // START SERVER
    // ============================================================================
    utils::Logger::info("Server starting on port " + std::to_string(config->getServerPort()));
    std::cout << "\nHealth check: http://localhost:" << config->getServerPort() << "/api/v1/health\n";
    std::cout << "Press Ctrl+C to stop\n\n";

    app.port(static_cast<uint16_t>(config->getServerPort())).multithreaded().run();
    
    utils::Logger::info("Server stopped");
    db->disconnect();
    
    return 0;
}
