/**
 * Logger implementation
 */

#include "utils/Logger.h"

namespace agrisphere {
namespace utils {

// Initialize static member
LogLevel Logger::minLevel = LOG_INFO;

} // namespace utils
} // namespace agrisphere
