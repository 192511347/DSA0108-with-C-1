/**
 * Database Connection Manager
 * PostgreSQL connection using libpq
 */

#pragma once

#include <libpq-fe.h>
#include <string>
#include <memory>
#include <stdexcept>
#include <iostream>

class Database {
private:
    PGconn* conn;
    std::string connStr;

public:
    Database(const std::string& host, const std::string& port, 
             const std::string& dbname, const std::string& user, 
             const std::string& password) {
        
        connStr = "host=" + host + 
                  " port=" + port + 
                  " dbname=" + dbname + 
                  " user=" + user + 
                  " password=" + password +
                  " connect_timeout=10";
        
        conn = nullptr;
    }

    ~Database() {
        disconnect();
    }

    bool connect() {
        if (conn != nullptr) {
            return true; // Already connected
        }

        conn = PQconnectdb(connStr.c_str());
        
        if (PQstatus(conn) != CONNECTION_OK) {
            std::cerr << "Database connection failed: " << PQerrorMessage(conn) << std::endl;
            PQfinish(conn);
            conn = nullptr;
            return false;
        }

        std::cout << "✅ Database connected: " << PQdb(conn) << std::endl;
        return true;
    }

    void disconnect() {
        if (conn != nullptr) {
            PQfinish(conn);
            conn = nullptr;
            std::cout << "Database disconnected" << std::endl;
        }
    }

    bool isConnected() const {
        return conn != nullptr && PQstatus(conn) == CONNECTION_OK;
    }

    PGresult* executeQuery(const std::string& query) {
        if (!isConnected()) {
            throw std::runtime_error("Database not connected");
        }

        PGresult* res = PQexec(conn, query.c_str());
        
        if (PQresultStatus(res) != PGRES_TUPLES_OK && 
            PQresultStatus(res) != PGRES_COMMAND_OK) {
            std::string error = PQerrorMessage(conn);
            PQclear(res);
            throw std::runtime_error("Query failed: " + error);
        }

        return res;
    }

    PGresult* executeParams(const std::string& query, 
                            int nParams, 
                            const char* const* paramValues) {
        if (!isConnected()) {
            throw std::runtime_error("Database not connected");
        }

        PGresult* res = PQexecParams(conn, query.c_str(), nParams, nullptr,
                                     paramValues, nullptr, nullptr, 0);
        
        if (PQresultStatus(res) != PGRES_TUPLES_OK && 
            PQresultStatus(res) != PGRES_COMMAND_OK) {
            std::string error = PQerrorMessage(conn);
            PQclear(res);
            throw std::runtime_error("Query failed: " + error);
        }

        return res;
    }

    std::string escapeString(const std::string& input) {
        if (!isConnected()) {
            return input;
        }

        char* escaped = new char[input.length() * 2 + 1];
        PQescapeStringConn(conn, escaped, input.c_str(), input.length(), nullptr);
        std::string result(escaped);
        delete[] escaped;
        return result;
    }

    std::string getError() const {
        if (conn != nullptr) {
            return PQerrorMessage(conn);
        }
        return "Connection not initialized";
    }
};
