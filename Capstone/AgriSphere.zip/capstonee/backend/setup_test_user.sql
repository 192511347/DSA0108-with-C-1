-- AgriSphere Test User Setup
-- This updates the buyer account with a known password
-- Password: Test@1234
-- Bcrypt Hash (12 rounds): $2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5QK7TbpVO6eKW

\c agrisphere

-- Update existing buyer account with known password
UPDATE users 
SET password_hash = '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5QK7TbpVO6eKW'
WHERE email = 'buyer@agrisphere.in';

-- Verify the update
\echo ''
\echo '========================================';
\echo '✅ Test User Updated Successfully!';
\echo '========================================';
\echo ''
\echo 'LOGIN CREDENTIALS:';
\echo '------------------';
\echo 'Email:    buyer@agrisphere.in';
\echo 'Password: Test@1234';
\echo 'Role:     BUYER';
\echo ''
\echo 'Test at: http://localhost:3000/login';
\echo ''

SELECT 
    email as "Email",
    role as "Role",
    full_name as "Name",
    'Test@1234' as "Password",
    substring(password_hash, 1, 20) || '...' as "Hash Preview"
FROM users 
WHERE email = 'buyer@agrisphere.in';

\echo ''
\echo '========================================';
