-- Reviews Table
-- Reviews for products, services, or sellers

CREATE TABLE IF NOT EXISTS reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    target_type VARCHAR(50) NOT NULL CHECK (target_type IN ('PRODUCT', 'SERVICE', 'SELLER')),
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    images JSONB DEFAULT '[]'::jsonb,
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'HIDDEN', 'FLAGGED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for product reviews
CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id);

-- Comments
COMMENT ON TABLE reviews IS 'User reviews and ratings';
COMMENT ON COLUMN reviews.target_type IS 'What is being reviewed: PRODUCT, SERVICE, or SELLER';
COMMENT ON COLUMN reviews.rating IS '1-5 star rating';
COMMENT ON COLUMN reviews.status IS 'Moderation status: ACTIVE, HIDDEN, FLAGGED';
