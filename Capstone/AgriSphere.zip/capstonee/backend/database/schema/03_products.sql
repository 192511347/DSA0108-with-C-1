-- Products Table
-- Stores agricultural products listed by farmers/sellers

CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    seller_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100) NOT NULL,
    price_per_unit BIGINT NOT NULL CHECK (price_per_unit > 0),
    unit VARCHAR(50) NOT NULL,
    available_quantity INTEGER NOT NULL CHECK (available_quantity >= 0),
    min_order_quantity INTEGER NOT NULL DEFAULT 1 CHECK (min_order_quantity > 0),
    images JSONB DEFAULT '[]'::jsonb,
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE', 'OUT_OF_STOCK')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_products_seller ON products(seller_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);

-- Comments
COMMENT ON TABLE products IS 'Agricultural products available for purchase';
COMMENT ON COLUMN products.price_per_unit IS 'Price in smallest currency unit (paisa/cents)';
COMMENT ON COLUMN products.unit IS 'Measurement unit: KG, QUINTAL, TON, BAG, LITRE, etc.';
COMMENT ON COLUMN products.images IS 'JSON array of image URLs';
COMMENT ON COLUMN products.category IS 'Product category: GRAINS, VEGETABLES, FRUITS, DAIRY, etc.';
