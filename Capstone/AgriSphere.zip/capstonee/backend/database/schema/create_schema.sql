-- AgriSphere Complete Database Schema
-- PostgreSQL 18.6
-- Run this script to create all tables in correct dependency order

-- ============================================================================
-- 1. USERS TABLE
-- ============================================================================
\i 01_users.sql

-- ============================================================================
-- 2. REFRESH TOKENS TABLE
-- ============================================================================
\i 02_refresh_tokens.sql

-- ============================================================================
-- 3. PRODUCTS TABLE
-- ============================================================================
\i 03_products.sql

-- ============================================================================
-- 4. CARTS & CART ITEMS TABLES
-- ============================================================================
\i 04_carts.sql

-- ============================================================================
-- 5. ORDERS & ORDER ITEMS TABLES
-- ============================================================================
\i 05_orders.sql

-- ============================================================================
-- 6. REVIEWS TABLE
-- ============================================================================
\i 06_reviews.sql

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- List all tables
\dt

-- Show table counts
SELECT 
    'users' as table_name, COUNT(*) as count FROM users
UNION ALL
    SELECT 'refresh_tokens', COUNT(*) FROM refresh_tokens
UNION ALL
    SELECT 'products', COUNT(*) FROM products
UNION ALL
    SELECT 'carts', COUNT(*) FROM carts
UNION ALL
    SELECT 'cart_items', COUNT(*) FROM cart_items
UNION ALL
    SELECT 'orders', COUNT(*) FROM orders
UNION ALL
    SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL
    SELECT 'reviews', COUNT(*) FROM reviews
ORDER BY table_name;

-- Success message
SELECT 'AgriSphere schema created successfully!' as status;
