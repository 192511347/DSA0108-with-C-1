-- Safe, additive schema migration. Only authenticated users' advisory records are stored.
BEGIN;
CREATE TABLE IF NOT EXISTS advisory_history (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 role TEXT NOT NULL,
 question TEXT NOT NULL,
 location TEXT NOT NULL DEFAULT '',
 language TEXT NOT NULL DEFAULT 'en',
 answer JSONB NOT NULL,
 weather JSONB NOT NULL DEFAULT 'null'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_advisory_history_user_date ON advisory_history(user_id,created_at DESC);
COMMIT;
