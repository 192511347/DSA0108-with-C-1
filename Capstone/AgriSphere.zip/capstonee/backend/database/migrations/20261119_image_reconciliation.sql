-- Photos were visually verified. Update ONLY rows that match a known photograph.
-- Unverified LOCAL seeded references are cleared, keeping product rows.
-- Existing seller uploads (/uploads/) and remote images are preserved.
-- Unmatched seeded listings with a /products/ photo are marked INACTIVE; their records are preserved.
BEGIN;
WITH matched AS (
 SELECT id, CASE
 WHEN lower(trim(name)) IN ('black pepper','black peppercorns') THEN 'Black%20Pepper.jpg'
 WHEN lower(trim(name)) IN ('turmeric powder','turmeric') THEN 'Turmeric%20Powder.jpg'
 WHEN lower(trim(name)) IN ('cumin seeds','cumin seeds (jeera)','cumin seeds jeera','jeera') THEN 'Cumin%20Seeds%28Jeera%29.jpg'
 WHEN lower(trim(name)) IN ('coriander powder','ground coriander') THEN 'Coriander%20Powder.jpg'
 WHEN lower(trim(name)) IN ('brinjal','brinjal eggplant','brinjal (eggplant)','eggplant') THEN 'Brinjal%28Eggplant%29.jpg'
 WHEN lower(trim(name)) IN ('lady finger','lady finger okra','lady finger (okra)','okra') THEN 'Lady%20Finger%28Okra%29.jpg'
 WHEN lower(trim(name)) IN ('green grapes','grapes') THEN 'Green%20Grapes.jpg'
 WHEN lower(trim(name)) IN ('pomegranate','pomegranates') THEN 'Pomegranate.jpg'
 WHEN lower(trim(name)) IN ('watermelon') THEN 'Watermelon.jpg'
 WHEN lower(trim(name)) IN ('fresh curd','fresh curd dahi','fresh curd (dahi)','curd','dahi') THEN 'Fresh%20Curd%28Dahi%29.jpg'
 WHEN lower(trim(name)) IN ('fresh paneer','paneer') THEN 'Fresh%20Paneer.jpg'
 WHEN lower(trim(name)) IN ('desi ghee','ghee') THEN 'Desi%20Ghee.jpg'
 ELSE NULL END AS filename
 FROM products
)
UPDATE products p SET images = CASE
 WHEN m.filename IS NOT NULL THEN jsonb_build_array('/products/' || m.filename)
 ELSE '[]'::jsonb END,
status = CASE WHEN m.filename IS NULL AND p.images::text LIKE '%/products/%' THEN 'INACTIVE' ELSE p.status END,
updated_at=now()
FROM matched m WHERE p.id=m.id
AND (p.images::text LIKE '%/products/%' OR p.images IS NULL OR p.images = '[]'::jsonb);
-- Improve descriptions only for generic seeded placeholders, do not overwrite custom seller copy.
UPDATE products SET description = CASE lower(trim(name))
 WHEN 'black pepper' THEN 'Whole black peppercorns, sold by weight; suitable for seasoning and spice grinding.'
 WHEN 'turmeric powder' THEN 'Fine ground turmeric powder for cooking and spice blends.'
 WHEN 'cumin seeds' THEN 'Whole cumin (jeera) seeds for seasoning and spice blends.'
 WHEN 'coriander powder' THEN 'Ground coriander seed powder for cooking and spice blends.'
 WHEN 'brinjal eggplant' THEN 'Fresh brinjal (eggplant), offered as a vegetable for home cooking.'
 WHEN 'lady finger okra' THEN 'Fresh okra (lady finger), available as a seasonal vegetable.'
 WHEN 'green grapes' THEN 'Fresh green grapes, a ready-to-eat fruit.'
 WHEN 'pomegranate' THEN 'Fresh pomegranates with red edible seeds.'
 WHEN 'watermelon' THEN 'Whole watermelon fruit with sweet red flesh.'
 WHEN 'fresh curd' THEN 'Fresh curd (dahi), a fermented dairy product; keep refrigerated.'
 WHEN 'fresh paneer' THEN 'Fresh paneer cheese cubes; keep refrigerated.'
 WHEN 'desi ghee' THEN 'Packaged desi ghee, a clarified butter cooking fat.'
 ELSE description END,updated_at=now()
WHERE (description IS NULL OR description='' OR description ILIKE 'Farm-fresh % available through AgriSphere' OR description ILIKE 'Quality agricultural product%')
AND lower(trim(name)) IN ('black pepper','turmeric powder','cumin seeds','coriander powder','brinjal eggplant','lady finger okra','green grapes','pomegranate','watermelon','fresh curd','fresh paneer','desi ghee');
COMMIT;
-- Audit retained products without verified photos:
SELECT id, name, images FROM products WHERE images = '[]'::jsonb ORDER BY name;
