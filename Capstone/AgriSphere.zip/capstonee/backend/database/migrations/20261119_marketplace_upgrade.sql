-- AgriSphere add-on. Safe to re-run, does not delete accounts or orders.
BEGIN;
CREATE TABLE IF NOT EXISTS product_views (
 id BIGSERIAL PRIMARY KEY, product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
 viewer_id UUID REFERENCES users(id) ON DELETE SET NULL, viewed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS product_views_product_idx ON product_views(product_id);
CREATE TABLE IF NOT EXISTS farm_profiles (
 user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 land_acres NUMERIC(10,2) CHECK (land_acres IS NULL OR land_acres >= 0),
 soil_type TEXT NOT NULL DEFAULT '', irrigation TEXT NOT NULL DEFAULT '',
 current_crops TEXT NOT NULL DEFAULT '', sowing_date DATE,
 farm_location TEXT NOT NULL DEFAULT '', updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS service_requests (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), requester_id UUID NOT NULL REFERENCES users(id),
 provider_id UUID REFERENCES users(id), service_name TEXT NOT NULL,
 contact_name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL DEFAULT '',
 location TEXT NOT NULL, preferred_date DATE, notes TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'REQUESTED' CHECK(status IN ('REQUESTED','ACCEPTED','IN_PROGRESS','COMPLETED','CANCELLED')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS service_requests_requester_idx ON service_requests(requester_id);
CREATE INDEX IF NOT EXISTS service_requests_provider_idx ON service_requests(provider_id);
COMMIT;
