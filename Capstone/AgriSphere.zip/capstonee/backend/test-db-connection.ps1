# Test PostgreSQL Connection Script
# Usage: .\test-db-connection.ps1 <password>

param(
    [Parameter(Mandatory=$true)]
    [string]$Password
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "PostgreSQL Connection Test" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$env:PGPASSWORD = $Password

try {
    Write-Host "Testing connection to: localhost:5432/agrisphere" -ForegroundColor Yellow
    Write-Host "User: postgres" -ForegroundColor Yellow
    Write-Host ""
    
    $result = psql -h localhost -p 5432 -U postgres -d agrisphere -c "SELECT 1 as test, current_database(), current_user;" 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ SUCCESS: Database connection established!" -ForegroundColor Green
        Write-Host ""
        Write-Host "Query result:" -ForegroundColor White
        Write-Host $result
        Write-Host ""
        Write-Host "Next steps:" -ForegroundColor Cyan
        Write-Host "1. Update backend/.env with this password" -ForegroundColor White
        Write-Host "2. Restart the backend server" -ForegroundColor White
        Write-Host "3. Health check should show 'database: connected'" -ForegroundColor White
    } else {
        Write-Host "❌ FAILED: Could not connect to database" -ForegroundColor Red
        Write-Host ""
        Write-Host "Error:" -ForegroundColor Red
        Write-Host $result
        Write-Host ""
        Write-Host "Common fixes:" -ForegroundColor Yellow
        Write-Host "- Check if PostgreSQL service is running" -ForegroundColor White
        Write-Host "- Verify the password is correct" -ForegroundColor White
        Write-Host "- Check pg_hba.conf authentication method" -ForegroundColor White
    }
} finally {
    $env:PGPASSWORD = ""
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
