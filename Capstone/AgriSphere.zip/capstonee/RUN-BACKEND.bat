@echo off
echo ========================================
echo Starting AgriSphere C++ Backend
echo ========================================
echo.

cd backend\build
.\Release\AgriSphere.exe

pause
