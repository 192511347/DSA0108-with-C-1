@echo off
title Run E2E Tests
echo Running Playwright tests...
call npm test
echo.
echo View report with: npm run report
pause
